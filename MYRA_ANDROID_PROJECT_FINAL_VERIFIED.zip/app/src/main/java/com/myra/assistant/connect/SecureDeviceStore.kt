package com.myra.assistant.connect

import android.content.Context
import android.content.SharedPreferences
import android.os.Build
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.util.UUID

/**
 * Secure persistent store for MYRA Connect paired devices, authentication tokens,
 * and recipient permission preferences.
 */
class SecureDeviceStore(context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences("myra_connect_secure", Context.MODE_PRIVATE)
    private val gson = Gson()

    // Unique Persistent ID for this phone
    val thisDeviceId: String
        get() {
            var id = prefs.getString("this_device_id", null)
            if (id == null) {
                id = UUID.randomUUID().toString()
                prefs.edit().putString("this_device_id", id).apply()
            }
            return id
        }

    // Friendly Device Name (e.g. "Primary Phone", "Home Phone")
    var thisDeviceName: String
        get() {
            return prefs.getString("this_device_name", null) ?: "${Build.MANUFACTURER.replaceFirstChar { it.uppercase() }} ${Build.MODEL}"
        }
        set(value) {
            prefs.edit().putString("this_device_name", value).apply()
        }

    // Local TCP Server Port
    var serverPort: Int
        get() = prefs.getInt("server_port", 9876)
        set(value) = prefs.edit().putInt("server_port", value).apply()

    // --- Paired Devices Management ---

    fun getPairedDevices(): List<PairedDevice> {
        val json = prefs.getString("paired_devices_list", null) ?: return emptyList()
        return try {
            val type = object : TypeToken<List<PairedDevice>>() {}.type
            gson.fromJson<List<PairedDevice>>(json, type) ?: emptyList()
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun savePairedDevice(device: PairedDevice) {
        val current = getPairedDevices().toMutableList()
        val index = current.indexOfFirst { it.id == device.id }
        if (index >= 0) {
            current[index] = device
        } else {
            current.add(device)
        }
        saveDevicesList(current)
    }

    fun getDevice(id: String): PairedDevice? {
        return getPairedDevices().find { it.id == id }
    }

    fun getDeviceByToken(token: String): PairedDevice? {
        if (token.isBlank()) return null
        return getPairedDevices().find { it.authToken == token }
    }

    fun renameDevice(id: String, newName: String) {
        val current = getPairedDevices().map {
            if (it.id == id) it.copy(name = newName) else it
        }
        saveDevicesList(current)
    }

    fun updateDeviceStatus(id: String, status: ConnectionStatus) {
        val current = getPairedDevices().map {
            if (it.id == id) it.copy(status = status, lastConnectedTime = System.currentTimeMillis()) else it
        }
        saveDevicesList(current)
    }

    fun removeDevice(id: String) {
        // Complete credential invalidation
        val current = getPairedDevices().filter { it.id != id }
        saveDevicesList(current)
    }

    private fun saveDevicesList(list: List<PairedDevice>) {
        val json = gson.toJson(list)
        prefs.edit().putString("paired_devices_list", json).apply()
    }

    // --- Recipient Device Permissions ---

    fun getDevicePermissions(): DevicePermissions {
        val json = prefs.getString("device_permissions", null) ?: return DevicePermissions()
        return try {
            gson.fromJson(json, DevicePermissions::class.java) ?: DevicePermissions()
        } catch (e: Exception) {
            DevicePermissions()
        }
    }

    fun saveDevicePermissions(permissions: DevicePermissions) {
        val json = gson.toJson(permissions)
        prefs.edit().putString("device_permissions", json).apply()
    }
}
