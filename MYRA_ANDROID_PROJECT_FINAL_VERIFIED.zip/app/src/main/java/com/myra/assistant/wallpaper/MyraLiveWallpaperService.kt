package com.myra.assistant.wallpaper

import android.service.wallpaper.WallpaperService

/**
 * Official Android WallpaperService for MYRA AI Live Wallpaper.
 */
class MyraLiveWallpaperService : WallpaperService() {

    override fun onCreateEngine(): Engine {
        return MyraWallpaperEngine()
    }

    inner class MyraWallpaperEngine : WallpaperService.Engine() {
        private val prefs = MyraWallpaperPreferences.getInstance(this@MyraLiveWallpaperService)
        private val handler = android.os.Handler(android.os.Looper.getMainLooper())
        private var isVisible = false
        private var width = 1080
        private var height = 1920

        // Animation timestamps
        private var lastFrameTime = android.os.SystemClock.uptimeMillis()
        private var animTimeSec = 0f
        private var pulseProgress = 0f

        // Interactive Touch Ripple
        private var rippleX = -1f
        private var rippleY = -1f
        private var rippleRadius = 0f
        private var rippleAlpha = 0f
        private var lastTapTime = 0L

        // Paints
        private val bgPaint = android.graphics.Paint()
        private val starPaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
        private val ringPaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            style = android.graphics.Paint.Style.STROKE
        }
        private val orbGlowPaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
        private val orbCorePaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
        private val earthAtmospherePaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
        private val earthBodyPaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
        private val earthGridPaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            style = android.graphics.Paint.Style.STROKE
        }
        private val portalPaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
        private val textPaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            textAlign = android.graphics.Paint.Align.CENTER
            typeface = android.graphics.Typeface.create(android.graphics.Typeface.SANS_SERIF, android.graphics.Typeface.BOLD)
        }
        private val wavePaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            strokeWidth = 3f
        }
        private val particlePaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)

        // Particles
        private class Particle(
            var x: Float,
            var y: Float,
            var vy: Float,
            var size: Float,
            var alpha: Float,
            var colorType: Int
        )
        private val particles = ArrayList<Particle>()

        // Radar sweep
        private var radarAngle = 0f

        private val frameRunnable = object : Runnable {
            override fun run() {
                drawFrame()
                if (isVisible) {
                    val fps = when (prefs.fps) {
                        WallpaperFPS.FPS_30 -> 33L
                        WallpaperFPS.FPS_60 -> 16L
                        WallpaperFPS.FPS_90 -> 11L
                        WallpaperFPS.FPS_120 -> 8L
                    }
                    handler.postDelayed(this, fps)
                }
            }
        }

        init {
            initParticles()
        }

        private fun initParticles() {
            particles.clear()
            val count = prefs.particleCount.count
            for (i in 0 until count) {
                particles.add(
                    Particle(
                        x = kotlin.random.Random.nextFloat() * width,
                        y = kotlin.random.Random.nextFloat() * height,
                        vy = -(40f + kotlin.random.Random.nextFloat() * 80f),
                        size = 1.5f + kotlin.random.Random.nextFloat() * 3.5f,
                        alpha = 0.2f + kotlin.random.Random.nextFloat() * 0.7f,
                        colorType = if (kotlin.random.Random.nextFloat() > 0.3f) 0 else 1
                    )
                )
            }
        }

        override fun onVisibilityChanged(visible: Boolean) {
            this.isVisible = visible
            if (visible) {
                lastFrameTime = android.os.SystemClock.uptimeMillis()
                initParticles()
                handler.post(frameRunnable)
            } else {
                handler.removeCallbacks(frameRunnable)
            }
        }

        override fun onSurfaceChanged(holder: android.view.SurfaceHolder?, format: Int, w: Int, h: Int) {
            super.onSurfaceChanged(holder, format, w, h)
            this.width = w
            this.height = h
            initParticles()
        }

        override fun onTouchEvent(event: android.view.MotionEvent) {
            if (event.action == android.view.MotionEvent.ACTION_DOWN) {
                val now = android.os.SystemClock.uptimeMillis()
                val x = event.x
                val y = event.y

                rippleX = x
                rippleY = y
                rippleRadius = 10f
                rippleAlpha = 0.8f

                val cy = height * 0.42f
                val distToOrb = kotlin.math.hypot((x - width / 2f).toDouble(), (y - cy).toDouble()).toFloat()

                if (distToOrb < 150f) {
                    launchMyraAssistant()
                } else if (now - lastTapTime < 350) {
                    launchMyraAssistant()
                }
                lastTapTime = now
            }
            super.onTouchEvent(event)
        }

        private fun launchMyraAssistant() {
            try {
                val intent = android.content.Intent(this@MyraLiveWallpaperService, com.myra.assistant.MainActivity::class.java).apply {
                    addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK or android.content.Intent.FLAG_ACTIVITY_CLEAR_TOP)
                }
                this@MyraLiveWallpaperService.startActivity(intent)
            } catch (e: Exception) {
                android.util.Log.e("MYRA_Wallpaper", "Failed to launch main activity", e)
            }
        }

        private fun drawFrame() {
            val holder = surfaceHolder ?: return
            var canvas: android.graphics.Canvas? = null
            try {
                canvas = holder.lockCanvas()
                if (canvas != null) {
                    val now = android.os.SystemClock.uptimeMillis()
                    val dt = ((now - lastFrameTime) / 1000f).coerceIn(0.001f, 0.1f)
                    lastFrameTime = now

                    val speedMult = prefs.speed.multiplier
                    animTimeSec += dt * speedMult
                    pulseProgress = (kotlin.math.sin(animTimeSec * 2f) * 0.5f + 0.5f)
                    radarAngle = (radarAngle + 45f * dt * speedMult) % 360f

                    renderWallpaperScene(canvas, dt)
                }
            } catch (e: Exception) {
                android.util.Log.e("MYRA_Wallpaper", "Error drawing frame", e)
            } finally {
                if (canvas != null) {
                    try {
                        holder.unlockCanvasAndPost(canvas)
                    } catch (e: Exception) {
                        android.util.Log.e("MYRA_Wallpaper", "Error unlocking canvas", e)
                    }
                }
            }
        }

        private fun renderWallpaperScene(canvas: android.graphics.Canvas, dt: Float) {
            val cx = width / 2f
            val cy = height * 0.42f

            // 1. Deep Space Void
            canvas.drawColor(android.graphics.Color.rgb(5, 7, 15))

            // 2. Holographic Earth Core
            if (prefs.showEarthHologram) {
                drawHolographicEarth(canvas, cx, height * 0.90f)
            }

            // 3. Ambient Stardust
            if (prefs.showParticles) {
                drawParticles(canvas, dt)
            }

            // 4. Rotating Cyber HUD Rings
            if (prefs.showHudRings) {
                drawCyberRings(canvas, cx, cy)
            }

            // 5. Central Breathing MYRA AI Orb
            drawCentralOrb(canvas, cx, cy)

            // 6. Sound Waveform Audio Aura
            if (prefs.showWaveform) {
                drawAudioWave(canvas, cx, cy + 180f)
            }

            // 7. Interactive Touch Ripple Effect
            if (rippleAlpha > 0.02f) {
                rippleRadius += 400f * dt
                rippleAlpha -= 1.2f * dt
                val rPaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                    style = android.graphics.Paint.Style.STROKE
                    strokeWidth = 4f
                    color = android.graphics.Color.argb((rippleAlpha * 255).toInt().coerceIn(0, 255), 0, 230, 255)
                }
                canvas.drawCircle(rippleX, rippleY, rippleRadius, rPaint)
            }
        }

        private fun drawHolographicEarth(canvas: android.graphics.Canvas, cx: Float, cy: Float) {
            val earthRadius = width * 0.58f
            earthAtmospherePaint.shader = android.graphics.RadialGradient(
                cx, cy, earthRadius * 1.25f,
                intArrayOf(
                    android.graphics.Color.argb(80, 0, 180, 255),
                    android.graphics.Color.argb(20, 0, 100, 200),
                    android.graphics.Color.TRANSPARENT
                ),
                floatArrayOf(0.7f, 0.9f, 1f),
                android.graphics.Shader.TileMode.CLAMP
            )
            canvas.drawCircle(cx, cy, earthRadius * 1.25f, earthAtmospherePaint)

            earthBodyPaint.shader = android.graphics.RadialGradient(
                cx, cy, earthRadius,
                intArrayOf(
                    android.graphics.Color.rgb(10, 25, 45),
                    android.graphics.Color.rgb(3, 8, 18)
                ),
                null,
                android.graphics.Shader.TileMode.CLAMP
            )
            canvas.drawCircle(cx, cy, earthRadius, earthBodyPaint)

            earthGridPaint.color = android.graphics.Color.argb(45, 0, 200, 255)
            earthGridPaint.strokeWidth = 1.8f

            val rotOffset = (animTimeSec * 12f) % (earthRadius * 2f)
            for (i in -3..3) {
                val lineX = cx + (i * (earthRadius / 3.5f)) + (rotOffset * 0.2f) - (earthRadius * 0.2f)
                if (lineX > cx - earthRadius && lineX < cx + earthRadius) {
                    canvas.drawLine(lineX, cy - earthRadius, lineX, cy + earthRadius, earthGridPaint)
                }
            }

            for (j in -2..2) {
                val lineY = cy + (j * (earthRadius / 3.2f))
                canvas.drawLine(cx - earthRadius, lineY, cx + earthRadius, lineY, earthGridPaint)
            }
        }

        private fun drawCyberRings(canvas: android.graphics.Canvas, cx: Float, cy: Float) {
            val r1 = 135f + pulseProgress * 6f
            val r2 = 170f - pulseProgress * 4f
            val r3 = 210f

            ringPaint.color = android.graphics.Color.argb(70, 0, 230, 255)
            ringPaint.strokeWidth = 2.5f
            canvas.drawCircle(cx, cy, r1, ringPaint)

            ringPaint.color = android.graphics.Color.argb(120, 0, 200, 255)
            ringPaint.strokeWidth = 4f
            val rect2 = android.graphics.RectF(cx - r2, cy - r2, cx + r2, cy + r2)
            canvas.drawArc(rect2, radarAngle, 75f, false, ringPaint)
            canvas.drawArc(rect2, radarAngle + 180f, 75f, false, ringPaint)

            ringPaint.color = android.graphics.Color.argb(40, 255, 255, 255)
            ringPaint.strokeWidth = 1.5f
            val rect3 = android.graphics.RectF(cx - r3, cy - r3, cx + r3, cy + r3)
            canvas.drawArc(rect3, -radarAngle * 1.5f, 40f, false, ringPaint)
            canvas.drawArc(rect3, -radarAngle * 1.5f + 120f, 40f, false, ringPaint)
            canvas.drawArc(rect3, -radarAngle * 1.5f + 240f, 40f, false, ringPaint)
        }

        private fun drawCentralOrb(canvas: android.graphics.Canvas, cx: Float, cy: Float) {
            val baseRadius = 85f
            val pulseRadius = baseRadius + (pulseProgress * 14f)

            orbGlowPaint.shader = android.graphics.RadialGradient(
                cx, cy, pulseRadius * 1.8f,
                intArrayOf(
                    android.graphics.Color.argb(180, 0, 240, 255),
                    android.graphics.Color.argb(90, 0, 130, 255),
                    android.graphics.Color.TRANSPARENT
                ),
                floatArrayOf(0.2f, 0.6f, 1f),
                android.graphics.Shader.TileMode.CLAMP
            )
            canvas.drawCircle(cx, cy, pulseRadius * 1.8f, orbGlowPaint)

            orbCorePaint.shader = android.graphics.RadialGradient(
                cx, cy, baseRadius,
                intArrayOf(
                    android.graphics.Color.WHITE,
                    android.graphics.Color.rgb(0, 220, 255),
                    android.graphics.Color.rgb(0, 110, 230)
                ),
                floatArrayOf(0f, 0.45f, 1f),
                android.graphics.Shader.TileMode.CLAMP
            )
            canvas.drawCircle(cx, cy, baseRadius, orbCorePaint)

            textPaint.color = android.graphics.Color.argb(220, 255, 255, 255)
            textPaint.textSize = 28f
            canvas.drawText("MYRA", cx, cy + 10f, textPaint)
        }

        private fun drawAudioWave(canvas: android.graphics.Canvas, cx: Float, cy: Float) {
            val radiusX = 180f
            for (i in -4..4) {
                val waveX = cx + (i * radiusX * 0.2f)
                val waveHeight = 60f + kotlin.math.sin(animTimeSec * 3f + i) * 35f
                wavePaint.shader = android.graphics.LinearGradient(
                    waveX, cy, waveX, cy - waveHeight,
                    android.graphics.Color.argb(120, 0, 230, 255),
                    android.graphics.Color.TRANSPARENT,
                    android.graphics.Shader.TileMode.CLAMP
                )
                canvas.drawLine(waveX, cy, waveX, cy - waveHeight, wavePaint)
            }
        }

        private fun drawParticles(canvas: android.graphics.Canvas, dt: Float) {
            val speedMult = prefs.speed.multiplier
            for (p in particles) {
                p.y += p.vy * dt * speedMult
                if (p.y < 0) {
                    p.y = height.toFloat()
                    p.x = kotlin.random.Random.nextFloat() * width
                    p.alpha = 0.8f
                }

                p.alpha -= 0.05f * dt
                if (p.alpha < 0.1f) p.alpha = 0.8f

                particlePaint.color = if (p.colorType == 0) {
                    android.graphics.Color.argb((p.alpha * 220).toInt(), 0, 220, 255)
                } else {
                    android.graphics.Color.argb((p.alpha * 220).toInt(), 255, 50, 90)
                }
                canvas.drawCircle(p.x, p.y, p.size, particlePaint)
            }
        }
    }
}

