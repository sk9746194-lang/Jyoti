# MYRA OFFLINE MODE & DETERMINISTIC VOICE GUIDE
*मायरा ऑफलाइन मोड एवं स्थानीय वॉयस कमांड्स निर्देशिका (2026 Edition)*

---

## 1. True Offline-First Architecture (सच्चा ऑफलाइन मॉडल)

जब आपका इंटरनेट बंद हो, फोन फ्लाइट मोड में हो, या जेमिनी का फ्री कोटा समाप्त हो गया हो, तब भी MYRA पूरी तरह से कार्य करती है। 

MYRA का **OfflineCommandEngine** सीधे Android OS के हार्डवेयर और सिस्टम सर्विस APIs का उपयोग करता है:

| ऑफलाइन फीचर | उपयोग की जाने वाली Android सर्विस / Intent | क्या इंटरनेट चाहिए? |
| :--- | :--- | :--- |
| **टॉर्च ऑन/ऑफ (Torch)** | `CameraManager.setTorchMode()` | ❌ नहीं (100% Offline) |
| **बैटरी स्थिति (Battery)** | `BatteryManager.EXTRA_LEVEL` | ❌ नहीं (100% Offline) |
| **समय व दिनांक (Time/Date)** | `java.util.Date`, `SimpleDateFormat` | ❌ नहीं (100% Offline) |
| **वॉल्यूम कंट्रोल (Volume)** | `AudioManager.adjustStreamVolume()` | ❌ नहीं (100% Offline) |
| **ऐप्स खोलना (Open Apps)** | `PackageManager.getLaunchIntentForPackage()` | ❌ नहीं (100% Offline) |
| **सेटिंग्स खोलना (Settings)** | `Settings.ACTION_WIFI_SETTINGS`, etc. | ❌ नहीं (100% Offline) |
| **स्थानीय नोट्स व मेमोरी** | `LocalMemoryRepository` (SQLite on-device) | ❌ नहीं (100% Offline) |
| **ऑफलाइन वॉयस रिकॉग्निशन** | Android `SpeechRecognizer` (Offline Language Pack) | ❌ नहीं (100% Offline) |
| **ऑफलाइन वॉयस बोलना (TTS)** | Android Native `TextToSpeech` (Hindi & English) | ❌ नहीं (100% Offline) |

---

## 2. ऑफलाइन कमांड्स की सूची (List of Offline Commands)

आप बिना इंटरनेट के हिंदी, हिंग्लिश या इंग्लिश में निम्नलिखित वाक्य बोल सकते हैं:

### A. टॉर्च और हार्डवेयर
- *"Torch on karo"* / *"Torch jalao"* / *"टॉर्च चालू करो"*
- *"Torch off karo"* / *"Torch bujhao"* / *"टॉर्च बंद करो"*

### B. बैटरी एवं फोन स्थिति
- *"Battery kitni hai?"* / *"Phone charge kitna hai?"* / *"बैटरी कितनी है?"*

### C. समय एवं तारीख
- *"Kitne baje hain?"* / *"Time kya hua hai?"* / *"समय क्या है?"*
- *"Aaj ki taarikh kya hai?"* / *"Aaj kaun sa din hai?"* / *"आज क्या तारीख है?"*

### D. आवाज व वॉल्यूम नियंत्रण
- *"Volume badhao"* / *"Aawaz zyada karo"* / *"वॉल्यूम बढ़ाओ"*
- *"Volume kam karo"* / *"वॉल्यूम कम करो"*
- *"Phone silent karo"* / *"Mute karo"* / *"म्यूट करो"*

### E. मोबाइल ऐप्स खोलना
- *"WhatsApp kholo"* / *"यूट्यूब खोलो"* / *"YouTube chalao"*
- *"Camera open karo"* / *"Gallery kholo"*
- *"Settings kholo"* / *"Calculator open karo"*
- *"Chrome browser open karo"* / *"Spotify kholo"*

### F. सेटिंग्स शॉर्टकट्स
- *"Wi-Fi setting kholo"*
- *"Bluetooth setting kholo"*
- *"Display setting kholo"*

### G. टास्क रोकना
- *"Ruk jao"* / *"Stop karo"* / *"Cancel karo"*

---

## 3. लोकल मेमोरी डेटाबेस (Local SQLite Memory)

- सभी नोट्स, बातचीत का इतिहास और उपयोगकर्ता की प्राथमिकताएं आपके फोन में `myra_local_memory.db` में स्टोर होती हैं।
- इसे कभी भी बिना आपकी सहमति के क्लाउड पर अपलोड नहीं किया जाता।
- आप Settings में जाकर किसी भी समय अपनी यादें देख सकते हैं, सर्च कर सकते हैं, JSON बैकअप ले सकते हैं या एक क्लिक में क्लियर कर सकते हैं।
