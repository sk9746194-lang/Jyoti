package com.myra.assistant.quota

import android.content.Context
import android.content.SharedPreferences
import android.util.Log

/**
 * Gemini Free-Quota Manager & Tracker for MYRA Assistant.
 *
 * GOOGLE GEMINI FREE-TIER REALITIES:
 * - Free tier typically provides 15 Requests Per Minute (RPM) and 1,500 Requests Per Day (RPD).
 * - Exact remaining quota is NOT exposed via an API header by Google.
 * - This manager tracks client-side request timestamps, detects HTTP 429 RESOURCE_EXHAUSTED,
 *   enforces cooldown periods, and shields the user from unexpected billing.
 * - Under NO circumstance does MYRA activate paid billing or switch silently to paid models.
 */
class GeminiQuotaHandler(context: Context) {

    companion object {
        private const val TAG = "MYRA_QuotaHandler"
        private const val PREFS_NAME = "myra_gemini_quota_tracker"
        private const val KEY_QUOTA_EXHAUSTED = "is_quota_exhausted"
        private const val KEY_EXHAUSTED_TIMESTAMP = "quota_exhausted_time"
        private const val KEY_REQUEST_COUNT_TODAY = "requests_today"
        private const val KEY_LAST_DAY_RESET = "last_day_reset_timestamp"
        private const val KEY_MINUTE_REQUESTS = "minute_requests_history"

        const val FREE_RPM_LIMIT = 15
        const val FREE_RPD_LIMIT = 1500
        const val COOLDOWN_MILLIS = 60_000L // 60-second cooldown for rate-limit 429
    }

    private val prefs: SharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    /**
     * Checks if the Gemini API quota is currently flagged as exhausted.
     * Auto-resets if the cooldown period has expired.
     */
    fun isQuotaExhausted(): Boolean {
        val isExhausted = prefs.getBoolean(KEY_QUOTA_EXHAUSTED, false)
        if (!isExhausted) return false

        val exhaustedTime = prefs.getLong(KEY_EXHAUSTED_TIMESTAMP, 0L)
        val elapsed = System.currentTimeMillis() - exhaustedTime

        if (elapsed > COOLDOWN_MILLIS) {
            // Cooldown finished, restore online eligibility
            clearQuotaExhausted()
            Log.i(TAG, "Rate limit cooldown expired. Restoring Gemini API eligibility.")
            return false
        }

        return true
    }

    /**
     * Flags quota as exhausted upon receiving HTTP 429 RESOURCE_EXHAUSTED.
     */
    fun recordQuotaExhausted() {
        prefs.edit()
            .putBoolean(KEY_QUOTA_EXHAUSTED, true)
            .putLong(KEY_EXHAUSTED_TIMESTAMP, System.currentTimeMillis())
            .apply()
        Log.w(TAG, "HTTP 429 detected. Quota exhausted flagged with ${COOLDOWN_MILLIS / 1000}s cooldown.")
    }

    fun clearQuotaExhausted() {
        prefs.edit()
            .putBoolean(KEY_QUOTA_EXHAUSTED, false)
            .remove(KEY_EXHAUSTED_TIMESTAMP)
            .apply()
    }

    /**
     * Returns remaining cooldown in seconds.
     */
    fun getRemainingCooldownSeconds(): Int {
        if (!isQuotaExhausted()) return 0
        val exhaustedTime = prefs.getLong(KEY_EXHAUSTED_TIMESTAMP, 0L)
        val remaining = COOLDOWN_MILLIS - (System.currentTimeMillis() - exhaustedTime)
        return if (remaining > 0) (remaining / 1000).toInt() else 0
    }

    /**
     * Records an outgoing Gemini request for local telemetry.
     */
    fun recordRequest() {
        val now = System.currentTimeMillis()
        val lastReset = prefs.getLong(KEY_LAST_DAY_RESET, 0L)

        val edit = prefs.edit()
        // Day reset check (24 hours)
        if (now - lastReset > 24 * 60 * 60 * 1000L) {
            edit.putInt(KEY_REQUEST_COUNT_TODAY, 1)
            edit.putLong(KEY_LAST_DAY_RESET, now)
        } else {
            val count = prefs.getInt(KEY_REQUEST_COUNT_TODAY, 0) + 1
            edit.putInt(KEY_REQUEST_COUNT_TODAY, count)
        }
        edit.apply()
    }

    fun getTodayRequestCount(): Int {
        return prefs.getInt(KEY_REQUEST_COUNT_TODAY, 0)
    }

    /**
     * Clear Hindi explanation of quota status for the user.
     */
    fun getStatusHindiMessage(): String {
        return if (isQuotaExhausted()) {
            val sec = getRemainingCooldownSeconds()
            "⚠️ Google Gemini फ्री कोटा अस्थायी रूप से समाप्त है (${sec}s कूलडाउन बाकी)। MYRA सुरक्षित रूप से ऑफलाइन कमांड मोड में कार्य कर रही है।"
        } else {
            "✓ Google Gemini फ्री टियर सामान्य है (आज ${getTodayRequestCount()} अनुरोध किए गए)।"
        }
    }
}
