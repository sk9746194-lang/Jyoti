package com.myra.assistant.data

import android.content.Context

enum class LearningTopic {
    MATHEMATICS,
    CODING,
    SCIENCE,
    ENGLISH_HINDI,
    GENERAL_KNOWLEDGE,
    GENERAL_EXPLANATION
}

/**
 * MYRA Learning Brain Manager
 * Formulates structured learning prompts and explanations for math, coding, science, language, and GK.
 */
class LearningBrainManager(private val context: Context) {

    /**
     * Constructs a tailored system instruction addition for learning mode.
     */
    fun getLearningInstruction(topic: LearningTopic = LearningTopic.GENERAL_EXPLANATION, simplifyLevel: Int = 1): String {
        val topicGuide = when (topic) {
            LearningTopic.MATHEMATICS -> "Show clear step-by-step calculations. Do not skip intermediate algebra or arithmetic steps. Verify the final answer."
            LearningTopic.CODING -> "Explain the code line by line with clean comments, best practices, time/space complexity, and common bug pitfalls."
            LearningTopic.SCIENCE -> "Use intuitive physical analogies, real-world examples, and precise scientific principles without fabricated jargon."
            LearningTopic.ENGLISH_HINDI -> "Teach vocabulary, pronunciation, grammar structures, and show both Hindi and English sentences side-by-side."
            LearningTopic.GENERAL_KNOWLEDGE -> "Provide verified historical, geographical, or current facts. If a fact is unverified or uncertain, explicitly state so."
            LearningTopic.GENERAL_EXPLANATION -> "Break down complex concepts into simple, easily digestible parts with relatable analogies."
        }

        val levelPrompt = if (simplifyLevel > 1) {
            "Explain in very simple terms as if explaining to a beginner student. Use everyday metaphors."
        } else {
            "Explain at an engaging, informative level with depth and examples."
        }

        return """
            [MYRA LEARNING BRAIN ACTIVE]
            $topicGuide
            $levelPrompt
            Always offer: 1) Concept explanation, 2) Step-by-step illustration, 3) Real-world example, 4) Follow-up practice question for the user.
        """.trimIndent()
    }
}
