package com.myra.assistant.offline

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import java.util.UUID

/**
 * LocalMemoryEntity — Room Database Entity for Local-Only Search Index.
 *
 * STRICT PRIVACY & CLOUD ISOLATION MANDATE:
 * - Stored 100% on-device in local Room SQLite storage.
 * - Indexed on content, category, timestamp, and composite tokens for zero-latency offline search.
 * - Strictly excluded from cloud sync, remote backup, and external network transmissions.
 */
@Entity(
    tableName = "local_memories",
    indices = [
        Index(value = ["content"], name = "idx_memories_content"),
        Index(value = ["category"], name = "idx_memories_category"),
        Index(value = ["timestamp"], name = "idx_memories_timestamp"),
        Index(value = ["category", "content"], name = "idx_memories_cat_content"),
        Index(value = ["search_tokens"], name = "idx_memories_tokens")
    ]
)
data class LocalMemoryEntity(
    @PrimaryKey
    @ColumnInfo(name = "id")
    val id: String = UUID.randomUUID().toString(),

    @ColumnInfo(name = "category")
    val category: String, // "preference", "project", "note", "fact", "companion"

    @ColumnInfo(name = "content")
    val content: String,

    @ColumnInfo(name = "timestamp")
    val timestamp: Long = System.currentTimeMillis(),

    @ColumnInfo(name = "is_pinned", defaultValue = "0")
    val isPinned: Boolean = false,

    @ColumnInfo(name = "search_tokens", defaultValue = "''")
    val searchTokens: String = ""
)
