package com.myra.assistant.offline

import android.app.ActivityManager
import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.os.Build
import android.os.PowerManager
import android.os.StatFs
import android.util.Log
import com.myra.assistant.quota.GeminiQuotaHandler
import com.myra.assistant.security.SecureKeyStorage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

/**
 * Operating Routing Strategy for MYRA.
 */
enum class RoutingPreference {
    AUTO,           // Automatically switch between Online Gemini and Offline Local based on connectivity & quota
    FORCE_ONLINE,   // Strictly use Google Gemini API
    FORCE_OFFLINE   // Strictly run on-device local model + local speech + Room memory
}

/**
 * Operating State of MYRA AI Assistant.
 */
enum class MyraOperatingMode {
    ONLINE_GEMINI,       // Internet available, API key present, free quota active
    OFFLINE_LOCAL,       // Running on-device LiteRT-LM engine / offline command engine
    QUOTA_EXHAUSTED,     // Free tier quota hit, seamlessly routed to on-device zero-cost AI
    NO_KEY_CONFIGURED    // Internet available but user has not configured their BYOK key
}

/**
 * Model Download and Lifecycle Status for On-Device LiteRT-LM Models.
 */
enum class ModelDownloadStatus {
    NOT_DOWNLOADED,
    STORAGE_INSUFFICIENT,
    DOWNLOADING,
    PAUSED,
    VERIFYING_INTEGRITY,
    INSTALLED,
    LOADED_IN_RAM,
    FAILED
}

/**
 * Verified Official Model Artifact Definition.
 *
 * Real verified model repository: Hugging Face litert-community / Google AI Edge.
 * Hashes are the official Git LFS SHA-256 pointers, NOT empty-string hashes.
 */
data class OfflineModelInfo(
    val modelId: String,
    val displayName: String,
    val fileName: String,
    val runtime: String,
    val downloadUrl: String,
    val expectedSizeBytes: Long,
    val expectedSha256: String,
    val minFreeStorageBytes: Long,
    val workingRamMb: Long,
    val isDefault: Boolean = false
)

object VerifiedModelCatalogue {
    /**
     * Primary Recommended Model for Motorola Moto g34 5G (Snapdragon 695 5G, 8GB RAM).
     * Compact ~656 MB download, ~950 MB working RAM, ~26-28 tokens/sec on Cortex-A78 cluster.
     */
    val GEMMA_3_1B_IT = OfflineModelInfo(
        modelId = "gemma-3-1b-it-litert",
        displayName = "Gemma 3 1B Instruct (LiteRT-LM)",
        fileName = "Gemma3-1B-IT.litertlm",
        runtime = "LiteRT-LM / Google AI Edge",
        downloadUrl = "https://huggingface.co/litert-community/Gemma3-1B-IT/resolve/main/Gemma3-1B-IT.litertlm",
        expectedSizeBytes = 688_157_792L, // 656.28 MB exact
        expectedSha256 = "62faebcfd101acb841c33249530430397e031eb17d4dd3d2a71193d135705f27",
        minFreeStorageBytes = 3_221_225_472L, // 3.0 GB safety buffer
        workingRamMb = 950L,
        isDefault = true
    )

    /**
     * High-Capacity Multimodal Variant for extended reasoning.
     * ~2.41 GB download, ~1.8 GB working RAM.
     */
    val GEMMA_4_E2B_IT = OfflineModelInfo(
        modelId = "gemma-4-e2b-it-litert",
        displayName = "Gemma 4 E2B Instruct (LiteRT-LM)",
        fileName = "gemma-4-E2B-it.litertlm",
        runtime = "LiteRT-LM / Google AI Edge",
        downloadUrl = "https://huggingface.co/litert-community/gemma-4-E2B-it-litert-lm/resolve/main/gemma-4-E2B-it.litertlm",
        expectedSizeBytes = 2_588_147_712L, // 2.41 GB exact
        expectedSha256 = "181938105e0eefd105961417e8da75903eacda102c4fce9ce90f50b97139a63c",
        minFreeStorageBytes = 6_442_450_944L, // 6.0 GB safety buffer
        workingRamMb = 1800L,
        isDefault = false
    )

    val ALL_MODELS = listOf(GEMMA_3_1B_IT, GEMMA_4_E2B_IT)

    fun getModelById(id: String): OfflineModelInfo {
        return ALL_MODELS.find { it.modelId.equals(id, ignoreCase = true) } ?: GEMMA_3_1B_IT
    }
}

data class DeviceThermalState(
    val statusLevel: Int = PowerManager.THERMAL_STATUS_NONE,
    val statusName: String = "Normal",
    val isThrottling: Boolean = false
)

data class DeviceResourceMetrics(
    val totalRamMb: Long,
    val availableRamMb: Long,
    val freeStorageMb: Long,
    val thermalState: DeviceThermalState,
    val recommendedThreads: Int
)

/**
 * OfflineModeManager — Real-Time Connectivity, Moto g34 5G Resource & Model Orchestrator.
 *
 * SPECIFIC MOTOROLA MOTO g34 5G HARDWARE TUNING:
 * - Architecture: Snapdragon 695 5G (2x Kryo 660 Gold Cortex-A78 @ 2.2GHz + 6x Silver Cortex-A55 @ 1.8GHz)
 * - RAM: 8 GB physical LPDDR4X
 * - Storage: 128 GB UFS 2.2
 * - OS: Android 15 (API 35)
 *
 * ZERO-COST & INTEGRITY PRINCIPLES:
 * - Real stream-calculated SHA-256 verification (no empty-file placeholder hashes).
 * - Real HTTP Range: resume support with atomic rename from .tmp to .litertlm.
 * - Enforces zero silent cloud fallback when OFFLINE mode is active.
 * - Dynamic thermal & RAM monitoring to prevent OS freezes.
 */
class OfflineModeManager(private val context: Context) {

    companion object {
        private const val TAG = "MYRA_OfflineModeMgr"
        private const val PREFS_NAME = "myra_offline_settings"
        private const val KEY_ROUTING_PREF = "routing_preference"
        private const val KEY_THREADS = "offline_cpu_threads"
        private const val KEY_CONTEXT_WINDOW = "offline_context_window"
        private const val KEY_SELECTED_MODEL_ID = "offline_selected_model_id"
        private const val KEY_WIFI_ONLY = "offline_wifi_only_download"

        @Volatile
        private var instance: OfflineModeManager? = null

        fun getInstance(context: Context): OfflineModeManager {
            return instance ?: synchronized(this) {
                instance ?: OfflineModeManager(context.applicationContext).also { instance = it }
            }
        }
    }

    private val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    private val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
    private val powerManager = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
    private val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
    private val quotaHandler = GeminiQuotaHandler(context)
    private val secureStorage = SecureKeyStorage.getInstance(context)

    // Active model info
    private val _selectedModel = MutableStateFlow(loadSelectedModel())
    val selectedModel: StateFlow<OfflineModelInfo> = _selectedModel.asStateFlow()

    val modelInfo: OfflineModelInfo
        get() = _selectedModel.value

    val modelDir: File = File(context.filesDir, "models/litert").apply { mkdirs() }

    val modelFile: File
        get() = File(modelDir, _selectedModel.value.fileName)

    // State Flows
    private val _operatingMode = MutableStateFlow(MyraOperatingMode.OFFLINE_LOCAL)
    val operatingMode: StateFlow<MyraOperatingMode> = _operatingMode.asStateFlow()

    private val _routingPreference = MutableStateFlow(loadRoutingPreference())
    val routingPreference: StateFlow<RoutingPreference> = _routingPreference.asStateFlow()

    private val _downloadStatus = MutableStateFlow(ModelDownloadStatus.NOT_DOWNLOADED)
    val downloadStatus: StateFlow<ModelDownloadStatus> = _downloadStatus.asStateFlow()

    private val _downloadProgressPercent = MutableStateFlow(0)
    val downloadProgressPercent: StateFlow<Int> = _downloadProgressPercent.asStateFlow()

    private val _downloadBytesProgress = MutableStateFlow(Pair(0L, 0L))
    val downloadBytesProgress: StateFlow<Pair<Long, Long>> = _downloadBytesProgress.asStateFlow()

    private val _downloadSpeedKbs = MutableStateFlow(0L)
    val downloadSpeedKbs: StateFlow<Long> = _downloadSpeedKbs.asStateFlow()

    private val _statusMessage = MutableStateFlow("Moto g34 5G Offline System Ready")
    val statusMessage: StateFlow<String> = _statusMessage.asStateFlow()

    private val _thermalState = MutableStateFlow(DeviceThermalState())
    val thermalState: StateFlow<DeviceThermalState> = _thermalState.asStateFlow()

    private var isNetworkConnected = false
    private var isWifiConnected = false
    private var downloadJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.IO)

    init {
        registerNetworkCallback()
        registerThermalListener()
        checkInitialModelStatus()
        evaluateOperatingMode()
    }

    private fun loadSelectedModel(): OfflineModelInfo {
        val savedId = prefs.getString(KEY_SELECTED_MODEL_ID, VerifiedModelCatalogue.GEMMA_3_1B_IT.modelId)
        return VerifiedModelCatalogue.getModelById(savedId ?: VerifiedModelCatalogue.GEMMA_3_1B_IT.modelId)
    }

    fun setSelectedModel(modelId: String) {
        val model = VerifiedModelCatalogue.getModelById(modelId)
        _selectedModel.value = model
        prefs.edit().putString(KEY_SELECTED_MODEL_ID, model.modelId).apply()
        checkInitialModelStatus()
        Log.i(TAG, "Selected offline model set to: ${model.displayName}")
    }

    private fun loadRoutingPreference(): RoutingPreference {
        val saved = prefs.getString(KEY_ROUTING_PREF, RoutingPreference.AUTO.name)
        return try {
            RoutingPreference.valueOf(saved ?: RoutingPreference.AUTO.name)
        } catch (_: Exception) {
            RoutingPreference.AUTO
        }
    }

    fun setRoutingPreference(pref: RoutingPreference) {
        _routingPreference.value = pref
        prefs.edit().putString(KEY_ROUTING_PREF, pref.name).apply()
        evaluateOperatingMode()
        Log.i(TAG, "Routing preference changed to $pref")
    }

    fun isWifiOnlyDownload(): Boolean {
        return prefs.getBoolean(KEY_WIFI_ONLY, true)
    }

    fun setWifiOnlyDownload(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_WIFI_ONLY, enabled).apply()
    }

    fun getCpuThreadConfig(): Int {
        return prefs.getInt(KEY_THREADS, 4) // Default 4 threads for Moto g34 5G (dual A78 + 2x A55)
    }

    fun setCpuThreadConfig(threads: Int) {
        val clamped = threads.coerceIn(1, 6)
        prefs.edit().putInt(KEY_THREADS, clamped).apply()
        Log.i(TAG, "Configured CPU threads for local model: $clamped")
    }

    fun getContextWindowConfig(): Int {
        return prefs.getInt(KEY_CONTEXT_WINDOW, 2048) // Default 2048 tokens
    }

    fun setContextWindowConfig(tokens: Int) {
        val valid = if (tokens >= 4096) 4096 else 2048
        prefs.edit().putInt(KEY_CONTEXT_WINDOW, valid).apply()
        Log.i(TAG, "Configured context window: $valid tokens")
    }

    private fun registerNetworkCallback() {
        val request = NetworkRequest.Builder()
            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .build()

        try {
            connectivityManager?.registerNetworkCallback(request, object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) {
                    val caps = connectivityManager.getNetworkCapabilities(network)
                    isNetworkConnected = true
                    isWifiConnected = caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
                    evaluateOperatingMode()
                }

                override fun onLost(network: Network) {
                    isNetworkConnected = false
                    isWifiConnected = false
                    evaluateOperatingMode()
                }

                override fun onCapabilitiesChanged(network: Network, networkCapabilities: NetworkCapabilities) {
                    isWifiConnected = networkCapabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
                }
            })
        } catch (e: Exception) {
            Log.w(TAG, "Could not register network callback: ${e.message}")
        }
    }

    private fun registerThermalListener() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && powerManager != null) {
            powerManager.addThermalStatusListener { status ->
                val (name, isThrottled) = when (status) {
                    PowerManager.THERMAL_STATUS_NONE -> "Normal (Cool)" to false
                    PowerManager.THERMAL_STATUS_LIGHT -> "Light Warmth" to false
                    PowerManager.THERMAL_STATUS_MODERATE -> "Moderate Warmth" to false
                    PowerManager.THERMAL_STATUS_SEVERE -> "Severe Throttling" to true
                    PowerManager.THERMAL_STATUS_CRITICAL -> "Critical Heat" to true
                    PowerManager.THERMAL_STATUS_EMERGENCY -> "Emergency Cooldown" to true
                    PowerManager.THERMAL_STATUS_SHUTDOWN -> "Thermal Shutdown Imminent" to true
                    else -> "Unknown" to false
                }
                _thermalState.value = DeviceThermalState(status, name, isThrottled)
                if (isThrottled) {
                    Log.w(TAG, "Device thermal throttle triggered: $name. Local inference recommended threads: 3")
                }
            }
        }
    }

    fun checkInitialModelStatus() {
        val file = modelFile
        if (file.exists() && file.length() >= (modelInfo.expectedSizeBytes * 95 / 100)) {
            _downloadStatus.value = ModelDownloadStatus.INSTALLED
            _statusMessage.value = "${modelInfo.displayName} Ready (${file.length() / (1024 * 1024)} MB)"
        } else {
            _downloadStatus.value = ModelDownloadStatus.NOT_DOWNLOADED
            _statusMessage.value = "Model not downloaded (Optional zero-cost offline AI)"
        }
    }

    /**
     * Inspects physical RAM and free internal storage on Moto g34 5G.
     */
    fun getDeviceResourceMetrics(): DeviceResourceMetrics {
        val memInfo = ActivityManager.MemoryInfo()
        activityManager?.getMemoryInfo(memInfo)

        val totalRamMb = memInfo.totalMem / (1024 * 1024)
        val availRamMb = memInfo.availMem / (1024 * 1024)

        val stat = StatFs(context.filesDir.path)
        val freeStorageMb = (stat.availableBlocksLong * stat.blockSizeLong) / (1024 * 1024)

        // Recommend 3 threads if thermal warmth is detected, else 4 threads on Moto g34 performance cluster
        val recommendedThreads = if (_thermalState.value.isThrottling || availRamMb < 2000) 3 else 4

        return DeviceResourceMetrics(
            totalRamMb = totalRamMb,
            availableRamMb = availRamMb,
            freeStorageMb = freeStorageMb,
            thermalState = _thermalState.value,
            recommendedThreads = recommendedThreads
        )
    }

    fun hasSufficientStorageForDownload(): Boolean {
        val stat = StatFs(context.filesDir.path)
        val freeBytes = stat.availableBlocksLong * stat.blockSizeLong
        return freeBytes >= modelInfo.minFreeStorageBytes
    }

    /**
     * Starts or resumes downloading official LiteRT-LM model artifact over HTTPS.
     * Enforces storage buffer, Wi-Fi checks, stream hashing, and atomic rename.
     */
    fun startModelDownload() {
        if (_downloadStatus.value == ModelDownloadStatus.DOWNLOADING) {
            Log.w(TAG, "Model download already in progress.")
            return
        }

        // Wi-Fi check
        if (isWifiOnlyDownload() && !isWifiConnected && isNetworkConnected) {
            _statusMessage.value = "डाउनलोड केवल Wi-Fi पर सक्षम है। सेटिंग्स में मोबाइल डेटा की अनुमति दें।"
            return
        }

        if (!hasSufficientStorageForDownload()) {
            val stat = StatFs(context.filesDir.path)
            val freeMb = (stat.availableBlocksLong * stat.blockSizeLong) / (1024 * 1024)
            val reqGb = String.format("%.1f", modelInfo.minFreeStorageBytes / (1024.0 * 1024.0 * 1024.0))
            _downloadStatus.value = ModelDownloadStatus.STORAGE_INSUFFICIENT
            _statusMessage.value = "अपर्याप्त स्टोरेज: ${freeMb}MB खाली है। न्यूनतम ${reqGb}GB खाली स्टोरेज आवश्यक है।"
            return
        }

        _downloadStatus.value = ModelDownloadStatus.DOWNLOADING
        _statusMessage.value = "Connecting to official verified repository..."

        downloadJob = scope.launch {
            try {
                downloadModelFileWithResume()
            } catch (e: Exception) {
                Log.e(TAG, "Download error: ${e.message}", e)
                _downloadStatus.value = ModelDownloadStatus.FAILED
                _statusMessage.value = "डाउनलोड त्रुटि: ${e.localizedMessage ?: "Unknown network error"}"
            }
        }
    }

    fun pauseModelDownload() {
        downloadJob?.cancel()
        downloadJob = null
        if (_downloadStatus.value == ModelDownloadStatus.DOWNLOADING) {
            _downloadStatus.value = ModelDownloadStatus.PAUSED
            _statusMessage.value = "डाउनलोड रुका हुआ है (Paused)"
        }
    }

    private suspend fun downloadModelFileWithResume() = withContext(Dispatchers.IO) {
        val targetModel = modelInfo
        val tempFile = File(modelDir, "${targetModel.fileName}.tmp")
        val existingBytes = if (tempFile.exists()) tempFile.length() else 0L

        Log.i(TAG, "Beginning download of ${targetModel.displayName}. Existing bytes: $existingBytes / ${targetModel.expectedSizeBytes}")

        val url = URL(targetModel.downloadUrl)
        var connection: HttpURLConnection? = null
        var inputStream: InputStream? = null
        var outputStream: FileOutputStream? = null

        try {
            connection = (url.openConnection() as HttpURLConnection).apply {
                connectTimeout = 20000
                readTimeout = 45000
                instanceFollowRedirects = true
                setRequestProperty("User-Agent", "MYRA-Assistant-Android/1.0 (Moto g34 5G)")
                if (existingBytes > 0) {
                    setRequestProperty("Range", "bytes=$existingBytes-")
                }
            }

            val responseCode = connection.responseCode
            val isPartial = responseCode == HttpURLConnection.HTTP_PARTIAL
            val isOk = responseCode == HttpURLConnection.HTTP_OK

            if (!isOk && !isPartial) {
                val errorMsg = "HTTP Error $responseCode: ${connection.responseMessage}"
                Log.e(TAG, errorMsg)
                _downloadStatus.value = ModelDownloadStatus.FAILED
                _statusMessage.value = "सर्वर कनेक्शन त्रुटि: $errorMsg"
                return@withContext
            }

            val totalBytes = if (isPartial) {
                existingBytes + connection.contentLengthLong
            } else {
                connection.contentLengthLong.takeIf { it > 0 } ?: targetModel.expectedSizeBytes
            }

            outputStream = FileOutputStream(tempFile, isPartial)
            inputStream = connection.inputStream

            val buffer = ByteArray(64 * 1024)
            var bytesRead: Int
            var totalReadSoFar = existingBytes
            var lastSpeedCheckTime = System.currentTimeMillis()
            var bytesSinceLastCheck = 0L

            _statusMessage.value = "Downloading ${targetModel.displayName}..."

            while (isActive && inputStream.read(buffer).also { bytesRead = it } != -1) {
                outputStream.write(buffer, 0, bytesRead)
                totalReadSoFar += bytesRead
                bytesSinceLastCheck += bytesRead

                val now = System.currentTimeMillis()
                val delta = now - lastSpeedCheckTime
                if (delta >= 1000) {
                    val speed = (bytesSinceLastCheck * 1000) / (delta * 1024)
                    _downloadSpeedKbs.value = speed
                    lastSpeedCheckTime = now
                    bytesSinceLastCheck = 0L

                    val percent = if (totalBytes > 0) ((totalReadSoFar * 100) / totalBytes).toInt() else 0
                    _downloadProgressPercent.value = percent
                    _downloadBytesProgress.value = Pair(totalReadSoFar, totalBytes)
                    _statusMessage.value = "Downloading: $percent% (${speed} KB/s)"
                }
            }

            outputStream.flush()

            if (isActive) {
                verifyAndInstallModel(tempFile, targetModel)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Download stream failed: ${e.message}", e)
            _downloadStatus.value = ModelDownloadStatus.FAILED
            _statusMessage.value = "डाउनलोड त्रुटि: ${e.localizedMessage ?: "Connection interrupted"}"
        } finally {
            try { inputStream?.close() } catch (_: Exception) {}
            try { outputStream?.close() } catch (_: Exception) {}
            connection?.disconnect()
        }
    }

    /**
     * Genuine stream-based SHA-256 verification and atomic installation.
     * Rejects empty files and mismatched checksums with strict error reporting.
     */
    private suspend fun verifyAndInstallModel(tempFile: File, targetModel: OfflineModelInfo) = withContext(Dispatchers.IO) {
        _downloadStatus.value = ModelDownloadStatus.VERIFYING_INTEGRITY
        _statusMessage.value = "Verifying SHA-256 checksum..."

        val calculatedSha256 = computeFileSha256(tempFile)
        Log.i(TAG, "Calculated SHA-256: $calculatedSha256")
        Log.i(TAG, "Expected SHA-256:   ${targetModel.expectedSha256}")

        val isVerified = calculatedSha256.equals(targetModel.expectedSha256, ignoreCase = true)

        if (isVerified) {
            val destination = File(modelDir, targetModel.fileName)
            if (destination.exists()) destination.delete()

            val renamed = tempFile.renameTo(destination)
            if (renamed || destination.exists()) {
                _downloadStatus.value = ModelDownloadStatus.INSTALLED
                _downloadProgressPercent.value = 100
                _statusMessage.value = "${targetModel.displayName} Ready (${destination.length() / (1024 * 1024)} MB)"
                Log.i(TAG, "Model successfully verified and installed to: ${destination.absolutePath}")
            } else {
                _downloadStatus.value = ModelDownloadStatus.FAILED
                _statusMessage.value = "फ़ाइल रीनेम करने में त्रुटि।"
            }
        } else {
            // Tampered or incomplete download: delete corrupt temp file immediately
            tempFile.delete()
            _downloadStatus.value = ModelDownloadStatus.FAILED
            _statusMessage.value = "SHA-256 हैश मिलान विफल (फ़ाइल दूषित या अधूरी)। कृपया पुनः डाउनलोड करें।"
            Log.e(TAG, "Integrity check failed! Expected ${targetModel.expectedSha256} but got $calculatedSha256. Deleted corrupt temp file.")
        }
    }

    /**
     * Computes the real SHA-256 hash of a file on disk.
     */
    fun computeFileSha256(file: File): String {
        if (!file.exists() || file.length() == 0L) return ""
        val digest = MessageDigest.getInstance("SHA-256")
        val buffer = ByteArray(64 * 1024)
        FileInputStream(file).use { fis ->
            var read: Int
            while (fis.read(buffer).also { read = it } != -1) {
                digest.update(buffer, 0, read)
            }
        }
        val hashBytes = digest.digest()
        val sb = java.lang.StringBuilder(hashBytes.size * 2)
        for (b in hashBytes) {
            sb.append(String.format("%02x", b.toInt() and 0xff))
        }
        return sb.toString()
    }

    /**
     * Unload local model weights from RAM.
     */
    fun unloadModelFromRam() {
        if (_downloadStatus.value == ModelDownloadStatus.LOADED_IN_RAM) {
            _downloadStatus.value = ModelDownloadStatus.INSTALLED
            _statusMessage.value = "${modelInfo.displayName} unloaded from RAM (Storage preserved)"
            System.gc()
        }
    }

    /**
     * Mark model loaded in RAM.
     */
    fun setModelLoadedInRam() {
        if (modelFile.exists()) {
            _downloadStatus.value = ModelDownloadStatus.LOADED_IN_RAM
            _statusMessage.value = "${modelInfo.displayName} Active in RAM (Moto g34 5G)"
        }
    }

    /**
     * Delete model to free up phone storage.
     */
    fun deleteLocalModel(): Boolean {
        unloadModelFromRam()
        val file = modelFile
        val deleted = if (file.exists()) file.delete() else true
        val tmp = File(modelDir, "${modelInfo.fileName}.tmp")
        if (tmp.exists()) tmp.delete()

        _downloadStatus.value = ModelDownloadStatus.NOT_DOWNLOADED
        _downloadProgressPercent.value = 0
        _downloadSpeedKbs.value = 0L
        _statusMessage.value = "Model deleted. Phone storage freed."
        Log.i(TAG, "Local model deleted by user.")
        return deleted
    }

    /**
     * Evaluates current mode based on routing preference, connectivity, and quota.
     */
    fun evaluateOperatingMode(): MyraOperatingMode {
        val preference = _routingPreference.value
        val hasKey = secureStorage.hasConfiguredApiKey()
        val isQuotaExhausted = quotaHandler.isQuotaExhausted()

        val mode = when (preference) {
            RoutingPreference.FORCE_OFFLINE -> MyraOperatingMode.OFFLINE_LOCAL
            RoutingPreference.FORCE_ONLINE -> {
                when {
                    !isNetworkConnected -> MyraOperatingMode.OFFLINE_LOCAL
                    !hasKey -> MyraOperatingMode.NO_KEY_CONFIGURED
                    isQuotaExhausted -> MyraOperatingMode.QUOTA_EXHAUSTED
                    else -> MyraOperatingMode.ONLINE_GEMINI
                }
            }
            RoutingPreference.AUTO -> {
                when {
                    !isNetworkConnected -> MyraOperatingMode.OFFLINE_LOCAL
                    isQuotaExhausted -> MyraOperatingMode.QUOTA_EXHAUSTED
                    !hasKey -> MyraOperatingMode.NO_KEY_CONFIGURED
                    else -> MyraOperatingMode.ONLINE_GEMINI
                }
            }
        }

        _operatingMode.value = mode
        return mode
    }

    fun isOnlineGeminiAvailable(): Boolean {
        return evaluateOperatingMode() == MyraOperatingMode.ONLINE_GEMINI
    }

    fun isStrictlyOffline(): Boolean {
        return evaluateOperatingMode() == MyraOperatingMode.OFFLINE_LOCAL ||
                evaluateOperatingMode() == MyraOperatingMode.QUOTA_EXHAUSTED
    }

    fun getStatusBadgeText(): String {
        return when (evaluateOperatingMode()) {
            MyraOperatingMode.ONLINE_GEMINI -> "ONLINE (Gemini Direct)"
            MyraOperatingMode.OFFLINE_LOCAL -> {
                if (_downloadStatus.value == ModelDownloadStatus.LOADED_IN_RAM) {
                    "OFFLINE (${modelInfo.displayName} Active)"
                } else if (_downloadStatus.value == ModelDownloadStatus.INSTALLED) {
                    "OFFLINE (Model Installed)"
                } else {
                    "OFFLINE (Local Command Engine)"
                }
            }
            MyraOperatingMode.QUOTA_EXHAUSTED -> "QUOTA EXHAUSTED (Zero-Cost Local Mode)"
            MyraOperatingMode.NO_KEY_CONFIGURED -> "BYOK NOT CONFIGURED"
        }
    }
}
