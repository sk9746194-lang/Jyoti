package com.myra.assistant.data

import android.content.Context

data class ProactiveSuggestion(
    val id: String,
    val type: String, // "task_reminder", "project_next_step", "daily_summary"
    val title: String,
    val message: String,
    val actionText: String
)

/**
 * MYRA Anticipate Engine
 * Provides helpful, non-intrusive proactive suggestions based on user-approved memories and pending tasks.
 * Strictly adheres to non-intrusive safety rules: No background calls, no continuous surveillance, fully user-toggleable.
 */
class AnticipateEngine(private val context: Context) {
    private val prefs = PreferencesManager(context)
    private val memoryManager = SmartMemoryManager(context)
    private val dailyLifeManager = DailyLifeManager(context)

    /**
     * Evaluates current state and returns high-value suggestions if enabled.
     */
    fun getSuggestions(): List<ProactiveSuggestion> {
        if (!prefs.isProactiveAnticipateEnabled) {
            return emptyList()
        }

        val suggestions = mutableListOf<ProactiveSuggestion>()

        // 1. Ongoing project next step suggestion
        val activeProj = prefs.activeProjectName
        val lastState = prefs.lastProjectState
        if (activeProj.isNotBlank() && lastState.isNotBlank()) {
            suggestions.add(
                ProactiveSuggestion(
                    id = "sug_proj_1",
                    type = "project_next_step",
                    title = "Ongoing Project: $activeProj",
                    message = "Aapka pichhla kaam '$lastState' par tha. Kya aap agla step continue karna chahenge?",
                    actionText = "Continue Project"
                )
            )
        }

        // 2. Pending tasks due today
        val pendingTasks = dailyLifeManager.getTasks(dailyLifeManager.getTodayDate()).filterNot { it.isCompleted }
        if (pendingTasks.isNotEmpty()) {
            val firstTask = pendingTasks.first()
            suggestions.add(
                ProactiveSuggestion(
                    id = "sug_task_${firstTask.id}",
                    type = "task_reminder",
                    title = "Pending Task Reminder",
                    message = "'${firstTask.title}' pending hai (Time: ${firstTask.timeDue}).",
                    actionText = "View Tasks"
                )
            )
        }

        // 3. Daily Briefing check
        if (pendingTasks.isEmpty()) {
            suggestions.add(
                ProactiveSuggestion(
                    id = "sug_daily_1",
                    type = "daily_summary",
                    title = "Daily Summary",
                    message = "Aaj aapke sabhi scheduled tasks up to date hain. Koi naya goal set karein?",
                    actionText = "Plan Day"
                )
            )
        }

        return suggestions
    }
}
