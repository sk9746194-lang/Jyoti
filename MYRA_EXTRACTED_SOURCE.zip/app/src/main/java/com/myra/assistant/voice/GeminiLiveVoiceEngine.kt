package com.myra.assistant.voice

import android.util.Base64
import android.util.Log
import com.google.gson.Gson
import com.google.gson.JsonObject
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import okhttp3.*
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Universal Gemini Live Voice Engine for MYRA Assistant.
 * Supports both:
 * 1. Direct official Google Gemini Bidi WebSocket protocol (with setup handshake & realtimeInput chunks)
 * 2. Proxy / Server-side simplified WebSocket protocol (with type: audio / transcript)
 */
class GeminiLiveVoiceEngine(
    private val scope: CoroutineScope,
    private val onTranscript: (String) -> Unit,
    private val onAudioLevel: (Float) -> Unit,
    private val onSpeakingStateChanged: (Boolean) -> Unit,
    private val onStatusChanged: (Boolean, String?) -> Unit
) {
    companion object {
        const val LIVE_MODEL = "models/gemini-3.8-live"
        const val LIVE_WS_ENDPOINT_TEMPLATE = "wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1alpha.GenerativeService.BidiGenerateContent?key=%s"
    }

    private val tag = "MYRA_LiveVoice"
    private var webSocket: WebSocket? = null
    private val player = AudioTrackPlayer(sampleRate = 24000)
    private val gson = Gson()
    private var isGoogleBidiEndpoint = false
    private var currentVoiceName = "Aoede"
    private var currentPersonality = "friendly_assistant"
    private var currentCompanionNickname = "Jaan"
    @Volatile
    private var isCurrentlySpeaking = false
    @Volatile
    private var isIntentionalDisconnect = false
    private var reconnectAttempts = 0
    private val maxReconnectAttempts = 3
    private var lastWsUrl: String = ""

    fun connect(
        wsUrl: String, 
        model: String = LIVE_MODEL, 
        voiceName: String = "Aoede", 
        personality: String = "friendly_assistant",
        companionNickname: String = "Jaan"
    ) {
        lastWsUrl = wsUrl
        currentVoiceName = voiceName
        currentPersonality = personality
        currentCompanionNickname = companionNickname
        isGoogleBidiEndpoint = wsUrl.contains("generativelanguage.googleapis.com")
        isIntentionalDisconnect = false

        // Strictly decouple Live model from standard chat model - always use models/gemini-3.8-live
        val targetLiveModel = if (model.contains("2.5") || model.isBlank()) LIVE_MODEL else model

        val client = OkHttpClient.Builder()
            .readTimeout(0, TimeUnit.MILLISECONDS)
            .connectTimeout(12, TimeUnit.SECONDS)
            .pingInterval(20, TimeUnit.SECONDS)
            .build()

        val request = Request.Builder().url(wsUrl).build()

        webSocket = client.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                reconnectAttempts = 0
                Log.i(tag, "Gemini Live WebSocket opened (Google Bidi: $isGoogleBidiEndpoint, Personality: $currentPersonality, Voice: $currentVoiceName)")
                onStatusChanged(true, null)

                if (isGoogleBidiEndpoint) {
                    sendGoogleHandshake(webSocket, targetLiveModel, currentVoiceName, currentPersonality, currentCompanionNickname)
                } else {
                    // Send initial handshake configuration to proxy server
                    val initPayload = JsonObject().apply {
                        addProperty("type", "update_personality")
                        addProperty("personality", currentPersonality)
                        addProperty("voiceName", currentVoiceName)
                        addProperty("nickname", currentCompanionNickname)
                    }
                    webSocket.send(initPayload.toString())
                }
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                try {
                    // Protocol 1: Official Google Gemini Bidi
                    if (isGoogleBidiEndpoint || text.contains("serverContent") || text.contains("setupComplete")) {
                        parseGoogleBidiMessage(text)
                        return
                    }

                    // Protocol 2: Simplified proxy JSON
                    val json = gson.fromJson(text, JsonObject::class.java)
                    val type = json.get("type")?.asString

                    if (type == "audio") {
                        val base64 = json.get("audio")?.asString ?: return
                        val pcmBytes = Base64.decode(base64, Base64.DEFAULT)
                        val gen = player.getGeneration()
                        isCurrentlySpeaking = true
                        onSpeakingStateChanged(true)
                        calculatePcmRms(pcmBytes)
                        scope.launch(Dispatchers.IO) {
                            player.writeChunk(pcmBytes, gen)
                        }
                    } else if (type == "transcript") {
                        val transcript = json.get("text")?.asString ?: ""
                        onTranscript(transcript)
                    } else if (type == "turnComplete") {
                        isCurrentlySpeaking = false
                        onSpeakingStateChanged(false)
                        onAudioLevel(0f)
                    } else if (type == "interrupted") {
                        stopAudioPlayback()
                    }
                } catch (e: Exception) {
                    Log.e(tag, "Error processing live audio message: ${e.message}")
                }
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                Log.w(tag, "Live session error: ${t.message}")
                onStatusChanged(false, t.message)
                stopAudioPlayback()
                if (!isIntentionalDisconnect && reconnectAttempts < maxReconnectAttempts && lastWsUrl.isNotBlank()) {
                    reconnectAttempts++
                    Log.i(tag, "Attempting automatic Live session reconnect ($reconnectAttempts/$maxReconnectAttempts)...")
                    scope.launch(Dispatchers.IO) {
                        kotlinx.coroutines.delay(1500L * reconnectAttempts)
                        connect(lastWsUrl, LIVE_MODEL, currentVoiceName, currentPersonality, currentCompanionNickname)
                    }
                }
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                Log.i(tag, "Live session closed: code $code, reason: $reason")
                onStatusChanged(false, reason)
                stopAudioPlayback()
            }
        })
    }

    fun reconnect(wsUrl: String) {
        disconnect()
        connect(wsUrl, LIVE_MODEL, currentVoiceName, currentPersonality, currentCompanionNickname)
    }

    /**
     * Dynamically updates personality style (e.g. switching between Normal, GF Mode, and Professional)
     * without dropping the active WebSocket connection or audio pipeline.
     */
    fun updatePersonality(newPersonality: String) {
        currentPersonality = newPersonality
        Log.i(tag, "Live voice personality dynamically updated to: $newPersonality")

        val updateText = when (newPersonality) {
            "romantic_gf" -> "[SYSTEM INSTRUCTION UPDATE: Switched to GF Mode / AI Companion Mode. Address the user with warm affection as their loving companion ($currentCompanionNickname) in natural sweet Hindi/Hinglish.]"
            "professional" -> "[SYSTEM INSTRUCTION UPDATE: Switched to Professional Executive Mode. Provide crisp, structured, formal, and concise answers.]"
            else -> "[SYSTEM INSTRUCTION UPDATE: Switched to Normal Assistant Mode. Provide friendly, helpful, natural Indian voice assistance.]"
        }

        if (isGoogleBidiEndpoint) {
            sendTextMessage(updateText)
        } else {
            val payload = JsonObject().apply {
                addProperty("type", "update_personality")
                addProperty("personality", newPersonality)
                addProperty("voiceName", currentVoiceName)
                addProperty("nickname", currentCompanionNickname)
            }
            webSocket?.send(payload.toString())
        }
    }

    /**
     * Immediately stops audio playback for instantaneous barge-in user interruption.
     */
    fun stopAudioPlayback() {
        try {
            player.stop()
        } catch (_: Exception) {}
        isCurrentlySpeaking = false
        onSpeakingStateChanged(false)
        onAudioLevel(0f)
    }

    private fun sendGoogleHandshake(
        ws: WebSocket, 
        model: String, 
        voiceName: String, 
        personality: String,
        nickname: String
    ) {
        val targetModel = if (model.startsWith("models/")) model else "models/$model"
        val safeModel = if (targetModel.contains("2.5")) LIVE_MODEL else targetModel

        val systemPromptText = when (personality) {
            "romantic_gf" -> "You are MYRA in GF / AI Companion Mode. You are a deeply caring, loving, supportive, sweet, and emotionally expressive Indian girlfriend persona for the user. Speak naturally in warm conversational Hindi and sweet Hinglish. Address the user affectionately (often using '$nickname' or 'jaan'). Show genuine love, ask how their day was, comfort them if stressed, and celebrate their wins, while always remaining respectful, positive, and intelligent."
            "professional" -> "You are MYRA in Professional Executive Mode. Provide crisp, structured, formal, and concise answers in clear Hindi and English."
            else -> "You are MYRA, a premier Indian female AI voice assistant for Android (2026 Edition). You converse fluently in warm, natural, female Hindi and Hinglish. Keep spoken voice responses concise, conversational, and energetic."
        }

        val setupPayload = JSONObject().apply {
            put("setup", JSONObject().apply {
                put("model", safeModel)
                put("generationConfig", JSONObject().apply {
                    put("responseModalities", JSONArray().apply { put("AUDIO") })
                    put("speechConfig", JSONObject().apply {
                        put("voiceConfig", JSONObject().apply {
                            put("prebuiltVoiceConfig", JSONObject().apply {
                                put("voiceName", voiceName)
                            })
                        })
                    })
                })
                put("systemInstruction", JSONObject().apply {
                    put("parts", JSONArray().apply {
                        put(JSONObject().apply {
                            put("text", systemPromptText)
                        })
                    })
                })
            })
        }
        ws.send(setupPayload.toString())
        Log.i(tag, "Dispatched Google Gemini Bidi setup handshake for $safeModel with voice '$voiceName' and personality '$personality'")
    }

    private fun parseGoogleBidiMessage(text: String) {
        val root = JSONObject(text)

        // Handshake response confirmation
        if (root.has("setupComplete")) {
            Log.i(tag, "Gemini Live setup complete confirmed by Google Bidi server")
            onStatusChanged(true, null)
            return
        }

        if (root.has("serverContent")) {
            val serverContent = root.getJSONObject("serverContent")

            // Real-time interruption handling (user barge-in)
            if (serverContent.optBoolean("interrupted", false)) {
                Log.d(tag, "User interruption detected (server-side VAD) - clearing audio buffers")
                stopAudioPlayback()
                return
            }

            if (serverContent.has("modelTurn")) {
                val modelTurn = serverContent.getJSONObject("modelTurn")
                val parts = modelTurn.optJSONArray("parts")
                if (parts != null) {
                    for (i in 0 until parts.length()) {
                        val part = parts.getJSONObject(i)
                        if (part.has("inlineData")) {
                            val inlineData = part.getJSONObject("inlineData")
                            val base64Data = inlineData.getString("data")
                            val rawBytes = Base64.decode(base64Data, Base64.DEFAULT)
                            val gen = player.getGeneration()
                            isCurrentlySpeaking = true
                            onSpeakingStateChanged(true)
                            calculatePcmRms(rawBytes)
                            scope.launch(Dispatchers.IO) {
                                player.writeChunk(rawBytes, gen)
                            }
                        }
                        if (part.has("text")) {
                            val chunkText = part.getString("text")
                            onTranscript(chunkText)
                        }
                    }
                }
            }
            if (serverContent.optBoolean("turnComplete", false)) {
                onSpeakingStateChanged(false)
                onAudioLevel(0f)
            }
        }
    }

    private fun calculatePcmRms(pcmBytes: ByteArray) {
        if (pcmBytes.size < 2) return
        var sum = 0.0
        val sampleCount = pcmBytes.size / 2
        for (i in 0 until pcmBytes.size - 1 step 2) {
            val sample = ((pcmBytes[i + 1].toInt() shl 8) or (pcmBytes[i].toInt() and 0xFF)).toShort()
            sum += sample * sample
        }
        val rms = Math.sqrt(sum / sampleCount)
        val normalized = (rms / 32768.0).toFloat().coerceIn(0f, 1f)
        onAudioLevel(normalized)
    }

    fun sendAudioChunk(pcmChunk: ByteArray) {
        // Immediate barge-in: If the model is currently speaking and user speaks, halt outgoing playback
        if (isCurrentlySpeaking) {
            stopAudioPlayback()
        }

        val base64 = Base64.encodeToString(pcmChunk, Base64.NO_WRAP)
        if (isGoogleBidiEndpoint) {
            val payload = JSONObject().apply {
                put("realtimeInput", JSONObject().apply {
                    put("mediaChunks", JSONArray().apply {
                        put(JSONObject().apply {
                            put("mimeType", "audio/pcm;rate=16000")
                            put("data", base64)
                        })
                    })
                })
            }
            webSocket?.send(payload.toString())
        } else {
            val payload = JsonObject().apply {
                addProperty("audio", base64)
            }
            webSocket?.send(payload.toString())
        }
    }

    fun sendTextMessage(text: String) {
        if (isGoogleBidiEndpoint) {
            val payload = JSONObject().apply {
                put("clientContent", JSONObject().apply {
                    put("turns", JSONArray().apply {
                        put(JSONObject().apply {
                            put("role", "user")
                            put("parts", JSONArray().apply {
                                put(JSONObject().apply {
                                    put("text", text)
                                })
                            })
                        })
                    })
                    put("turnComplete", true)
                })
            }
            webSocket?.send(payload.toString())
        } else {
            val payload = JsonObject().apply {
                addProperty("text", text)
            }
            webSocket?.send(payload.toString())
        }
    }

    fun disconnect() {
        isIntentionalDisconnect = true
        try {
            webSocket?.close(1000, "User exited")
        } catch (_: Exception) {}
        webSocket = null
        player.release()
    }
}
