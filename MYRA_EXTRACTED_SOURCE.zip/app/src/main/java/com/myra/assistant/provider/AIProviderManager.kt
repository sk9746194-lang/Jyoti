package com.myra.assistant.provider

import android.content.Context
import android.util.Log
import com.myra.assistant.offline.MyraOperatingMode
import com.myra.assistant.offline.OfflineCommandEngine
import com.myra.assistant.offline.OfflineModeManager
import com.myra.assistant.offline.RoutingPreference
import com.myra.assistant.quota.AIRequestCache
import com.myra.assistant.quota.ConversationContextManager
import com.myra.assistant.quota.GeminiQuotaHandler
import com.myra.assistant.security.SecureKeyStorage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * AIProviderManager — Central Orchestrator for MYRA's Zero-Cost AI Routing.
 *
 * ROUTING MODES:
 * 1. FORCE_OFFLINE: Strictly routes to local hardware command engine or on-device LiteRT-LM model.
 *    Never touches network.
 * 2. FORCE_ONLINE: Strictly uses official Google Gemini API (BYOK direct).
 * 3. AUTO: Seamless zero-cost auto-failover:
 *    - Instant hardware commands (0ms, 0 tokens)
 *    - Cache hits (0ms, 0 tokens)
 *    - Official Gemini API when online & quota available
 *    - Seamless failover to on-device Gemma 3 1B LiteRT-LM model if offline or quota exhausted
 *    - Honest guidance if model is not yet installed (Never returns fake AI text)
 *
 * PERSONALITY & MEMORY PRESERVATION:
 * - Passes active system instruction (Assistant, Companion/GF Mode with nickname, or Pro)
 *   and isolated Room memories to both online and offline models.
 */
class AIProviderManager(private val context: Context) {

    companion object {
        private const val TAG = "MYRA_ProviderManager"

        @Volatile
        private var instance: AIProviderManager? = null

        fun getInstance(context: Context): AIProviderManager {
            return instance ?: synchronized(this) {
                instance ?: AIProviderManager(context.applicationContext).also { instance = it }
            }
        }
    }

    private val geminiDirectProvider = GeminiDirectProvider(context)
    private val optionalBackendProvider = OptionalSecureBackendProvider(context)
    val localModelProvider = LocalModelProvider(context)
    private val offlineCommandEngine = OfflineCommandEngine(context)

    private val quotaHandler = GeminiQuotaHandler(context)
    private val requestCache = AIRequestCache(context)
    private val contextManager = ConversationContextManager()
    private val offlineModeManager = OfflineModeManager.getInstance(context)
    private val secureStorage = SecureKeyStorage.getInstance(context)

    /**
     * Dispatches user prompt across the prioritized provider pipeline based on routing preference.
     */
    suspend fun processChat(
        userPrompt: String,
        history: List<Pair<String, String>> = emptyList(),
        modelName: String = "gemini-3.8-flash",
        systemInstruction: String? = null
    ): AIResponse = withContext(Dispatchers.Default) {
        val cleanPrompt = userPrompt.trim()
        val startTime = System.currentTimeMillis()
        val routingPref = offlineModeManager.routingPreference.value

        // 1. FIRST PRIORITY: Offline Deterministic Command Engine (Universal across all modes)
        // Instant 0ms hardware/app controls — Torch, Battery, Apps, Volume, Diagnostics.
        val offlineResult = offlineCommandEngine.processCommand(cleanPrompt)
        if (offlineResult.isHandled) {
            Log.i(TAG, "Command handled by OfflineCommandEngine: ${offlineResult.actionType}")
            return@withContext AIResponse(
                text = offlineResult.spokenReply,
                spokenSummary = offlineResult.spokenReply,
                detectedAction = offlineResult.actionType,
                providerUsed = AIProviderType.OFFLINE_DETERMINISTIC,
                modelUsed = "offline-intent-router",
                latencyMs = System.currentTimeMillis() - startTime
            )
        }

        // =====================================================================
        // MODE A: FORCE_OFFLINE
        // =====================================================================
        if (routingPref == RoutingPreference.FORCE_OFFLINE) {
            Log.i(TAG, "Routing Strategy: FORCE_OFFLINE active.")
            if (localModelProvider.isAvailable()) {
                val request = AIRequest(
                    prompt = cleanPrompt,
                    conversationHistory = contextManager.compactHistory(history),
                    modelName = offlineModeManager.modelInfo.modelId,
                    systemInstruction = systemInstruction ?: "You are MYRA, a helpful and affectionate on-device AI assistant."
                )
                val localResult = localModelProvider.executeChat(request)
                if (localResult.isSuccess) {
                    return@withContext localResult.getOrThrow()
                } else {
                    val err = localResult.exceptionOrNull()?.message ?: "Inference error"
                    return@withContext AIResponse(
                        text = "⚠️ ऑन-डिवाइस AI त्रुटि: $err\n\nकृपया सेटिंग्स में जाकर मॉडल की जांच करें।",
                        spokenSummary = "ऑन डिवाइस एआई में त्रुटि आई है।",
                        providerUsed = AIProviderType.LOCAL_ON_DEVICE,
                        modelUsed = offlineModeManager.modelInfo.modelId,
                        latencyMs = System.currentTimeMillis() - startTime,
                        isError = true
                    )
                }
            } else {
                val modelNameDisp = offlineModeManager.modelInfo.displayName
                val sizeMb = offlineModeManager.modelInfo.expectedSizeBytes / (1024 * 1024)
                return@withContext AIResponse(
                    text = "MYRA ऑफ़लाइन मोड (Force Offline) में है।\n\n" +
                            "बिना इंटरनेट के प्राकृतिक AI चैट करने के लिए ऑन-डिवाइस $modelNameDisp (${sizeMb} MB) आवश्यक है।\n\n" +
                            "👉 कृपया 'सेटिंग्स > ऑफ़लाइन AI' में जाकर मॉडल डाउनलोड करें।\n\n" +
                            "(नोट: टॉर्च, बैटरी, वॉल्यूम, और ऐप्स खोलने जैसे डिवाइस कमांड अभी भी 100% काम कर रहे हैं।)",
                    spokenSummary = "ऑफ़लाइन AI चैट के लिए सेटिंग्स से मॉडल डाउनलोड करें।",
                    providerUsed = AIProviderType.OFFLINE_DETERMINISTIC,
                    modelUsed = "offline-setup-required",
                    latencyMs = System.currentTimeMillis() - startTime
                )
            }
        }

        // =====================================================================
        // 2. SECOND PRIORITY: AI Request Cache (AUTO & ONLINE modes)
        // =====================================================================
        val cachedResponse = requestCache.get(cleanPrompt)
        if (cachedResponse != null) {
            Log.i(TAG, "Cache hit for prompt: $cleanPrompt")
            return@withContext AIResponse(
                text = cachedResponse,
                spokenSummary = cachedResponse.take(150),
                providerUsed = AIProviderType.OFFLINE_DETERMINISTIC,
                modelUsed = "local-request-cache",
                latencyMs = System.currentTimeMillis() - startTime,
                isCached = true
            )
        }

        // 3. Evaluate Network & Operating State
        val mode = offlineModeManager.evaluateOperatingMode()

        // =====================================================================
        // MODE B: FORCE_ONLINE
        // =====================================================================
        if (routingPref == RoutingPreference.FORCE_ONLINE) {
            if (mode != MyraOperatingMode.ONLINE_GEMINI) {
                val reason = when (mode) {
                    MyraOperatingMode.NO_KEY_CONFIGURED -> "Google Gemini API Key कॉन्फ़िगर नहीं है। सेटिंग्स में अपनी मुफ़्त API Key दर्ज करें।"
                    MyraOperatingMode.QUOTA_EXHAUSTED -> "Google Gemini फ्री टियर कोटा समाप्त हो गया है।"
                    else -> "इंटरनेट कनेक्शन उपलब्ध नहीं है।"
                }
                return@withContext AIResponse(
                    text = "⚠️ Force Online मोड सक्रिय है, लेकिन ऑनलाइन AI उपलब्ध नहीं है:\n$reason\n\nबिना इंटरनेट के चैट करने के लिए सेटिंग्स में 'Auto' या 'Force Offline' मोड चुनें।",
                    spokenSummary = reason,
                    providerUsed = AIProviderType.GEMINI_DIRECT,
                    modelUsed = modelName,
                    latencyMs = System.currentTimeMillis() - startTime,
                    isError = true
                )
            }

            // Execute Gemini Direct
            val request = AIRequest(
                prompt = cleanPrompt,
                conversationHistory = contextManager.compactHistory(history),
                modelName = modelName,
                systemInstruction = systemInstruction ?: "You are MYRA, a premier AI Assistant."
            )
            quotaHandler.recordRequest()
            val geminiResult = geminiDirectProvider.executeChat(request)
            if (geminiResult.isSuccess) {
                val resp = geminiResult.getOrThrow()
                if (!resp.isQuotaExhausted) {
                    requestCache.put(cleanPrompt, resp.text)
                }
                return@withContext resp
            } else {
                return@withContext AIResponse(
                    text = "ऑनलाइन Gemini कॉल विफल: ${geminiResult.exceptionOrNull()?.localizedMessage}",
                    spokenSummary = "Gemini सर्वर से संपर्क नहीं हो सका।",
                    providerUsed = AIProviderType.GEMINI_DIRECT,
                    modelUsed = modelName,
                    latencyMs = System.currentTimeMillis() - startTime,
                    isError = true
                )
            }
        }

        // =====================================================================
        // MODE C: AUTO (Smart Zero-Cost Routing with Seamless Failover)
        // =====================================================================

        // Step 1: Optional Custom Backend (if user configured private server)
        if (optionalBackendProvider.isAvailable() && mode == MyraOperatingMode.ONLINE_GEMINI) {
            val request = AIRequest(
                prompt = cleanPrompt,
                conversationHistory = contextManager.compactHistory(history),
                modelName = modelName,
                systemInstruction = systemInstruction ?: "You are MYRA, a premier AI Assistant."
            )
            val backendResult = optionalBackendProvider.executeChat(request)
            if (backendResult.isSuccess) {
                val resp = backendResult.getOrThrow()
                requestCache.put(cleanPrompt, resp.text)
                return@withContext resp
            }
            Log.w(TAG, "Optional backend failed. Falling back to Gemini Direct...")
        }

        // Step 2: Gemini Direct Provider (Official Google API)
        if (mode == MyraOperatingMode.ONLINE_GEMINI) {
            val request = AIRequest(
                prompt = cleanPrompt,
                conversationHistory = contextManager.compactHistory(history),
                modelName = modelName,
                systemInstruction = systemInstruction ?: "You are MYRA, a premier AI Assistant."
            )

            quotaHandler.recordRequest()
            val geminiResult = geminiDirectProvider.executeChat(request)

            if (geminiResult.isSuccess) {
                val resp = geminiResult.getOrThrow()
                if (resp.isQuotaExhausted) {
                    quotaHandler.recordQuotaExhausted()
                    offlineModeManager.evaluateOperatingMode()
                } else {
                    requestCache.put(cleanPrompt, resp.text)
                    return@withContext resp
                }
            } else {
                Log.w(TAG, "Gemini Direct failed: ${geminiResult.exceptionOrNull()?.message}. Auto-routing to local AI...")
            }
        }

        // Step 3: Seamless Auto Failover to On-Device Local Model (Gemma 3 1B LiteRT-LM)
        if (localModelProvider.isAvailable()) {
            Log.i(TAG, "AUTO router: Online unavailable/exhausted. Routing to installed on-device LiteRT-LM model.")
            val request = AIRequest(
                prompt = cleanPrompt,
                conversationHistory = contextManager.compactHistory(history),
                modelName = offlineModeManager.modelInfo.modelId,
                systemInstruction = systemInstruction ?: "You are MYRA, a helpful and affectionate on-device AI assistant."
            )
            val localResult = localModelProvider.executeChat(request)
            if (localResult.isSuccess) {
                return@withContext localResult.getOrThrow()
            } else {
                Log.w(TAG, "Local model inference failed: ${localResult.exceptionOrNull()?.message}")
            }
        }

        // Step 4: Transparent User Guidance (When neither online nor offline LLM can answer)
        val latency = System.currentTimeMillis() - startTime
        val modelDisp = offlineModeManager.modelInfo.displayName
        val fallbackText = when (mode) {
            MyraOperatingMode.QUOTA_EXHAUSTED -> {
                "⚠️ आपका Google Gemini फ्री कोटा (Free Tier Quota) समाप्त हो गया है।\n\n" +
                "बिना इंटरनेट और बिना किसी शुल्क के निरंतर AI चैट के लिए 'सेTINGS > ऑफ़लाइन AI' में जाकर $modelDisp डाउनलोड करें।\n\n" +
                "(टॉर्च, बैटरी, वॉल्यूम, अलार्म, और ऐप्स खोलने जैसे लोकल कमांड्स अभी भी सक्रिय हैं।)"
            }
            MyraOperatingMode.NO_KEY_CONFIGURED -> {
                "नमस्ते! ऑनलाइन AI चैट के लिए सेटिंग्स में अपनी मुफ़्त Google Gemini API Key दर्ज करें (BYOK)।\n\n" +
                "या बिना इंटरनेट के 100% मुफ़्त AI चैट के लिए 'सेटिंग्स > ऑफ़लाइन AI' से $modelDisp डाउनलोड करें।"
            }
            MyraOperatingMode.OFFLINE_LOCAL -> {
                "इंटरनेट कनेक्शन उपलब्ध नहीं है और ऑन-डिवाइस $modelDisp मॉडल अभी डाउनलोड नहीं किया गया है।\n\n" +
                "ऑफलाइन AI चैट के लिए वाई-फाई कनेक्ट करके 'सेटिंग्स > ऑफ़लाइन AI' से मॉडल डाउनलोड करें। फोन टूल्स (टॉर्च, बैटरी, अलार्म) तुरंत काम कर रहे हैं।"
            }
            else -> {
                "ऑनलाइन AI सेवा से संपर्क नहीं हो सका। कृपया नेटवर्क जांचें या ऑफ़लाइन मॉडल स्थापित करें।"
            }
        }

        return@withContext AIResponse(
            text = fallbackText,
            spokenSummary = fallbackText.lines().firstOrNull() ?: fallbackText,
            providerUsed = AIProviderType.OFFLINE_DETERMINISTIC,
            modelUsed = "offline-guidance-router",
            latencyMs = latency
        )
    }

    fun getActiveProviderBadge(): String {
        return offlineModeManager.getStatusBadgeText()
    }

    fun getQuotaStatusHindi(): String {
        return quotaHandler.getStatusHindiMessage()
    }
}
