package com.myra.assistant.provider

import android.content.Context
import android.util.Log
import com.myra.assistant.security.SecureKeyStorage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * GeminiDirectProvider — The Primary Zero-Cost Online AI Provider for MYRA.
 *
 * ARCHITECTURE:
 * Android MYRA App  ---> HTTPS --->  Official Google Gemini API
 * 
 * ZERO INTERMEDIARY PLATFORMS:
 * - NO Render dependency.
 * - NO Cloudflare Workers dependency.
 * - NO paid VPS or proxy server.
 * - Direct authenticated REST calls to Google's official endpoint.
 * - Built-in quota monitoring, exponential backoff for 503/timeouts,
 *   and immediate fast-abort on HTTP 429 (RESOURCE_EXHAUSTED).
 */
class GeminiDirectProvider(private val context: Context) : BackendProvider {

    override val providerType = AIProviderType.GEMINI_DIRECT
    override val displayName = "Google Gemini Direct (Zero-Cost / BYOK)"

    companion object {
        private const val TAG = "MYRA_GeminiDirect"
        private const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models"
        private val JSON_MEDIA = "application/json; charset=utf-8".toMediaType()

        val VERIFIED_MODELS = listOf(
            "gemini-3.8-flash",
            "gemini-3.6-flash",
            "gemini-3.5-flash-lite"
        )
        const val DEFAULT_MODEL = "gemini-3.8-flash"
        const val FALLBACK_MODEL = "gemini-3.5-flash-lite"
    }

    private val secureStorage = SecureKeyStorage.getInstance(context)

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(18, TimeUnit.SECONDS)
        .writeTimeout(12, TimeUnit.SECONDS)
        .retryOnConnectionFailure(false) // Controlled manually via exponential backoff
        .build()

    override fun isAvailable(): Boolean {
        return secureStorage.hasConfiguredApiKey()
    }

    override suspend fun testConnection(): Pair<Boolean, String> = withContext(Dispatchers.IO) {
        val apiKey = secureStorage.getGeminiApiKey()
        if (apiKey.isBlank()) {
            return@withContext Pair(false, "API Key Configured नहीं है। सेटिंग्स में अपनी Google Gemini API Key जोड़ें।")
        }

        val testUrl = "$BASE_URL/$DEFAULT_MODEL:generateContent"
        val payload = JSONObject().apply {
            put("contents", JSONArray().apply {
                put(JSONObject().apply {
                    put("role", "user")
                    put("parts", JSONArray().apply {
                        put(JSONObject().apply { put("text", "Say 'OK' in one word") })
                    })
                })
            })
            put("generationConfig", JSONObject().apply {
                put("maxOutputTokens", 5)
            })
        }

        val request = Request.Builder()
            .url(testUrl)
            .post(payload.toString().toRequestBody(JSON_MEDIA))
            .header("x-goog-api-key", apiKey)
            .header("User-Agent", "MYRA-Android-Direct/2026")
            .build()

        val start = System.currentTimeMillis()
        try {
            val response = httpClient.newCall(request).execute()
            val latency = System.currentTimeMillis() - start
            val code = response.code
            val body = response.body?.string() ?: ""

            if (response.isSuccessful) {
                secureStorage.recordKeyTestResult(true, "Connected (${latency}ms)")
                return@withContext Pair(true, "सफलतापूर्वक कनेक्टेड (${latency}ms) • Google Gemini Direct")
            }

            val errorMsg = parseErrorMessage(code, body)
            secureStorage.recordKeyTestResult(false, errorMsg)
            return@withContext Pair(false, errorMsg)
        } catch (e: Exception) {
            val err = "नेटवर्क एरर: ${e.localizedMessage ?: "Google सर्वर से संपर्क नहीं हो सका"}"
            secureStorage.recordKeyTestResult(false, err)
            return@withContext Pair(false, err)
        }
    }

    override suspend fun executeChat(request: AIRequest): Result<AIResponse> = withContext(Dispatchers.IO) {
        val apiKey = secureStorage.getGeminiApiKey()
        if (apiKey.isBlank()) {
            return@withContext Result.failure(
                IllegalStateException("Gemini API Key missing. Please configure your key in Settings.")
            )
        }

        val targetModel = if (request.modelName.isNotBlank()) request.modelName else DEFAULT_MODEL
        val modelTiers = listOf(targetModel, "gemini-3.6-flash", FALLBACK_MODEL).distinct()

        var lastError: String? = null
        val startTime = System.currentTimeMillis()

        for (model in modelTiers) {
            val result = executeRequestWithRetry(apiKey, model, request)
            if (result.isSuccess) {
                val rawText = result.getOrNull() ?: ""
                val latency = System.currentTimeMillis() - startTime
                val (extractedAction, params, cleanText) = parseActionFromResponse(rawText)

                return@withContext Result.success(
                    AIResponse(
                        text = cleanText,
                        spokenSummary = cleanText.take(150),
                        detectedAction = extractedAction,
                        actionParams = params,
                        providerUsed = AIProviderType.GEMINI_DIRECT,
                        modelUsed = model,
                        latencyMs = latency
                    )
                )
            }

            val ex = result.exceptionOrNull()
            lastError = ex?.message

            // If quota exhausted (HTTP 429), DO NOT endlessly try next models or retry
            if (lastError?.contains("QUOTA_EXHAUSTED", ignoreCase = true) == true) {
                Log.w(TAG, "Gemini API Quota Exhausted (429). Halting cloud requests.")
                return@withContext Result.success(
                    AIResponse(
                        text = "⚠️ आपका Google Gemini फ्री कोटा (Free Tier Quota) समाप्त हो गया है। MYRA अब बिना इंटरनेट और बिना किसी अतिरिक्त शुल्क के ऑफलाइन कमांड मोड में चल रही है।",
                        spokenSummary = "जेमिनी फ्री कोटा समाप्त हो गया है। मायरा ऑफलाइन मोड में सक्रिय है।",
                        providerUsed = AIProviderType.GEMINI_DIRECT,
                        modelUsed = model,
                        latencyMs = System.currentTimeMillis() - startTime,
                        isQuotaExhausted = true,
                        errorMessage = "RESOURCE_EXHAUSTED"
                    )
                )
            }
        }

        Result.failure(Exception(lastError ?: "Direct Gemini request failed across all model tiers"))
    }

    /**
     * Executes HTTP request with exponential backoff ONLY for transient server errors (503/500/timeout).
     * Never retries 429, 400, or 401.
     */
    private suspend fun executeRequestWithRetry(
        apiKey: String,
        model: String,
        request: AIRequest
    ): Result<String> {
        val maxAttempts = 2
        var currentDelay = 800L

        for (attempt in 1..maxAttempts) {
            val url = "$BASE_URL/$model:generateContent"
            val payload = buildJsonPayload(request)

            val httpRequest = Request.Builder()
                .url(url)
                .post(payload.toString().toRequestBody(JSON_MEDIA))
                .header("x-goog-api-key", apiKey)
                .header("User-Agent", "MYRA-Android-Direct/2026")
                .build()

            try {
                val response = httpClient.newCall(httpRequest).execute()
                val code = response.code
                val body = response.body?.string() ?: ""

                if (response.isSuccessful) {
                    val text = extractGeneratedText(body)
                    return Result.success(text)
                }

                // Check for HTTP 429 Quota Exhaustion
                if (code == 429) {
                    return Result.failure(Exception("QUOTA_EXHAUSTED: Free rate limit or usage quota reached."))
                }

                // If 503 (Server Busy) or 500 and attempts remain, back off
                if ((code == 503 || code == 500) && attempt < maxAttempts) {
                    Log.w(TAG, "Transient HTTP $code from Gemini. Retrying in ${currentDelay}ms...")
                    delay(currentDelay)
                    currentDelay *= 2
                    continue
                }

                val parsedError = parseErrorMessage(code, body)
                return Result.failure(Exception(parsedError))
            } catch (e: IOException) {
                if (attempt < maxAttempts) {
                    Log.w(TAG, "Socket timeout / IO failure. Retrying attempt ${attempt + 1}...")
                    delay(currentDelay)
                    currentDelay *= 2
                    continue
                }
                return Result.failure(e)
            }
        }

        return Result.failure(Exception("Max retry attempts reached for model $model"))
    }

    private fun buildJsonPayload(request: AIRequest): JSONObject {
        return JSONObject().apply {
            val contentsArr = JSONArray()

            // Append conversation history if present
            request.conversationHistory.forEach { (sender, text) ->
                val role = if (sender.equals("user", ignoreCase = true)) "user" else "model"
                contentsArr.put(JSONObject().apply {
                    put("role", role)
                    put("parts", JSONArray().apply {
                        put(JSONObject().apply { put("text", text) })
                    })
                })
            }

            // Append current prompt & images
            val currentParts = JSONArray().apply {
                put(JSONObject().apply { put("text", request.prompt) })
            }
            request.attachedBase64Images.forEach { base64Data ->
                currentParts.put(JSONObject().apply {
                    put("inlineData", JSONObject().apply {
                        put("mimeType", "image/jpeg")
                        put("data", base64Data)
                    })
                })
            }
            contentsArr.put(JSONObject().apply {
                put("role", "user")
                put("parts", currentParts)
            })

            put("contents", contentsArr)

            // System instructions
            put("systemInstruction", JSONObject().apply {
                put("parts", JSONArray().apply {
                    put(JSONObject().apply { put("text", request.systemInstruction) })
                })
            })

            // Generation config
            put("generationConfig", JSONObject().apply {
                put("temperature", request.temperature)
                put("maxOutputTokens", request.maxOutputTokens)
            })
        }
    }

    private fun extractGeneratedText(responseBody: String): String {
        return try {
            val json = JSONObject(responseBody)
            val candidates = json.optJSONArray("candidates")
            if (candidates != null && candidates.length() > 0) {
                val first = candidates.getJSONObject(0)
                val content = first.optJSONObject("content")
                val parts = content?.optJSONArray("parts")
                if (parts != null && parts.length() > 0) {
                    return parts.getJSONObject(0).optString("text", "")
                }
            }
            "No text returned"
        } catch (e: Exception) {
            "Response parsing error: ${e.message}"
        }
    }

    private fun parseActionFromResponse(text: String): Triple<String?, Map<String, Any>, String> {
        // Checks if text contains structured action directive (e.g. [ACTION: toggle_flashlight, state: on])
        val actionRegex = Regex("""\[ACTION:\s*([a-zA-Z0-9_]+)(?:,\s*params:\s*(\{[^}]+}))?\]""")
        val match = actionRegex.find(text)
        if (match != null) {
            val actionName = match.groupValues[1]
            val cleanText = text.replace(match.value, "").trim()
            return Triple(actionName, emptyMap(), cleanText)
        }
        return Triple(null, emptyMap(), text)
    }

    private fun parseErrorMessage(code: Int, body: String): String {
        var detail = "HTTP $code"
        try {
            val json = JSONObject(body)
            if (json.has("error")) {
                detail = json.getJSONObject("error").optString("message", detail)
            }
        } catch (_: Exception) {}

        return when (code) {
            400 -> "अमान्य अनुरोध (HTTP 400): API Key की जांच करें।"
            401, 403 -> "API Key अमान्य है या अनुमति नहीं है (HTTP $code)। Google AI Studio में जांचें।"
            404 -> "मॉडल उपलब्ध नहीं है (HTTP 404)।"
            429 -> "QUOTA_EXHAUSTED: फ्री उपयोग कोटा समाप्त हो गया है।"
            503 -> "Google Gemini सर्वर पर भारी ट्रैफिक है (HTTP 503)।"
            else -> "Gemini API एरर: $detail"
        }
    }
}
