package com.myra.assistant.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.myra.assistant.data.GeminiApiClient
import com.myra.assistant.data.PreferencesManager
import com.myra.assistant.data.SmartMemoryManager

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TruthSafetyCenterScreen(
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val prefs = remember { PreferencesManager(context) }
    val memoryManager = remember { SmartMemoryManager(context) }

    var isPaidUsage by remember { mutableStateOf(prefs.isPaidUsageAllowed) }
    var isMemoryEnabled by remember { mutableStateOf(prefs.isSmartMemoryEnabled) }
    var isMemoryPaused by remember { mutableStateOf(prefs.isMemoryPaused) }
    var isConfirmationRequired by remember { mutableStateOf(prefs.isActionConfirmationRequired) }
    var memoriesList by remember { mutableStateOf(memoryManager.getMemories()) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Truth & Safety Center", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        Text("सत्यता, सुरक्षा एवं AI नियंत्रण", fontSize = 11.sp, color = Color.Cyan)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF090D16))
            )
        },
        containerColor = Color(0xFF060911)
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item { Spacer(modifier = Modifier.height(8.dp)) }

            // 1. Gemini Model & Live Connection Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF0B132B))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.SmartToy, contentDescription = null, tint = Color.Cyan)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Active AI Engine & Model", fontWeight = FontWeight.Bold, color = Color.White)
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Model: ${prefs.selectedGeminiModel}", color = Color(0xFF64DFDF), fontSize = 13.sp)
                        Text("Connection: ${prefs.geminiApiConnectionStatus}", color = Color.LightGray, fontSize = 12.sp)
                        Text("API Key: ${if (prefs.hasConfiguredApiKey) "Configured (Stored in Keystore)" else "Not Configured"}", color = Color.Gray, fontSize = 12.sp)
                    }
                }
            }

            // 2. Verified Quota & Billing Protection Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF0B132B))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Shield, contentDescription = null, tint = Color(0xFF48CAE4))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Quota & Billing Protection", fontWeight = FontWeight.Bold, color = Color.White)
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Estimated Today Requests: ${prefs.dailyRequestCount}", color = Color.White, fontSize = 13.sp)
                        Text("Google Free Quota: 15 RPM / 1M TPM (Free-Tier Safe)", color = Color(0xFF80ED99), fontSize = 12.sp)
                        Text("Note: Project quotas are tracked directly on Google Cloud Console.", color = Color.Gray, fontSize = 11.sp)
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Allow Paid API Usage", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                                Text("Default is OFF. Prevent unexpected charges.", color = Color.Gray, fontSize = 11.sp)
                            }
                            Switch(
                                checked = isPaidUsage,
                                onCheckedChange = {
                                    isPaidUsage = it
                                    prefs.isPaidUsageAllowed = it
                                }
                            )
                        }
                    }
                }
            }

            // 3. Action Safety & Confirmation Guard
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF0B132B))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.VerifiedUser, contentDescription = null, tint = Color(0xFF52B788))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Action Safety & Confirmation", fontWeight = FontWeight.Bold, color = Color.White)
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Confirm Sensitive Actions", color = Color.White, fontSize = 14.sp)
                                Text("Always confirm calls, messages, SOS, and remote actions.", color = Color.Gray, fontSize = 11.sp)
                            }
                            Switch(
                                checked = isConfirmationRequired,
                                onCheckedChange = {
                                    isConfirmationRequired = it
                                    prefs.isActionConfirmationRequired = it
                                }
                            )
                        }
                    }
                }
            }

            // 4. Smart Memory Controls
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF0B132B))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Memory, contentDescription = null, tint = Color(0xFFB5179E))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("User-Controlled Smart Memory", fontWeight = FontWeight.Bold, color = Color.White)
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Enable Smart Memory", color = Color.White, fontSize = 14.sp)
                            Switch(
                                checked = isMemoryEnabled,
                                onCheckedChange = {
                                    isMemoryEnabled = it
                                    prefs.isSmartMemoryEnabled = it
                                }
                            )
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Pause Memory Recording", color = Color.White, fontSize = 14.sp)
                            Switch(
                                checked = isMemoryPaused,
                                onCheckedChange = {
                                    isMemoryPaused = it
                                    prefs.isMemoryPaused = it
                                }
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Stored Memories: ${memoriesList.size}", color = Color.LightGray, fontSize = 12.sp)
                        if (memoriesList.isNotEmpty()) {
                            Button(
                                onClick = {
                                    memoryManager.clearAllMemories()
                                    memoriesList = emptyList()
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7209B7)),
                                modifier = Modifier.padding(top = 8.dp)
                            ) {
                                Text("Clear All Memories", color = Color.White, fontSize = 12.sp)
                            }
                        }
                    }
                }
            }

            item { Spacer(modifier = Modifier.height(24.dp)) }
        }
    }
}
