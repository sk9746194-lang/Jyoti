package com.myra.assistant.provider

/**
 * Supported AI Provider Tiers for MYRA.
 */
enum class AIProviderType {
    GEMINI_DIRECT,      // Official Google Gemini API directly over HTTPS (Zero-cost, Zero-server)
    OPTIONAL_BACKEND,   // Optional user-configured server proxy (Self-hosted / VPS / Localhost)
    LOCAL_ON_DEVICE,    // Optional on-device lightweight open-weight LLM (Gemma/SmolLM/Qwen)
    OFFLINE_DETERMINISTIC // Instant zero-cost on-device rule & command engine
}

/**
 * Standard AI Request Model across all providers.
 */
data class AIRequest(
    val prompt: String,
    val conversationHistory: List<Pair<String, String>> = emptyList(),
    val systemInstruction: String = "You are MYRA, a premier Indian AI Voice Assistant. Respond naturally in Hindi, Hinglish, or English.",
    val preferredLanguage: String = "auto", // "hi", "en", "auto"
    val maxOutputTokens: Int = 512,
    val temperature: Double = 0.7,
    val modelName: String = "gemini-3.8-flash",
    val attachedBase64Images: List<String> = emptyList()
)

/**
 * Standard AI Response Model across all providers.
 */
data class AIResponse(
    val text: String,
    val spokenSummary: String = "",
    val detectedAction: String? = null,
    val actionParams: Map<String, Any> = emptyMap(),
    val providerUsed: AIProviderType,
    val modelUsed: String,
    val latencyMs: Long,
    val isCached: Boolean = false,
    val isQuotaExhausted: Boolean = false,
    val errorMessage: String? = null
)

/**
 * Core interface for all AI backends in MYRA.
 * Ensures modularity and eliminates mandatory third-party hosting dependencies.
 */
interface BackendProvider {
    val providerType: AIProviderType
    val displayName: String

    /**
     * Checks if this provider is currently available and configured.
     */
    fun isAvailable(): Boolean

    /**
     * Executes the conversational inference request.
     */
    suspend fun executeChat(request: AIRequest): Result<AIResponse>

    /**
     * Tests connectivity to the provider.
     */
    suspend fun testConnection(): Pair<Boolean, String>
}
