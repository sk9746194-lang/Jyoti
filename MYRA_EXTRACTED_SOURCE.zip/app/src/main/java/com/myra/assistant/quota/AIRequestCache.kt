package com.myra.assistant.quota

import android.content.Context
import android.util.LruCache
import org.json.JSONObject

/**
 * AI Request Cache for MYRA.
 * 
 * QUOTA PRESERVATION POLICY:
 * - Caches static responses (definitions, math, translations, system help)
 * - Identical requests within 1 hour return instant cached responses with 0ms latency
 *   and zero consumed tokens from the user's free Gemini API quota.
 */
class AIRequestCache(context: Context) {

    private val prefs = context.getSharedPreferences("myra_ai_cache", Context.MODE_PRIVATE)

    // Memory LRU Cache: Holds up to 64 recent answers
    private val memoryCache = LruCache<String, String>(64)

    companion object {
        private const val TTL_MILLIS = 3600_000L // 1 hour
    }

    private fun normalizeKey(prompt: String): String {
        return prompt.trim().lowercase()
    }

    /**
     * Checks if a cached response exists for the prompt and is within TTL.
     */
    fun get(prompt: String): String? {
        val key = normalizeKey(prompt)

        // 1. Check memory cache
        val memHit = memoryCache.get(key)
        if (memHit != null) return memHit

        // 2. Check disk cache
        val diskData = prefs.getString(key, null) ?: return null
        return try {
            val json = JSONObject(diskData)
            val timestamp = json.getLong("ts")
            if (System.currentTimeMillis() - timestamp < TTL_MILLIS) {
                val text = json.getString("text")
                memoryCache.put(key, text)
                text
            } else {
                prefs.edit().remove(key).apply()
                null
            }
        } catch (_: Exception) {
            null
        }
    }

    /**
     * Stores a response in the cache.
     */
    fun put(prompt: String, responseText: String) {
        if (prompt.length < 4 || responseText.isBlank()) return
        val key = normalizeKey(prompt)

        memoryCache.put(key, responseText)

        try {
            val json = JSONObject().apply {
                put("ts", System.currentTimeMillis())
                put("text", responseText)
            }
            prefs.edit().putString(key, json.toString()).apply()
        } catch (_: Exception) {}
    }

    /**
     * Clears all cached responses.
     */
    fun clear() {
        memoryCache.evictAll()
        prefs.edit().clear().apply()
    }
}
