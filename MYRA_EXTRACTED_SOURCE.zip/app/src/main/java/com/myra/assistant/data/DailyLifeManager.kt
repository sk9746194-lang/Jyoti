package com.myra.assistant.data

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

data class DailyTaskItem(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val timeDue: String,
    val date: String, // "YYYY-MM-DD"
    val isCompleted: Boolean = false,
    val isCalendarEvent: Boolean = false,
    val priority: String = "medium" // "low", "medium", "high"
)

/**
 * MYRA Daily Life Manager
 * Manages reminders, daily task lists, calendar events, morning briefings and evening reviews.
 */
class DailyLifeManager(private val context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("myra_daily_life", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_TASKS = "daily_tasks"
    }

    private val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())

    fun getTodayDate(): String = dateFormat.format(Date())

    /**
     * Retrieves all tasks for today or a specific date.
     */
    fun getTasks(date: String = getTodayDate()): List<DailyTaskItem> {
        val jsonStr = prefs.getString(KEY_TASKS, "[]") ?: "[]"
        val list = mutableListOf<DailyTaskItem>()
        try {
            val arr = JSONArray(jsonStr)
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                val taskDate = obj.optString("date", "")
                if (date.isEmpty() || taskDate == date || taskDate.isEmpty()) {
                    list.add(
                        DailyTaskItem(
                            id = obj.optString("id", UUID.randomUUID().toString()),
                            title = obj.optString("title", ""),
                            timeDue = obj.optString("timeDue", "All Day"),
                            date = taskDate,
                            isCompleted = obj.optBoolean("isCompleted", false),
                            isCalendarEvent = obj.optBoolean("isCalendarEvent", false),
                            priority = obj.optString("priority", "medium")
                        )
                    )
                }
            }
        } catch (e: Exception) {
            // handle error
        }
        return list
    }

    /**
     * Adds a new task or calendar event.
     */
    fun addTask(title: String, timeDue: String, date: String = getTodayDate(), isCalendarEvent: Boolean = false, priority: String = "medium"): DailyTaskItem {
        val allTasks = getAllStoredTasks().toMutableList()
        val item = DailyTaskItem(
            title = title.trim(),
            timeDue = timeDue.trim(),
            date = date,
            isCalendarEvent = isCalendarEvent,
            priority = priority
        )
        allTasks.add(item)
        saveAllTasks(allTasks)
        return item
    }

    /**
     * Marks a task as completed or incomplete.
     */
    fun toggleTaskCompletion(id: String): Boolean {
        val allTasks = getAllStoredTasks().map {
            if (it.id == id) it.copy(isCompleted = !it.isCompleted) else it
        }
        saveAllTasks(allTasks)
        return true
    }

    /**
     * Deletes a task by id.
     */
    fun deleteTask(id: String): Boolean {
        val allTasks = getAllStoredTasks().filterNot { it.id == id }
        saveAllTasks(allTasks)
        return true
    }

    /**
     * Generates a morning daily briefing in Hindi/Hinglish.
     */
    fun generateMorningBriefing(): String {
        val todayTasks = getTasks(getTodayDate())
        val pending = todayTasks.filterNot { it.isCompleted }
        return if (pending.isEmpty()) {
            "Suprabhat! Aaj ke liye aapki koi pending tasks nahi hain. Aapka din shubh rahe!"
        } else {
            val sb = StringBuilder("Suprabhat! Aaj aapke paas ${pending.size} pending tasks hain:\n")
            pending.take(5).forEachIndexed { index, task ->
                sb.append("${index + 1}. ${task.title} (${task.timeDue})\n")
            }
            sb.toString().trim()
        }
    }

    /**
     * Generates an evening task review.
     */
    fun generateEveningReview(): String {
        val todayTasks = getTasks(getTodayDate())
        val completed = todayTasks.filter { it.isCompleted }
        val pending = todayTasks.filterNot { it.isCompleted }
        return "Shubh Sandhya! Aaj aapne ${completed.size} tasks complete kiye, aur ${pending.size} tasks pending hain. Shandar kaam!"
    }

    private fun getAllStoredTasks(): List<DailyTaskItem> {
        val jsonStr = prefs.getString(KEY_TASKS, "[]") ?: "[]"
        val list = mutableListOf<DailyTaskItem>()
        try {
            val arr = JSONArray(jsonStr)
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                list.add(
                    DailyTaskItem(
                        id = obj.optString("id", UUID.randomUUID().toString()),
                        title = obj.optString("title", ""),
                        timeDue = obj.optString("timeDue", "All Day"),
                        date = obj.optString("date", getTodayDate()),
                        isCompleted = obj.optBoolean("isCompleted", false),
                        isCalendarEvent = obj.optBoolean("isCalendarEvent", false),
                        priority = obj.optString("priority", "medium")
                    )
                )
            }
        } catch (e: Exception) {
            // handle error
        }
        return list
    }

    private fun saveAllTasks(tasks: List<DailyTaskItem>) {
        val arr = JSONArray()
        tasks.forEach { item ->
            val obj = JSONObject()
            obj.put("id", item.id)
            obj.put("title", item.title)
            obj.put("timeDue", item.timeDue)
            obj.put("date", item.date)
            obj.put("isCompleted", item.isCompleted)
            obj.put("isCalendarEvent", item.isCalendarEvent)
            obj.put("priority", item.priority)
            arr.put(obj)
        }
        prefs.edit().putString(KEY_TASKS, arr.toString()).apply()
    }
}
