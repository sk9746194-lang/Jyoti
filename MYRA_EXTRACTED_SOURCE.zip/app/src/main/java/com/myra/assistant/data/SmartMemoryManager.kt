package com.myra.assistant.data

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

data class UserMemoryItem(
    val id: String = UUID.randomUUID().toString(),
    val category: String, // "preference", "project", "instruction", "fact"
    val content: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isPinned: Boolean = false
)

/**
 * MYRA Smart Memory Manager
 * Provides user-controlled, persistent local memory.
 * - Stores user-approved preferences, ongoing project states, and instructions.
 * - Disallows storing sensitive keys, passwords, or financial credentials.
 * - Supports editing, pausing, deleting individual memories or clearing all.
 */
class SmartMemoryManager(private val context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("myra_smart_memory", Context.MODE_PRIVATE)
    private val preferencesManager = PreferencesManager(context)
    private val localRepository = com.myra.assistant.offline.LocalMemoryRepository(context)

    companion object {
        private const val KEY_MEMORIES = "stored_user_memories"
        private const val SENSITIVE_REGEX = "(?i)(password|passwd|api[_-]?key|secret|token|bearer|cvv|pin|credit[_-]?card|otp)"
    }

    /**
     * Checks if text contains sensitive data that should NEVER be stored.
     */
    fun containsSensitiveData(text: String): Boolean {
        return Regex(SENSITIVE_REGEX).containsMatchIn(text)
    }

    /**
     * Adds an approved memory item if memory is enabled and not paused.
     */
    fun addMemory(category: String, content: String, isPinned: Boolean = false): Boolean {
        if (!preferencesManager.isSmartMemoryEnabled || preferencesManager.isMemoryPaused) {
            return false
        }
        if (containsSensitiveData(content)) {
            // Strictly reject sensitive information
            return false
        }

        val list = getMemories().toMutableList()
        // Deduplicate
        if (list.any { it.content.equals(content.trim(), ignoreCase = true) }) {
            return false
        }

        val newItem = UserMemoryItem(
            category = category,
            content = content.trim(),
            isPinned = isPinned
        )
        list.add(0, newItem)
        saveMemories(list)

        // Sync with local-only Room search index (zero cloud sync)
        localRepository.insertMemory(category, content.trim(), isPinned)
        return true
    }

    /**
     * Returns all stored memories.
     */
    fun getMemories(): List<UserMemoryItem> {
        val jsonStr = prefs.getString(KEY_MEMORIES, "[]") ?: "[]"
        val result = mutableListOf<UserMemoryItem>()
        try {
            val arr = JSONArray(jsonStr)
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                result.add(
                    UserMemoryItem(
                        id = obj.optString("id", UUID.randomUUID().toString()),
                        category = obj.optString("category", "preference"),
                        content = obj.optString("content", ""),
                        timestamp = obj.optLong("timestamp", System.currentTimeMillis()),
                        isPinned = obj.optBoolean("isPinned", false)
                    )
                )
            }
        } catch (e: Exception) {
            // return empty on parse error
        }
        return result
    }

    /**
     * Deletes a specific memory item by id.
     */
    fun deleteMemory(id: String): Boolean {
        val list = getMemories().filterNot { it.id == id }
        saveMemories(list)
        localRepository.deleteMemory(id)
        return true
    }

    /**
     * Updates an existing memory content.
     */
    fun updateMemory(id: String, newContent: String): Boolean {
        if (containsSensitiveData(newContent)) return false
        val list = getMemories().map {
            if (it.id == id) it.copy(content = newContent.trim()) else it
        }
        saveMemories(list)
        localRepository.updateMemory(id, newContent.trim())
        return true
    }

    /**
     * Clears all stored memories.
     */
    fun clearAllMemories() {
        prefs.edit().remove(KEY_MEMORIES).apply()
        localRepository.clearAll()
    }

    /**
     * Deletes ONLY companion memories, strictly preserving standard user preferences,
     * ongoing project states, and system instructions.
     */
    fun clearCompanionMemories(): Int {
        val all = getMemories()
        val remaining = all.filterNot { it.category.equals("companion", ignoreCase = true) }
        val removedCount = all.size - remaining.size
        saveMemories(remaining)
        localRepository.clearCompanionMemories()
        return removedCount
    }

    /**
     * Fast local-only search across the Room SQLite memory index.
     * Guaranteed 100% offline, zero cloud synchronization.
     */
    fun searchLocalIndex(keyword: String, personality: String = preferencesManager.personality): List<com.myra.assistant.offline.LocalMemoryEntity> {
        return localRepository.searchMemoriesIsolated(keyword, personality)
    }

    /**
     * Retrieves relevant memories formatted for Gemini system prompt.
     * Strictly isolates memory:
     * - Professional mode: completely excludes all companion memories.
     * - Normal Assistant mode: excludes romantic companion memories.
     * - GF / Companion mode: includes companion memories, preferences, and facts.
     */
    fun getFormattedMemoryContext(currentPersonality: String = preferencesManager.personality): String {
        if (!preferencesManager.isSmartMemoryEnabled || preferencesManager.isMemoryPaused) {
            return ""
        }
        val memories = getMemories()
        if (memories.isEmpty()) return ""

        val filtered = when (currentPersonality) {
            "professional" -> memories.filterNot { it.category.equals("companion", ignoreCase = true) }
            "romantic_gf" -> memories
            else -> memories.filterNot { it.category.equals("companion", ignoreCase = true) }
        }

        if (filtered.isEmpty()) return ""

        val sb = StringBuilder("Approved User Memories:\n")
        filtered.take(15).forEach { mem ->
            sb.append("- [${mem.category.uppercase()}] ${mem.content}\n")
        }
        return sb.toString().trim()
    }

    /**
     * Saves ongoing project state for resuming ("MYRA, pichhle project ko wahi se continue karo").
     */
    fun saveProjectState(projectName: String, stateDescription: String) {
        preferencesManager.activeProjectName = projectName
        preferencesManager.lastProjectState = stateDescription
        addMemory("project", "Active Project: $projectName - $stateDescription", isPinned = true)
    }

    /**
     * Retrieves project context to continue unfinished work.
     */
    fun getResumeProjectContext(): String {
        val name = preferencesManager.activeProjectName
        val state = preferencesManager.lastProjectState
        return if (state.isNotBlank()) {
            "Aapka pichhla active project '$name' tha. Last state: $state. Chaliye yahin se continue karte hain."
        } else {
            "Aapka koi pichhla unfinished project save nahi hai. Kya aap koi naya project shuru karna chahte hain?"
        }
    }

    private fun saveMemories(list: List<UserMemoryItem>) {
        val arr = JSONArray()
        list.forEach { item ->
            val obj = JSONObject()
            obj.put("id", item.id)
            obj.put("category", item.category)
            obj.put("content", item.content)
            obj.put("timestamp", item.timestamp)
            obj.put("isPinned", item.isPinned)
            arr.put(obj)
        }
        prefs.edit().putString(KEY_MEMORIES, arr.toString()).apply()
    }
}
