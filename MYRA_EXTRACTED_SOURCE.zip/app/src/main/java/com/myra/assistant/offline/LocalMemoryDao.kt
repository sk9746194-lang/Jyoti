package com.myra.assistant.offline

import androidx.room.*

/**
 * LocalMemoryDao — Room Data Access Object for Local-Only Search Index.
 *
 * Provides sub-millisecond local indexed search queries without requiring an active internet connection.
 * Guarantees privacy isolation across assistant personalities.
 */
@Dao
interface LocalMemoryDao {

    @Query("SELECT * FROM local_memories ORDER BY is_pinned DESC, timestamp DESC")
    fun getAllMemories(): List<LocalMemoryEntity>

    /**
     * Fast indexed search across content, category, and normalized search tokens.
     */
    @Query("""
        SELECT * FROM local_memories 
        WHERE content LIKE '%' || :keyword || '%' 
           OR category LIKE '%' || :keyword || '%' 
           OR search_tokens LIKE '%' || :keyword || '%' 
        ORDER BY is_pinned DESC, timestamp DESC
    """)
    fun searchMemories(keyword: String): List<LocalMemoryEntity>

    /**
     * Search within a specific memory category using index.
     */
    @Query("""
        SELECT * FROM local_memories 
        WHERE category = :category 
          AND (content LIKE '%' || :keyword || '%' OR search_tokens LIKE '%' || :keyword || '%') 
        ORDER BY is_pinned DESC, timestamp DESC
    """)
    fun searchByCategory(category: String, keyword: String): List<LocalMemoryEntity>

    /**
     * Search with companion memory isolation (excludes romantic GF memories in professional/standard mode).
     */
    @Query("""
        SELECT * FROM local_memories 
        WHERE category != 'companion' 
          AND (content LIKE '%' || :keyword || '%' OR category LIKE '%' || :keyword || '%' OR search_tokens LIKE '%' || :keyword || '%') 
        ORDER BY is_pinned DESC, timestamp DESC
    """)
    fun searchIsolatedMemories(keyword: String): List<LocalMemoryEntity>

    @Query("SELECT * FROM local_memories WHERE id = :id LIMIT 1")
    fun getMemoryById(id: String): LocalMemoryEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertMemory(memory: LocalMemoryEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertAll(memories: List<LocalMemoryEntity>)

    @Update
    fun updateMemory(memory: LocalMemoryEntity): Int

    @Query("DELETE FROM local_memories WHERE id = :id")
    fun deleteMemory(id: String): Int

    @Query("DELETE FROM local_memories WHERE category = 'companion'")
    fun clearCompanionMemories(): Int

    @Query("DELETE FROM local_memories")
    fun clearAll(): Int

    @Query("SELECT COUNT(*) FROM local_memories")
    fun getCount(): Int
}
