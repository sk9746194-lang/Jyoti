package com.myra.assistant.provider

import android.content.Context
import com.myra.assistant.security.SecureKeyStorage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * OptionalSecureBackendProvider — Strictly Optional Mediation Backend for MYRA.
 *
 * ZERO-MANDATORY-COST POLICY:
 * - This backend is NEVER mandatory for normal AI chat.
 * - Used only if the user explicitly configures a custom self-hosted server URL
 *   (e.g., local home server, companion PC, or private VPS).
 * - Render and Cloudflare are completely optional.
 * - If this provider is unavailable or fails, MYRA seamlessly falls back to Gemini Direct
 *   or Offline Mode.
 */
class OptionalSecureBackendProvider(private val context: Context) : BackendProvider {

    override val providerType = AIProviderType.OPTIONAL_BACKEND
    override val displayName = "Optional Custom Server (Self-Hosted / Proxy)"

    private val secureStorage = SecureKeyStorage.getInstance(context)
    private val JSON_MEDIA = "application/json; charset=utf-8".toMediaType()

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    override fun isAvailable(): Boolean {
        val customUrl = secureStorage.getCustomBackendUrl()
        return customUrl.isNotBlank() && (customUrl.startsWith("http://") || customUrl.startsWith("https://"))
    }

    override suspend fun testConnection(): Pair<Boolean, String> = withContext(Dispatchers.IO) {
        val customUrl = secureStorage.getCustomBackendUrl()
        if (customUrl.isBlank()) {
            return@withContext Pair(false, "कोई कस्टम सर्वर URL कॉन्फ़िगर नहीं है (यह वैकल्पिक है)")
        }

        val pingUrl = if (customUrl.endsWith("/")) "${customUrl}api/gemini/ping" else "$customUrl/api/gemini/ping"
        val request = Request.Builder().url(pingUrl).get().build()

        try {
            val response = httpClient.newCall(request).execute()
            if (response.isSuccessful) {
                return@withContext Pair(true, "कस्टम सर्वर ऑनलाइन है (${response.code})")
            }
            return@withContext Pair(false, "कस्टम सर्वर एरर: HTTP ${response.code}")
        } catch (e: Exception) {
            return@withContext Pair(false, "कस्टम सर्वर से संपर्क विफल: ${e.localizedMessage}")
        }
    }

    override suspend fun executeChat(request: AIRequest): Result<AIResponse> = withContext(Dispatchers.IO) {
        val customUrl = secureStorage.getCustomBackendUrl()
        if (!isAvailable()) {
            return@withContext Result.failure(IllegalStateException("Optional backend is not configured"))
        }

        val endpoint = if (customUrl.endsWith("/")) "${customUrl}api/chat" else "$customUrl/api/chat"
        val payload = JSONObject().apply {
            put("message", request.prompt)
            put("model", request.modelName)
            put("history", JSONArray().apply {
                request.conversationHistory.forEach { (role, text) ->
                    put(JSONObject().apply {
                        put("sender", role)
                        put("text", text)
                    })
                }
            })
        }

        val httpRequest = Request.Builder()
            .url(endpoint)
            .post(payload.toString().toRequestBody(JSON_MEDIA))
            .build()

        val start = System.currentTimeMillis()
        try {
            val response = httpClient.newCall(httpRequest).execute()
            val latency = System.currentTimeMillis() - start
            val body = response.body?.string() ?: ""

            if (response.isSuccessful) {
                val json = JSONObject(body)
                val reply = json.optString("response", "No response")
                val action = json.optString("action", null)
                return@withContext Result.success(
                    AIResponse(
                        text = reply,
                        spokenSummary = json.optString("spokenSummary", reply.take(150)),
                        detectedAction = if (action == "general_chat") null else action,
                        providerUsed = AIProviderType.OPTIONAL_BACKEND,
                        modelUsed = json.optString("model", "custom-proxy"),
                        latencyMs = latency
                    )
                )
            }
            return@withContext Result.failure(Exception("Optional server returned HTTP ${response.code}"))
        } catch (e: Exception) {
            return@withContext Result.failure(e)
        }
    }
}
