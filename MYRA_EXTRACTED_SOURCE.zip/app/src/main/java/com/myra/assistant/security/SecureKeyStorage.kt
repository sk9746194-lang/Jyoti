package com.myra.assistant.security

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/**
 * Android Keystore-backed Secure Storage for MYRA Assistant.
 * 
 * ZERO-COST & ZERO-EXPOSURE POLICY:
 * - Uses hardware-backed AES-256-GCM via Android Keystore when available.
 * - Stores user-provided Gemini API Key (BYOK) with cryptographic encryption at rest.
 * - Never leaks or logs the raw API key in Logcat, crash dumps, or telemetry.
 * - Provides masked view (e.g., "AIzaSyD...k9X1") for safe UI display.
 * - Allows user to delete, replace, or check configuration status at any time.
 */
class SecureKeyStorage(private val context: Context) {

    companion object {
        private const val TAG = "MYRA_SecureStorage"
        private const val PREF_FILE_NAME = "myra_secure_vault"
        private const val KEY_GEMINI_API_KEY = "encrypted_gemini_api_key"
        private const val KEY_CUSTOM_BACKEND_URL = "encrypted_custom_backend_url"
        private const val KEY_IS_BYOK_ENABLED = "byok_active"
        private const val KEY_LAST_KEY_TEST_TIME = "last_key_test_timestamp"
        private const val KEY_LAST_KEY_TEST_STATUS = "last_key_test_status"

        @Volatile
        private var instance: SecureKeyStorage? = null

        fun getInstance(context: Context): SecureKeyStorage {
            return instance ?: synchronized(this) {
                instance ?: SecureKeyStorage(context.applicationContext).also { instance = it }
            }
        }
    }

    private val securePrefs: SharedPreferences by lazy {
        initEncryptedPreferences()
    }

    private fun initEncryptedPreferences(): SharedPreferences {
        return try {
            val masterKey = MasterKey.Builder(context)
                .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                .build()

            EncryptedSharedPreferences.create(
                context,
                PREF_FILE_NAME,
                masterKey,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        } catch (e: Exception) {
            Log.w(TAG, "Keystore encryption init failed, falling back to private SharedPreferences: ${e.message}")
            context.getSharedPreferences("${PREF_FILE_NAME}_fallback", Context.MODE_PRIVATE)
        }
    }

    /**
     * Stores user-provided Gemini API Key securely.
     */
    fun saveGeminiApiKey(apiKey: String) {
        val cleanKey = apiKey.trim()
        securePrefs.edit()
            .putString(KEY_GEMINI_API_KEY, cleanKey)
            .putBoolean(KEY_IS_BYOK_ENABLED, cleanKey.isNotBlank())
            .apply()
        Log.i(TAG, "Gemini API key stored securely (Keystore AES-256). Length: ${cleanKey.length}")
    }

    /**
     * Retrieves the plaintext key strictly for authorized in-memory HTTPS request execution.
     * Never store this result in static fields or expose to UI.
     */
    fun getGeminiApiKey(): String {
        return securePrefs.getString(KEY_GEMINI_API_KEY, "")?.trim() ?: ""
    }

    /**
     * Returns true if user has configured their own Gemini API key.
     */
    fun hasConfiguredApiKey(): Boolean {
        val key = getGeminiApiKey()
        return key.isNotBlank() && key.length >= 20
    }

    /**
     * Returns a masked representation of the API key for safe UI display.
     * e.g., "AIzaSy...4X9Z" or "Not Configured".
     */
    fun getMaskedApiKey(): String {
        val key = getGeminiApiKey()
        if (key.isBlank()) return "Not Configured (बिना की के)"
        if (key.length <= 10) return "••••••••"
        return "${key.take(7)}...${key.takeLast(4)}"
    }

    /**
     * Completely removes the API key from encrypted storage.
     */
    fun clearGeminiApiKey() {
        securePrefs.edit()
            .remove(KEY_GEMINI_API_KEY)
            .putBoolean(KEY_IS_BYOK_ENABLED, false)
            .remove(KEY_LAST_KEY_TEST_STATUS)
            .apply()
        Log.i(TAG, "Gemini API key erased from encrypted vault.")
    }

    /**
     * Optional custom server endpoint URL (e.g. user-hosted backend).
     */
    fun saveCustomBackendUrl(url: String) {
        securePrefs.edit().putString(KEY_CUSTOM_BACKEND_URL, url.trim()).apply()
    }

    fun getCustomBackendUrl(): String {
        return securePrefs.getString(KEY_CUSTOM_BACKEND_URL, "")?.trim() ?: ""
    }

    fun clearCustomBackendUrl() {
        securePrefs.edit().remove(KEY_CUSTOM_BACKEND_URL).apply()
    }

    /**
     * Records the last test result.
     */
    fun recordKeyTestResult(isSuccess: Boolean, message: String) {
        securePrefs.edit()
            .putLong(KEY_LAST_KEY_TEST_TIME, System.currentTimeMillis())
            .putString(KEY_LAST_KEY_TEST_STATUS, if (isSuccess) "VERIFIED: $message" else "FAILED: $message")
            .apply()
    }

    fun getLastKeyTestStatus(): String {
        return securePrefs.getString(KEY_LAST_KEY_TEST_STATUS, "Not Tested Yet") ?: "Not Tested Yet"
    }
}
