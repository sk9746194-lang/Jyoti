package com.myra.assistant.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import com.myra.assistant.offline.OfflineModeManager
import java.util.Locale

/**
 * OfflineSpeechManager — Zero-Cost, Strictly Isolated On-Device Voice Input & Output.
 *
 * SPECIFICATION & ZERO CLOUD FALLBACK GUARANTEE:
 * - When MYRA is in OFFLINE mode, speech recognition MUST NOT silently call Google Cloud servers.
 * - Enforces RecognizerIntent.EXTRA_PREFER_OFFLINE = true.
 * - Uses on-device Hindi (hi-IN) and English (en-IN) offline packages.
 * - Native Android TextToSpeech with immediate cancellation / interruption on user input.
 * - Provides clear user prompts if offline speech model packages need activation in Android 15 settings.
 */
class OfflineSpeechManager(
    private val context: Context,
    private val onSpeechRecognized: (String) -> Unit,
    private val onError: (String) -> Unit
) : TextToSpeech.OnInitListener {

    companion object {
        private const val TAG = "MYRA_OfflineSpeech"
        private const val UTTERANCE_ID = "myra_offline_speech_stream"
    }

    private val offlineModeMgr = OfflineModeManager.getInstance(context)
    private var speechRecognizer: SpeechRecognizer? = null
    private var textToSpeech: TextToSpeech? = null
    private var isTtsReady = false
    private var isListeningActive = false

    init {
        initSpeechRecognizer()
        initTextToSpeech()
    }

    private fun initSpeechRecognizer() {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            Log.w(TAG, "Android SpeechRecognizer is not available on this device.")
            return
        }

        try {
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
                setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {
                        isListeningActive = true
                        Log.d(TAG, "Offline SpeechRecognizer: Ready for user voice")
                    }

                    override fun onBeginningOfSpeech() {
                        // Immediately interrupt ongoing TTS when user begins speaking
                        stopSpeaking()
                        Log.d(TAG, "SpeechRecognizer: User started speaking (TTS halted)")
                    }

                    override fun onRmsChanged(rmsdB: Float) {}
                    override fun onBufferReceived(buffer: ByteArray?) {}
                    override fun onEndOfSpeech() {
                        isListeningActive = false
                        Log.d(TAG, "SpeechRecognizer: End of speech")
                    }

                    override fun onError(error: Int) {
                        isListeningActive = false
                        val isOffline = offlineModeMgr.isStrictlyOffline()

                        val message = when (error) {
                            SpeechRecognizer.ERROR_NO_MATCH -> "कोई आवाज़ नहीं पहचानी गई।"
                            SpeechRecognizer.ERROR_NETWORK_TIMEOUT,
                            SpeechRecognizer.ERROR_NETWORK -> {
                                if (isOffline) {
                                    "ऑफलाइन स्पीच पैकेज सक्रिय नहीं है। कृपया Android सेटिंग्स में 'Offline Speech Recognition' डाउनलोड करें।"
                                } else {
                                    "नेटवर्क टाइमआउट।"
                                }
                            }
                            SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "समय समाप्त। कृपया पुनः बोलें।"
                            SpeechRecognizer.ERROR_AUDIO -> "ऑडियो रिकॉर्डिंग एरर।"
                            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "माइक्रोफ़ोन अनुमति आवश्यक है।"
                            else -> "पहचान त्रुटि (कोड: $error)"
                        }
                        Log.w(TAG, "Speech recognition error: $message (code: $error)")
                        onError(message)
                    }

                    override fun onResults(results: Bundle?) {
                        isListeningActive = false
                        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        val text = matches?.firstOrNull()?.trim() ?: ""
                        if (text.isNotBlank()) {
                            Log.i(TAG, "Recognized offline text: $text")
                            onSpeechRecognized(text)
                        }
                    }

                    override fun onPartialResults(partialResults: Bundle?) {
                        val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        val partial = matches?.firstOrNull()?.trim() ?: ""
                        if (partial.isNotBlank()) {
                            Log.d(TAG, "Partial offline recognized text: $partial")
                        }
                    }

                    override fun onEvent(eventType: Int, params: Bundle?) {}
                })
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to initialize SpeechRecognizer: ${e.message}")
        }
    }

    private fun initTextToSpeech() {
        try {
            textToSpeech = TextToSpeech(context.applicationContext, this).apply {
                setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        Log.d(TAG, "TTS playback started: $utteranceId")
                    }

                    override fun onDone(utteranceId: String?) {
                        Log.d(TAG, "TTS playback completed: $utteranceId")
                    }

                    override fun onError(utteranceId: String?) {
                        Log.w(TAG, "TTS playback error on $utteranceId")
                    }
                })
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to instantiate TextToSpeech: ${e.message}")
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            isTtsReady = true
            // Prefer Hindi if available on device, fallback to Indian English
            val hiLocale = Locale("hi", "IN")
            val langResult = textToSpeech?.setLanguage(hiLocale)
            if (langResult == TextToSpeech.LANG_MISSING_DATA || langResult == TextToSpeech.LANG_NOT_SUPPORTED) {
                textToSpeech?.language = Locale("en", "IN")
                try {
                    val inEngVoices = textToSpeech?.voices?.filter { v ->
                        v.locale.language.equals("en", ignoreCase = true) && v.locale.country.equals("IN", ignoreCase = true)
                    }
                    val bestInEng = inEngVoices?.firstOrNull { it.name.contains("female", ignoreCase = true) } ?: inEngVoices?.firstOrNull()
                    if (bestInEng != null) textToSpeech?.voice = bestInEng
                } catch (_: Exception) {}
                Log.i(TAG, "Hindi TTS missing on device. Defaulted to natural en-IN voice.")
            } else {
                try {
                    val hindiVoices = textToSpeech?.voices?.filter { v ->
                        v.locale.language.equals("hi", ignoreCase = true)
                    }
                    val bestHindi = hindiVoices?.firstOrNull { it.name.contains("hie", ignoreCase = true) }
                        ?: hindiVoices?.firstOrNull { it.name.contains("hid", ignoreCase = true) }
                        ?: hindiVoices?.firstOrNull { it.name.contains("female", ignoreCase = true) }
                        ?: hindiVoices?.firstOrNull()
                    if (bestHindi != null) {
                        textToSpeech?.voice = bestHindi
                        Log.i(TAG, "Selected natural Hindi voice: ${bestHindi.name}")
                    }
                } catch (e: Exception) {
                    Log.w(TAG, "Voice selection warning: ${e.message}")
                }
                Log.i(TAG, "Android native Hindi TTS initialized successfully with natural voice.")
            }
            textToSpeech?.setSpeechRate(0.96f)
            textToSpeech?.setPitch(1.0f)
        } else {
            isTtsReady = false
            Log.w(TAG, "Native TextToSpeech initialization failed (code: $status).")
        }
    }

    /**
     * Starts listening for user speech with strict offline preference.
     */
    fun startListening(languageCode: String = "hi-IN") {
        val recognizer = speechRecognizer ?: run {
            onError("स्पीच रिकॉग्नाइज़र उपलब्ध नहीं है।")
            return
        }

        // Halt any current audio output immediately so mic does not capture speaker echo
        stopSpeaking()

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, languageCode)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, languageCode)
            putExtra(RecognizerIntent.EXTRA_ONLY_RETURN_LANGUAGE_PREFERENCE, false)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            // MANDATORY: Request on-device offline recognition package
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
        }

        try {
            recognizer.startListening(intent)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to start listening: ${e.message}")
            onError("माइक चालू करने में त्रुटि: ${e.localizedMessage}")
        }
    }

    fun stopListening() {
        try {
            speechRecognizer?.stopListening()
            isListeningActive = false
        } catch (_: Exception) {}
    }

    /**
     * Speaks text using native on-device Android TTS.
     * Guaranteed zero cloud API cost and immediate interruptibility.
     */
    fun speak(text: String, onComplete: (() -> Unit)? = null) {
        if (!isTtsReady || textToSpeech == null) {
            Log.w(TAG, "TTS not ready. Cannot speak offline text.")
            return
        }

        // Halt any current playback immediately
        stopSpeaking()

        // Clean markdown characters and links before feeding into TTS
        val cleanSpeech = text
            .replace(Regex("""[*_`#\[\]()]"""), "")
            .replace(Regex("""https?://\S+"""), "वेब लिंक")
            .take(600)

        textToSpeech?.speak(cleanSpeech, TextToSpeech.QUEUE_FLUSH, null, UTTERANCE_ID)
    }

    /**
     * Immediately interrupts audio output when user taps or speaks.
     */
    fun stopSpeaking() {
        try {
            textToSpeech?.stop()
        } catch (_: Exception) {}
    }

    fun isListening(): Boolean = isListeningActive

    fun release() {
        try {
            speechRecognizer?.destroy()
            textToSpeech?.shutdown()
        } catch (_: Exception) {}
    }
}
