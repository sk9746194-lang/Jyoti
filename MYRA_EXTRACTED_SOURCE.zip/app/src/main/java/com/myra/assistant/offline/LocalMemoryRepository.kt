package com.myra.assistant.offline

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.util.Log
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/**
 * LocalMemoryRepository — Zero-Cost Local SQLite & Room Database for MYRA.
 *
 * PRIVACY & ZERO-CLOUD MANDATE:
 * - 100% on-device private database.
 * - ZERO remote cloud sync, remote transmission, or external telemetry.
 * - Full indexed search available when internet connection is lost.
 * - Full user autonomy: Search, Edit, Delete, Export as JSON, and Clear All.
 */
class LocalMemoryRepository(private val context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        private const val TAG = "MYRA_LocalMemoryRepo"
        private const val DATABASE_NAME = "myra_local_memory.db"
        private const val DATABASE_VERSION = 2

        private const val TABLE_MEMORIES = "local_memories"
        private const val COL_ID = "id"
        private const val COL_CATEGORY = "category"
        private const val COL_CONTENT = "content"
        private const val COL_TIMESTAMP = "timestamp"
        private const val COL_PINNED = "is_pinned"
        private const val COL_SEARCH_TOKENS = "search_tokens"

        // Search indexes for zero-latency offline memory query
        private const val IDX_CONTENT = "idx_memories_content"
        private const val IDX_CATEGORY = "idx_memories_category"
        private const val IDX_TOKENS = "idx_memories_tokens"
    }

    override fun onCreate(db: SQLiteDatabase) {
        // 1. Primary Table
        val createSql = """
            CREATE TABLE IF NOT EXISTS $TABLE_MEMORIES (
                $COL_ID TEXT PRIMARY KEY,
                $COL_CATEGORY TEXT NOT NULL,
                $COL_CONTENT TEXT NOT NULL,
                $COL_TIMESTAMP INTEGER NOT NULL,
                $COL_PINNED INTEGER NOT NULL DEFAULT 0,
                $COL_SEARCH_TOKENS TEXT NOT NULL DEFAULT ''
            )
        """.trimIndent()
        db.execSQL(createSql)

        // 2. High-performance offline search index
        db.execSQL("CREATE INDEX IF NOT EXISTS $IDX_CONTENT ON $TABLE_MEMORIES ($COL_CONTENT)")
        db.execSQL("CREATE INDEX IF NOT EXISTS $IDX_CATEGORY ON $TABLE_MEMORIES ($COL_CATEGORY)")
        db.execSQL("CREATE INDEX IF NOT EXISTS $IDX_TOKENS ON $TABLE_MEMORIES ($COL_SEARCH_TOKENS)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) {
            try {
                db.execSQL("ALTER TABLE $TABLE_MEMORIES ADD COLUMN $COL_SEARCH_TOKENS TEXT NOT NULL DEFAULT ''")
                db.execSQL("CREATE INDEX IF NOT EXISTS $IDX_CONTENT ON $TABLE_MEMORIES ($COL_CONTENT)")
                db.execSQL("CREATE INDEX IF NOT EXISTS $IDX_CATEGORY ON $TABLE_MEMORIES ($COL_CATEGORY)")
                db.execSQL("CREATE INDEX IF NOT EXISTS $IDX_TOKENS ON $TABLE_MEMORIES ($COL_SEARCH_TOKENS)")
            } catch (e: Exception) {
                Log.w(TAG, "Database upgrade migration fallback: ${e.message}")
            }
        }
    }

    private fun generateSearchTokens(content: String, category: String): String {
        val clean = "$content $category"
            .lowercase()
            .replace(Regex("[^a-z0-9\\s\\u0900-\\u097F]"), " ")
            .split(Regex("\\s+"))
            .filter { it.isNotBlank() && it.length > 1 }
            .distinct()
            .joinToString(" ")
        return clean
    }

    /**
     * Inserts a new memory item with indexed search tokens.
     */
    fun insertMemory(category: String, content: String, isPinned: Boolean = false): Boolean {
        if (content.isBlank()) return false
        val tokens = generateSearchTokens(content, category)

        return try {
            val db = writableDatabase
            val values = ContentValues().apply {
                put(COL_ID, UUID.randomUUID().toString())
                put(COL_CATEGORY, category.trim())
                put(COL_CONTENT, content.trim())
                put(COL_TIMESTAMP, System.currentTimeMillis())
                put(COL_PINNED, if (isPinned) 1 else 0)
                put(COL_SEARCH_TOKENS, tokens)
            }
            val rowId = db.insertWithOnConflict(TABLE_MEMORIES, null, values, SQLiteDatabase.CONFLICT_REPLACE)
            rowId != -1L
        } catch (e: Exception) {
            Log.e(TAG, "Error inserting local memory: ${e.message}")
            false
        }
    }

    /**
     * Fetches all memories ordered by pinned first, then newest.
     */
    fun getAllMemories(): List<LocalMemoryEntity> {
        val list = mutableListOf<LocalMemoryEntity>()
        return try {
            val db = readableDatabase
            val cursor = db.query(
                TABLE_MEMORIES,
                null,
                null,
                null,
                null,
                null,
                "$COL_PINNED DESC, $COL_TIMESTAMP DESC"
            )
            cursor.use { c ->
                while (c.moveToNext()) {
                    list.add(extractFromCursor(c))
                }
            }
            list
        } catch (e: Exception) {
            Log.e(TAG, "Error fetching all local memories: ${e.message}")
            list
        }
    }

    /**
     * Searches memories by keyword using indexed content, category, and search tokens.
     * Guaranteed 100% offline with zero cloud requests.
     */
    fun searchMemories(keyword: String): List<LocalMemoryEntity> {
        if (keyword.isBlank()) return getAllMemories()
        val list = mutableListOf<LocalMemoryEntity>()
        val cleanKeyword = keyword.trim().lowercase()

        return try {
            val db = readableDatabase
            val cursor = db.query(
                TABLE_MEMORIES,
                null,
                "$COL_CONTENT LIKE ? OR $COL_CATEGORY LIKE ? OR $COL_SEARCH_TOKENS LIKE ?",
                arrayOf("%$cleanKeyword%", "%$cleanKeyword%", "%$cleanKeyword%"),
                null,
                null,
                "$COL_PINNED DESC, $COL_TIMESTAMP DESC"
            )
            cursor.use { c ->
                while (c.moveToNext()) {
                    list.add(extractFromCursor(c))
                }
            }
            list
        } catch (e: Exception) {
            Log.e(TAG, "Error searching local memories: ${e.message}")
            list
        }
    }

    /**
     * Searches memories while enforcing personality privacy boundaries.
     * In professional / standard mode, romantic companion memories are strictly isolated.
     */
    fun searchMemoriesIsolated(keyword: String, currentPersonality: String): List<LocalMemoryEntity> {
        val results = searchMemories(keyword)
        return when (currentPersonality) {
            "professional", "friendly_assistant" -> results.filterNot { it.category.equals("companion", ignoreCase = true) }
            else -> results
        }
    }

    /**
     * Deletes a specific memory item.
     */
    fun deleteMemory(id: String): Boolean {
        return try {
            val db = writableDatabase
            val deletedRows = db.delete(TABLE_MEMORIES, "$COL_ID = ?", arrayOf(id))
            deletedRows > 0
        } catch (e: Exception) {
            Log.e(TAG, "Error deleting local memory: ${e.message}")
            false
        }
    }

    /**
     * Updates an existing memory item and regenerates search index tokens.
     */
    fun updateMemory(id: String, newContent: String, newCategory: String? = null): Boolean {
        return try {
            val db = writableDatabase
            val tokens = generateSearchTokens(newContent, newCategory ?: "preference")
            val values = ContentValues().apply {
                put(COL_CONTENT, newContent.trim())
                put(COL_SEARCH_TOKENS, tokens)
                if (newCategory != null) put(COL_CATEGORY, newCategory.trim())
            }
            db.update(TABLE_MEMORIES, values, "$COL_ID = ?", arrayOf(id)) > 0
        } catch (e: Exception) {
            Log.e(TAG, "Error updating local memory: ${e.message}")
            false
        }
    }

    /**
     * Clears only companion memories, preserving preferences and ongoing projects.
     */
    fun clearCompanionMemories(): Int {
        return try {
            val db = writableDatabase
            db.delete(TABLE_MEMORIES, "$COL_CATEGORY = ?", arrayOf("companion"))
        } catch (e: Exception) {
            Log.e(TAG, "Error clearing companion memories: ${e.message}")
            0
        }
    }

    /**
     * Exports all local memories as a formatted JSON string for user backup.
     */
    fun exportToJson(): String {
        val memories = getAllMemories()
        val arr = JSONArray()
        memories.forEach { m ->
            arr.put(JSONObject().apply {
                put("id", m.id)
                put("category", m.category)
                put("content", m.content)
                put("timestamp", m.timestamp)
                put("isPinned", m.isPinned)
            })
        }
        return arr.toString(2)
    }

    /**
     * Completely wipes all local memories (clear all).
     */
    fun clearAll(): Boolean {
        return try {
            val db = writableDatabase
            db.delete(TABLE_MEMORIES, null, null) >= 0
        } catch (e: Exception) {
            Log.e(TAG, "Error clearing all local memories: ${e.message}")
            false
        }
    }

    private fun extractFromCursor(c: android.database.Cursor): LocalMemoryEntity {
        return LocalMemoryEntity(
            id = c.getString(c.getColumnIndexOrThrow(COL_ID)),
            category = c.getString(c.getColumnIndexOrThrow(COL_CATEGORY)),
            content = c.getString(c.getColumnIndexOrThrow(COL_CONTENT)),
            timestamp = c.getLong(c.getColumnIndexOrThrow(COL_TIMESTAMP)),
            isPinned = c.getInt(c.getColumnIndexOrThrow(COL_PINNED)) == 1,
            searchTokens = c.getString(c.getColumnIndexOrThrow(COL_SEARCH_TOKENS))
        )
    }
}
