package com.myra.assistant.offline

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

/**
 * LocalMemoryDatabase — Room Database for MYRA Local Memory.
 *
 * STRICT PRIVACY & ZERO-CLOUD MANDATE:
 * - 100% on-device private SQLite database managed via Room.
 * - STRICTLY ISOLATED from cloud sync, remote backup, or network transmission.
 * - High-speed indexed local queries available when internet connection is lost.
 */
@Database(
    entities = [LocalMemoryEntity::class],
    version = 2,
    exportSchema = false
)
abstract class LocalMemoryDatabase : RoomDatabase() {

    abstract fun localMemoryDao(): LocalMemoryDao

    companion object {
        @Volatile
        private var INSTANCE: LocalMemoryDatabase? = null
        private const val DATABASE_NAME = "myra_local_memory_room.db"

        fun getInstance(context: Context): LocalMemoryDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    LocalMemoryDatabase::class.java,
                    DATABASE_NAME
                )
                    .fallbackToDestructiveMigration()
                    .allowMainThreadQueries() // Safe for small, indexed offline memory lookups
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
