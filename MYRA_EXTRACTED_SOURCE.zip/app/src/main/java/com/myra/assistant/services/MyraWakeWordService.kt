package com.myra.assistant.services

import com.myra.assistant.MainActivity
import com.myra.assistant.MyraApplication
import com.myra.assistant.data.PreferencesManager
import java.util.Locale
import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.*
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log
import androidx.core.app.NotificationCompat
import android.media.AudioManager
import android.media.AudioAttributes
import android.media.AudioFocusRequest

/**
 * Continuous SpeechRecognizer Wake Word Detection Foreground Service.
 *
 * ARCHITECTURAL CLARIFICATION:
 * This service operates using Android's native SpeechRecognizer in a continuous loop
 * within a foreground service (FOREGROUND_SERVICE_TYPE_MICROPHONE).
 *
 * Dedicated Offline Neural DSP Wake-Word Engines Comparison:
 * - Commercial offline neural engines (e.g. Picovoice Porcupine) require proprietary C++
 *   shared libraries (.so), device-tied access keys, and per-activation licensing.
 * - Open-source ONNX engines (e.g. openWakeWord) require heavy ONNX runtime binaries
 *   and continuous ~15% CPU load when running purely in software on mobile CPUs.
 * - Android's native HotwordDetectionService (Android 12+) is strictly restricted to system
 *   partition apps or system-privileged assistant roles.
 *
 * Therefore, MyraWakeWordService uses Android's SpeechRecognizer with audio focus awareness
 * and screen-state power throttling, preserving Gemini Live WebSocket as the primary conversational system.
 */
class MyraWakeWordService : Service() {

    private val TAG = "MYRA_WakeWordService"
    private val NOTIFICATION_ID = 2026

    private var speechRecognizer: SpeechRecognizer? = null
    private var audioManager: AudioManager? = null
    private var audioFocusRequest: AudioFocusRequest? = null
    private var hasAudioFocus = false
    private var isListening = false
    private var isDestroyed = false
    private var listeningPaused = false
    private var wakeWordTriggered = false
    private var wakeLock: PowerManager.WakeLock? = null
    private val handler = Handler(Looper.getMainLooper())

    private val audioFocusChangeListener = AudioManager.OnAudioFocusChangeListener { focusChange ->
        when (focusChange) {
            AudioManager.AUDIOFOCUS_LOSS,
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> {
                Log.i(TAG, "Audio focus lost; pausing wake-word recognizer.")
                hasAudioFocus = false
                try {
                    speechRecognizer?.stopListening()
                    isListening = false
                } catch (_: Exception) {}
            }
            AudioManager.AUDIOFOCUS_GAIN -> {
                Log.i(TAG, "Audio focus regained; resuming wake-word listener.")
                hasAudioFocus = true
                scheduleRestart(500)
            }
        }
    }

    private val restartRunnable = Runnable {
        if (!isDestroyed) {
            startWakeWordListening()
        }
    }

    override fun onCreate() {
        super.onCreate()
        isRunning = true
        acquireCpuWakeLock()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP_SERVICE) {
            stopSelf()
            return START_NOT_STICKY
        }

        val openIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val stopIntent = PendingIntent.getService(
            this,
            1,
            Intent(this, MyraWakeWordService::class.java).apply {
                action = ACTION_STOP_SERVICE
            },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val notification: Notification = NotificationCompat.Builder(this, MyraApplication.CHANNEL_ID_VOICE_SERVICE)
            .setContentTitle("MYRA Hands-Free Voice Active")
            .setContentText("Listening for 'Hey MYRA' / 'मायरा' / Voice Commands...")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setOngoing(true)
            .setContentIntent(openIntent)
            .addAction(android.R.drawable.ic_media_play, "Open MYRA", openIntent)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop Hands-Free", stopIntent)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }

        when (intent?.action) {
    ACTION_PAUSE_LISTENING -> {
        pauseListeningForAssistant()
        return START_STICKY
    }
    ACTION_RESUME_LISTENING -> {
        listeningPaused = false
        wakeWordTriggered = false
        initAndStartListening()
        return START_STICKY
    }
}

initAndStartListening()
return START_STICKY
    }

    private fun acquireCpuWakeLock() {
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "myra:wakeword_cpu_lock").apply {
                setReferenceCounted(false)
                acquire(24 * 60 * 60 * 1000L) // 24 hours max
            }
        } catch (e: Exception) {
            Log.w(TAG, "Failed to acquire partial wake lock", e)
        }
    }

    private fun initAndStartListening() {
        handler.post {
            try {
                if (SpeechRecognizer.isRecognitionAvailable(this)) {
                    speechRecognizer?.destroy()
                    speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
                        setRecognitionListener(createListener())
                    }
                    startWakeWordListening()
                } else {
                    Log.e(TAG, "Speech recognition unavailable on this device")
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error initializing speech recognizer for wake word", e)
                scheduleRestart(2000)
            }
        }
    }

    private fun startWakeWordListening() {
        if (isDestroyed || listeningPaused || wakeWordTriggered) return
        val prefs = PreferencesManager(this)
        if (!prefs.isHandsFreeWakeWordEnabled) {
            Log.i(TAG, "Hands-free wake word is disabled in preferences; pausing listener")
            return
        }

        try {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
            }

            speechRecognizer?.startListening(intent)
            isListening = true
            Log.d(TAG, "Wake word listening started successfully")
        } catch (e: Exception) {
            Log.w(TAG, "startListening failed: ${e.message}")
            scheduleRestart(1000)
        }
    }

    private fun scheduleRestart(delayMs: Long) {
        handler.removeCallbacks(restartRunnable)
        if (!isDestroyed && !listeningPaused && !wakeWordTriggered) {
            handler.postDelayed(restartRunnable, delayMs.coerceAtLeast(900L))
        }
    }

    private fun createListener() = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}

        override fun onError(error: Int) {
            isListening = false
            if (listeningPaused || wakeWordTriggered || isDestroyed) return
            // SpeechRecognizer errors like NO_MATCH or SPEECH_TIMEOUT are normal during idle listening
            val delay = when (error) {
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> 800L
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> 5000L
                else -> 400L
            }
            scheduleRestart(delay)
        }

        override fun onResults(results: Bundle?) {
            isListening = false
            if (listeningPaused || wakeWordTriggered || isDestroyed) return
            val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            if (!matches.isNullOrEmpty()) {
                val detectedText = matches[0]
                Log.d(TAG, "Speech heard: '$detectedText'")
                if (checkWakeWordTrigger(detectedText)) {
                    handleWakeWordTriggered(detectedText)
                    return
                }
            }
            scheduleRestart(250)
        }

        override fun onPartialResults(partialResults: Bundle?) {
            val partialMatches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            if (!partialMatches.isNullOrEmpty()) {
                val partialText = partialMatches[0]
                if (!wakeWordTriggered && !listeningPaused && checkWakeWordTrigger(partialText)) {
                    handleWakeWordTriggered(partialText)
                }
            }
        }

        override fun onEvent(eventType: Int, params: Bundle?) {}
    }

    private fun checkWakeWordTrigger(text: String): Boolean {
        val lower = text.lowercase(Locale.ROOT).trim()
        val triggers = listOf(
            "hey myra", "myra", "mayra", "mira",
            "मायरा", "हे मायरा", "सुनो मायरा", "नमस्ते मायरा", "हेलो मायरा", "हाय मायरा",
            "hello myra", "hi myra", "ok myra", "suno myra", "namaste myra"
        )
        return triggers.any { lower.contains(it) }
    }

    private fun handleWakeWordTriggered(rawSpeech: String) {
        if (wakeWordTriggered || listeningPaused || isDestroyed) return
        wakeWordTriggered = true
        isListening = false
        handler.removeCallbacks(restartRunnable)
        try { speechRecognizer?.cancel() } catch (_: Exception) {}
        Log.i(TAG, "HOTWORD DETECTED! Waking screen and launching MYRA...")

        // 1. Vibrate feedback
        try {
            val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vm = getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
                vm.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 70, 40, 90), -1))
            } else {
                @Suppress("DEPRECATION")
                vibrator.vibrate(longArrayOf(0, 70, 40, 90), -1)
            }
        } catch (_: Exception) {}

        // 2. Turn screen on and wake up device (even from lock screen / screen off)
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            @Suppress("DEPRECATION")
            val screenWakeLock = pm.newWakeLock(
                PowerManager.SCREEN_BRIGHT_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP or PowerManager.ON_AFTER_RELEASE,
                "myra:wake_screen_lock"
            )
            screenWakeLock.acquire(10000) // 10 seconds
        } catch (e: Exception) {
            Log.w(TAG, "Could not turn screen on with wake lock", e)
        }

        // 3. Extract any follow-up command spoken in the same breath (e.g., "Hey MYRA torch on karo" -> "torch on karo")
        var followUpCommand = ""
        val triggers = listOf(
            "hey myra", "myra", "mayra", "mira",
            "मायरा", "हे मायरा", "सुनो मायरा", "नमस्ते मायरा", "हेलो मायरा", "हाय मायरा",
            "hello myra", "hi myra", "ok myra", "suno myra", "namaste myra"
        )
        val lower = rawSpeech.lowercase(Locale.ROOT)
        for (trig in triggers) {
            val idx = lower.indexOf(trig)
            if (idx != -1) {
                followUpCommand = rawSpeech.substring(idx + trig.length).trim(' ', ',', '.', '!', '?')
                break
            }
        }

        // 4. Launch MainActivity with lockscreen bypass & voice auto-start flags
        val launchIntent = Intent(this, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            putExtra(EXTRA_AUTO_START_VOICE, true)
            putExtra(EXTRA_TRIGGER_SOURCE, "wake_word")
            if (followUpCommand.isNotBlank()) {
                putExtra(EXTRA_FOLLOW_UP_COMMAND, followUpCommand)
            }
        }

        try {
            startActivity(launchIntent)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to start MainActivity from wake word service", e)
        }

        // Do not restart the wake recognizer while MainActivity owns the microphone.
        // MainActivity explicitly resumes this service when it moves to the background.
    }

    private fun pauseListeningForAssistant() {
listeningPaused = true
isListening = false
handler.removeCallbacks(restartRunnable)
try {
    speechRecognizer?.cancel()
    speechRecognizer?.destroy()
} catch (e: Exception) {
    Log.w(TAG, "Recognizer pause cleanup failed", e)
}
speechRecognizer = null
Log.i(TAG, "Wake recognizer paused; assistant now owns the microphone")
}

override fun onDestroy() {
        super.onDestroy()
        isDestroyed = true
        isRunning = false
        handler.removeCallbacksAndMessages(null)
        try {
            speechRecognizer?.destroy()
            speechRecognizer = null
        } catch (_: Exception) {}

        try {
            wakeLock?.let {
                if (it.isHeld) it.release()
            }
        } catch (_: Exception) {}
        Log.i(TAG, "MyraWakeWordService destroyed")
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_STOP_SERVICE = "com.myra.assistant.ACTION_STOP_WAKE_WORD"
        const val ACTION_PAUSE_LISTENING = "com.myra.assistant.ACTION_PAUSE_WAKE_LISTENING"
        const val ACTION_RESUME_LISTENING = "com.myra.assistant.ACTION_RESUME_WAKE_LISTENING"
        const val ACTION_PAUSE_LISTENING = "com.myra.assistant.ACTION_PAUSE_WAKE_LISTENING"
        const val ACTION_RESUME_LISTENING = "com.myra.assistant.ACTION_RESUME_WAKE_LISTENING"
        const val EXTRA_AUTO_START_VOICE = "AUTO_START_VOICE"
        const val EXTRA_TRIGGER_SOURCE = "TRIGGER_SOURCE"
        const val EXTRA_FOLLOW_UP_COMMAND = "FOLLOW_UP_COMMAND"

        var isRunning: Boolean = false
            private set

        fun start(context: Context) {
            val intent = Intent(context, MyraWakeWordService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun pauseForAssistant(context: Context) {
    val intent = Intent(context, MyraWakeWordService::class.java).apply { action = ACTION_PAUSE_LISTENING }
    context.startService(intent)
}

fun resumeWhenAppBackgrounded(context: Context) {
    val intent = Intent(context, MyraWakeWordService::class.java).apply { action = ACTION_RESUME_LISTENING }
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(intent)
    else context.startService(intent)
}

fun stop(context: Context) {
            val intent = Intent(context, MyraWakeWordService::class.java).apply {
                action = ACTION_STOP_SERVICE
            }
            context.startService(intent)
        }
    }
}
