package com.myra.assistant.quota

/**
 * Manages conversational context window to minimize prompt token bloat
 * while preserving multi-turn conversational coherence.
 *
 * TOKEN OPTIMIZATION POLICY:
 * - Slides window over the most recent 8-10 turns.
 * - Truncates excessively long turns to 300 characters each.
 * - Injects persistent personal memory points without blowing up the context window.
 */
class ConversationContextManager {

    companion object {
        const val MAX_HISTORY_TURNS = 8
        const val MAX_CHARS_PER_TURN = 350
    }

    /**
     * Compacts conversation history turns into an efficient token-friendly list.
     */
    fun compactHistory(rawHistory: List<Pair<String, String>>): List<Pair<String, String>> {
        if (rawHistory.isEmpty()) return emptyList()

        val recentTurns = rawHistory.takeLast(MAX_HISTORY_TURNS)
        return recentTurns.map { (sender, text) ->
            val compactedText = if (text.length > MAX_CHARS_PER_TURN) {
                text.take(MAX_CHARS_PER_TURN) + "..."
            } else {
                text
            }
            Pair(sender, compactedText)
        }
    }
}
