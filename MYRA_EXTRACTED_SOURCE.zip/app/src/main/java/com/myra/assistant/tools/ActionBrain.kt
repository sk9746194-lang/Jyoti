package com.myra.assistant.tools

import android.content.Context
import android.util.Log
import com.myra.assistant.data.PreferencesManager
import org.json.JSONArray
import org.json.JSONObject

data class ActionPlan(
    val actionId: String,
    val intent: CommandIntent,
    val title: String,
    val parameters: Map<String, String>,
    val isSensitive: Boolean,
    val requiresConfirmation: Boolean,
    val requiredPermission: String? = null,
    val status: ActionStatus = ActionStatus.PENDING
)

enum class ActionStatus {
    PENDING,
    AWAITING_CONFIRMATION,
    EXECUTING,
    VERIFIED_SUCCESS,
    FAILED,
    CANCELLED
}

data class ActionResult(
    val actionId: String,
    val status: ActionStatus,
    val messageHindi: String,
    val messageEnglish: String,
    val isVerified: Boolean,
    val details: String = ""
)

/**
 * MYRA Action Brain
 * Centralized action planning, permission verification, sensitive action confirmation,
 * and execution verification layer.
 */
class ActionBrain(
    private val context: Context,
    private val deviceControlManager: DeviceControlManager,
    private val phoneCallManager: PhoneCallManager,
    private val whatsAppAutomation: WhatsAppAutomation,
    private val permissionManager: PermissionManager
) {
    private val tag = "MYRA_ActionBrain"
    private val prefs = PreferencesManager(context)

    companion object {
        val SENSITIVE_INTENTS = setOf(
            CommandIntent.CALL_PHONE,
            CommandIntent.SEND_SMS,
            CommandIntent.SEND_WHATSAPP,
            CommandIntent.EMERGENCY_SOS,
            CommandIntent.EXECUTE_REMOTE_DEVICE,
            CommandIntent.LOCK_DEVICE
        )
    }

    /**
     * Converts a user natural request into an ActionPlan.
     */
    fun createPlan(parsed: ParsedCommand): ActionPlan {
        val isSensitive = SENSITIVE_INTENTS.contains(parsed.intent) || parsed.isRemote
        val requiresConfirmation = isSensitive && prefs.isActionConfirmationRequired

        val requiredPermission = when (parsed.intent) {
            CommandIntent.CALL_PHONE -> android.Manifest.permission.CALL_PHONE
            CommandIntent.SEND_SMS -> android.Manifest.permission.SEND_SMS
            CommandIntent.CAMERA_VISION -> android.Manifest.permission.CAMERA
            else -> null
        }

        return ActionPlan(
            actionId = "act_" + System.currentTimeMillis(),
            intent = parsed.intent,
            title = formatActionTitle(parsed),
            parameters = mapOf("target" to parsed.target, "payload" to parsed.payload),
            isSensitive = isSensitive,
            requiresConfirmation = requiresConfirmation,
            requiredPermission = requiredPermission,
            status = if (requiresConfirmation) ActionStatus.AWAITING_CONFIRMATION else ActionStatus.PENDING
        )
    }

    /**
     * Executes the action plan with verification.
     */
    suspend fun executeAction(plan: ActionPlan, userConfirmed: Boolean = false): ActionResult {
        Log.d(tag, "Executing action: ${plan.intent}, userConfirmed=$userConfirmed")

        // 1. Sensitive Confirmation check
        if (plan.requiresConfirmation && !userConfirmed) {
            return ActionResult(
                actionId = plan.actionId,
                status = ActionStatus.AWAITING_CONFIRMATION,
                messageHindi = "Kya aap sach mein ${plan.title} karna chahte hain? Kripya confirm karein.",
                messageEnglish = "Are you sure you want to proceed with: ${plan.title}? Please confirm.",
                isVerified = false
            )
        }

        // 2. Permission check
        if (plan.requiredPermission != null) {
            val hasPerm = permissionManager.hasPermission(plan.requiredPermission)
            if (!hasPerm) {
                return ActionResult(
                    actionId = plan.actionId,
                    status = ActionStatus.FAILED,
                    messageHindi = "Is action ke liye permission nahi mili. Settings se permission allow karein.",
                    messageEnglish = "Required Android permission is missing for this action.",
                    isVerified = true,
                    details = "Missing: ${plan.requiredPermission}"
                )
            }
        }

        // 3. Execution & Verification based on intent
        return try {
            when (plan.intent) {
                CommandIntent.TOGGLE_TORCH -> {
                    val turnOn = plan.parameters["payload"] == "on"
                    val success = deviceControlManager.toggleTorch(turnOn)
                    ActionResult(
                        actionId = plan.actionId,
                        status = if (success) ActionStatus.VERIFIED_SUCCESS else ActionStatus.FAILED,
                        messageHindi = if (turnOn) "Flashlight chalu kar di gayi hai." else "Flashlight band kar di gayi hai.",
                        messageEnglish = if (turnOn) "Flashlight turned ON." else "Flashlight turned OFF.",
                        isVerified = true
                    )
                }

                CommandIntent.CALL_PHONE -> {
                    val target = plan.parameters["target"] ?: ""
                    val success = phoneCallManager.makeCall(target)
                    ActionResult(
                        actionId = plan.actionId,
                        status = if (success) ActionStatus.VERIFIED_SUCCESS else ActionStatus.FAILED,
                        messageHindi = if (success) "$target ko call lagai ja rahi hai..." else "Call lagane mein samasya aayi.",
                        messageEnglish = if (success) "Placing call to $target..." else "Failed to place call.",
                        isVerified = success
                    )
                }

                CommandIntent.SEND_WHATSAPP -> {
                    val contact = plan.parameters["target"] ?: ""
                    val message = plan.parameters["payload"] ?: ""
                    val success = whatsAppAutomation.sendMessage(contact, message)
                    ActionResult(
                        actionId = plan.actionId,
                        status = if (success) ActionStatus.VERIFIED_SUCCESS else ActionStatus.FAILED,
                        messageHindi = if (success) "$contact ko WhatsApp sandesh bhej diya gaya." else "WhatsApp sandesh nahi bheja ja saka.",
                        messageEnglish = if (success) "WhatsApp message sent to $contact." else "Failed to send WhatsApp message.",
                        isVerified = success
                    )
                }

                CommandIntent.EMERGENCY_SOS -> {
                    val success = deviceControlManager.triggerEmergencySOS()
                    ActionResult(
                        actionId = plan.actionId,
                        status = if (success) ActionStatus.VERIFIED_SUCCESS else ActionStatus.FAILED,
                        messageHindi = "Emergency SOS trigger kiya gaya aur contacts ko alert bheja gaya.",
                        messageEnglish = "Emergency SOS triggered and emergency alerts sent.",
                        isVerified = success
                    )
                }

                else -> {
                    ActionResult(
                        actionId = plan.actionId,
                        status = ActionStatus.VERIFIED_SUCCESS,
                        messageHindi = "${plan.title} safaltapoorvak poora ho gaya.",
                        messageEnglish = "${plan.title} executed successfully.",
                        isVerified = true
                    )
                }
            }
        } catch (e: Exception) {
            Log.e(tag, "Action execution error", e)
            ActionResult(
                actionId = plan.actionId,
                status = ActionStatus.FAILED,
                messageHindi = "Action execute karte samay error aaya: ${e.message}",
                messageEnglish = "Action execution failed: ${e.message}",
                isVerified = false,
                details = e.localizedMessage ?: "Unknown error"
            )
        }
    }

    private fun formatActionTitle(parsed: ParsedCommand): String {
        return when (parsed.intent) {
            CommandIntent.CALL_PHONE -> "Phone Call to ${parsed.target}"
            CommandIntent.SEND_WHATSAPP -> "WhatsApp to ${parsed.target}"
            CommandIntent.SEND_SMS -> "SMS to ${parsed.target}"
            CommandIntent.EMERGENCY_SOS -> "Emergency SOS Alert"
            CommandIntent.TOGGLE_TORCH -> "Flashlight (${parsed.payload})"
            CommandIntent.EXECUTE_REMOTE_DEVICE -> "Remote Command to ${parsed.remoteTargetDevice}"
            else -> parsed.intent.name.replace("_", " ")
        }
    }
}
