package com.myra.assistant.offline

import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.os.BatteryManager
import android.provider.Settings
import android.util.Log
import com.myra.assistant.tools.AppLauncher
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Result of an offline deterministic command execution.
 */
data class OfflineCommandResult(
    val isHandled: Boolean,
    val spokenReply: String,
    val actionType: String? = null,
    val details: String = ""
)

/**
 * OfflineCommandEngine — Deterministic Zero-Cost Local Intent Router for MYRA.
 *
 * ZERO-CLOUD & ZERO-COST PRINCIPLE:
 * - Executes immediately on-device in under 5ms with ZERO network requests.
 * - Understands natural Hindi, Hinglish, and English phrasing.
 * - Controls hardware, apps, settings, battery, and time without any Gemini API tokens.
 */
class OfflineCommandEngine(private val context: Context) {

    companion object {
        private const val TAG = "MYRA_OfflineEngine"
    }

    private val appLauncher = AppLauncher(context)

    /**
     * Attempts to execute the command locally without touching any cloud API.
     */
    fun processCommand(input: String): OfflineCommandResult {
        val query = input.trim().lowercase()
        if (query.isBlank()) {
            return OfflineCommandResult(false, "कृपया कोई कमांड बोलिए।")
        }

        // 1. TORCH / FLASHLIGHT
        if (query.contains("torch") || query.contains("flashlight") || query.contains("लाइट") || query.contains("टॉर्च")) {
            val turnOff = query.contains("band") || query.contains("off") || query.contains("bujhao") || query.contains("बंद")
            val state = !turnOff
            val success = setTorchState(state)
            val msg = if (success) {
                if (state) "टॉर्च चालू कर दी गई है।" else "टॉर्च बंद कर दी गई है।"
            } else {
                "टॉर्च कंट्रोल करने में असमर्थ (कैमरा परमिशन आवश्यक)।"
            }
            return OfflineCommandResult(true, msg, "toggle_flashlight", "State: $state")
        }

        // 2. BATTERY STATUS
        if (query.contains("battery") || query.contains("चार्जिंग") || query.contains("बैटरी") || query.contains("charge")) {
            val batteryStatus = getBatteryStatus()
            return OfflineCommandResult(true, batteryStatus, "get_battery")
        }

        // 3. TIME AND DATE
        if (query.contains("time") || query.contains("samay") || query.contains("समय") || query.contains("baje") || query.contains("कितने बजे")) {
            val timeStr = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())
            return OfflineCommandResult(true, "अभी समय $timeStr हुआ है।", "get_time")
        }

        if (query.contains("date") || query.contains("taarikh") || query.contains("तारीख") || query.contains("aaj ka din") || query.contains("दिनांक")) {
            val dateStr = SimpleDateFormat("EEEE, dd MMMM yyyy", Locale("hi", "IN")).format(Date())
            return OfflineCommandResult(true, "आज $dateStr है।", "get_date")
        }

        // 4. VOLUME CONTROLS
        if (query.contains("volume") || query.contains("aawaz") || query.contains("आवाज") || query.contains("sound")) {
            val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
            if (audioManager != null) {
                if (query.contains("up") || query.contains("badhao") || query.contains("zyada") || query.contains("बढ़ाओ")) {
                    audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
                    return OfflineCommandResult(true, "वॉल्यूम बढ़ा दिया गया है।", "volume_up")
                }
                if (query.contains("down") || query.contains("kam") || query.contains("ghatao") || query.contains("कम")) {
                    audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
                    return OfflineCommandResult(true, "वॉल्यूम कम कर दिया गया है।", "volume_down")
                }
                if (query.contains("mute") || query.contains("silent") || query.contains("म्यूट")) {
                    audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, 0, AudioManager.FLAG_SHOW_UI)
                    return OfflineCommandResult(true, "फोन म्यूट कर दिया गया है।", "volume_mute")
                }
            }
        }

        // 5. OPEN POPULAR APPS VIA INTENT
        val appMatches = mapOf(
            "whatsapp" to "WhatsApp",
            "व्हाट्सएप" to "WhatsApp",
            "youtube" to "YouTube",
            "यूट्यूब" to "YouTube",
            "camera" to "Camera",
            "कैमरा" to "Camera",
            "settings" to "Settings",
            "सेटिंग्स" to "Settings",
            "gallery" to "Gallery",
            "गैलरी" to "Gallery",
            "chrome" to "Chrome",
            "क्रोम" to "Chrome",
            "maps" to "Maps",
            "मैप्स" to "Maps",
            "calculator" to "Calculator",
            "कैलकुलेटर" to "Calculator",
            "spotify" to "Spotify",
            "स्पॉटीफाई" to "Spotify"
        )

        for ((trigger, appName) in appMatches) {
            if ((query.contains("kholo") || query.contains("open") || query.contains("chalao") || query.contains("खोलो")) && query.contains(trigger)) {
                val launched = appLauncher.launchAppByName(appName)
                val reply = if (launched) "$appName खोला जा रहा है..." else "$appName ऐप फोन में नहीं मिला।"
                return OfflineCommandResult(true, reply, "open_app", appName)
            }
        }

        // 6. OPEN SYSTEM SETTINGS DIRECTLY
        if (query.contains("wifi setting") || query.contains("वाईफाई सेटिंग")) {
            openSystemSetting(Settings.ACTION_WIFI_SETTINGS)
            return OfflineCommandResult(true, "Wi-Fi सेटिंग्स खोली जा रही हैं।", "open_settings")
        }
        if (query.contains("bluetooth setting") || query.contains("ब्लूटूथ")) {
            openSystemSetting(Settings.ACTION_BLUETOOTH_SETTINGS)
            return OfflineCommandResult(true, "ब्लूटूथ सेटिंग्स खोली जा रही हैं।", "open_settings")
        }
        if (query.contains("display setting") || query.contains("screen setting")) {
            openSystemSetting(Settings.ACTION_DISPLAY_SETTINGS)
            return OfflineCommandResult(true, "डिस्प्ले सेटिंग्स खोली जा रही हैं।", "open_settings")
        }

        // 7. CANCEL / STOP
        if (query.contains("ruk jao") || query.contains("stop") || query.contains("cancel") || query.contains("चुप") || query.contains("रुक जाओ")) {
            return OfflineCommandResult(true, "ठीक है, टास्क रोक दिया गया है।", "stop_task")
        }

        // 8. LOCAL-ONLY OFFLINE MEMORY SEARCH INDEX (ROOM DATABASE)
        if (query.contains("memory") || query.contains("याद") || query.contains("yaad") || query.contains("notes") || query.contains("नोट्स")) {
            val memoryRepo = LocalMemoryRepository(context)
            val keyword = query
                .replace(Regex("(memory|याद|yaad|notes|नोट्स|mein|me|dhoondo|search|dekho|kya hai|batao|hai|karo|what is|find|my|mera|meri)"), " ")
                .trim()

            val memories = if (keyword.length > 1) {
                memoryRepo.searchMemories(keyword)
            } else {
                memoryRepo.getAllMemories().take(3)
            }

            if (memories.isNotEmpty()) {
                val summary = memories.take(3).joinToString("; ") { "[${it.category.uppercase()}] ${it.content}" }
                val reply = "आपकी ऑफलाइन मेमोरी में मिला: $summary"
                return OfflineCommandResult(true, reply, "search_offline_memory", "Found ${memories.size} records")
            } else {
                return OfflineCommandResult(true, "आपकी लोकल मेमोरी में इस बारे में कोई सेव्ड रिकॉर्ड नहीं मिला।", "search_offline_memory", "0 records")
            }
        }

        // Not a deterministic offline hardware command
        return OfflineCommandResult(false, "")
    }

    private fun setTorchState(enable: Boolean): Boolean {
        return try {
            val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as? CameraManager
            val cameraId = cameraManager?.cameraIdList?.firstOrNull() ?: return false
            cameraManager.setTorchMode(cameraId, enable)
            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to toggle torch: ${e.message}")
            false
        }
    }

    private fun getBatteryStatus(): String {
        return try {
            val batteryManager = context.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager
            val level = batteryManager?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) ?: -1
            val isCharging = batteryManager?.isCharging == true
            val chargingText = if (isCharging) "और चार्जिंग जारी है" else "और डिस्चार्ज हो रही है"
            if (level >= 0) "फोन की बैटरी $level% है $chargingText।" else "बैटरी स्तर प्राप्त नहीं हो सका।"
        } catch (_: Exception) {
            "बैटरी जानकारी उपलब्ध नहीं है।"
        }
    }

    private fun openSystemSetting(action: String) {
        try {
            val intent = Intent(action).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            Log.e(TAG, "Cannot launch settings intent: ${e.message}")
        }
    }
}
