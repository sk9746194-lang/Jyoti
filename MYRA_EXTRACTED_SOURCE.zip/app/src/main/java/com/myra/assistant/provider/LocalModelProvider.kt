package com.myra.assistant.provider

import android.app.ActivityManager
import android.content.Context
import android.os.PowerManager
import android.os.StatFs
import android.util.Log
import com.myra.assistant.offline.LocalMemoryRepository
import com.myra.assistant.offline.OfflineModeManager
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import java.io.File
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig
import com.google.ai.edge.litertlm.Conversation
import kotlinx.coroutines.flow.collect
import kotlin.coroutines.coroutineContext

/**
 * Benchmark Results for On-Device Model on Motorola Moto g34 5G.
 */
data class LocalModelBenchmarkResult(
    val modelName: String,
    val contextWindowTokens: Int,
    val maxTokens: Int,
    val cpuThreadsUsed: Int,
    val timeToFirstTokenMs: Long,
    val totalInferenceTimeMs: Long,
    val generatedTokenCount: Int,
    val tokensPerSecond: Double,
    val memoryUsageMb: Long,
    val thermalStatus: String,
    val passedStabilityCheck: Boolean
)

/**
 * Callback interface for streaming local model tokens to UI.
 */
interface LocalModelStreamListener {
    fun onTokenGenerated(token: String)
    fun onMetricsUpdated(tokensPerSec: Double, elapsedMs: Long)
    fun onComplete(fullResponse: String, totalLatencyMs: Long)
    fun onError(errorMessage: String)
}

/**
 * Device Hardware Compatibility Report.
 */
data class DeviceHardwareReport(
    val totalRamMb: Long,
    val availableRamMb: Long,
    val isRamSufficient: Boolean,
    val freeStorageMb: Long,
    val isStorageSufficient: Boolean,
    val isCompatible: Boolean,
    val recommendation: String
)

/**
 * LocalModelProvider — Real Google AI Edge / LiteRT-LM Inference Engine for Motorola Moto g34 5G.
 *
 * SPECIFICATION & HARDWARE TUNING:
 * - Device: Motorola Moto g34 5G (Snapdragon 695 5G, 8GB Physical RAM, Android 15)
 * - Supported Models:
 *     1. Gemma 3 1B IT (.litertlm, ~656 MB, ~950 MB working RAM) [Recommended Default]
 *     2. Gemma 4 E2B IT (.litertlm, ~2.41 GB, ~1.8 GB working RAM) [High Capacity]
 * - Official Runtime: Google AI Edge LiteRT-LM (com.google.ai.edge.litertlm)
 *     Engine, EngineConfig, Conversation, sendMessageAsync (Flow<String>)
 * - Prompt Format: Gemma 3 Chat Template (<start_of_turn>user / <end_of_turn> / <start_of_turn>model)
 * - Memory & Isolation: Reads Room database strictly offline (zero cloud sync).
 * - ZERO SIMULATION POLICY: Never returns mock or hardcoded AI responses. If inference fails or
 *   model is missing, returns explicit error.
 */
class LocalModelProvider(private val context: Context) : BackendProvider {

    override val providerType = AIProviderType.LOCAL_ON_DEVICE
    override val displayName = "On-Device Local AI (Google LiteRT-LM / Gemma)"

    companion object {
        private const val TAG = "MYRA_LocalLiteRTLM"
        private const val MIN_REQUIRED_RAM_MB = 3800L
        private const val LOW_RAM_THRESHOLD_MB = 1200L
        private const val DEFAULT_CONTEXT_WINDOW = 2048
        private const val DEFAULT_MAX_GEN_TOKENS = 256

        @Volatile
        private var isModelLoaded = false
        private val lock = Any()
    }

    private val offlineModeMgr = OfflineModeManager.getInstance(context)
    private val localMemoryRepo = LocalMemoryRepository.getInstance(context)

    // Native LiteRT-LM Engine and Conversation handles
    private var nativeEngine: Engine? = null
    private var nativeConversation: Conversation? = null

    /**
     * Checks if the device has sufficient hardware resources for running on-device inference.
     */
    fun checkHardwareCompatibility(): DeviceHardwareReport {
        val metrics = offlineModeMgr.getDeviceResourceMetrics()
        val isRamSufficient = metrics.totalRamMb >= MIN_REQUIRED_RAM_MB && metrics.availableRamMb >= LOW_RAM_THRESHOLD_MB
        val isStorageSufficient = metrics.freeStorageMb >= 2048L
        val isCompatible = isRamSufficient && isStorageSufficient

        val recommendation = when {
            metrics.thermalState.isThrottling -> "डिवाइस तापमान अधिक है (${metrics.thermalState.statusName})। थ्रेड्स को 3 तक सीमित रखा जा रहा है।"
            !isRamSufficient -> "रैम अपर्याप्त है (${metrics.availableRamMb}MB उपलब्ध)। सुरक्षित संचालन के लिए न्यूनतम 1.2GB उपलब्ध रैम चाहिए।"
            !isStorageSufficient -> "स्टोरेज कम है (${metrics.freeStorageMb}MB)। ऑन-डिवाइस मॉडल के लिए कम से कम 2GB खाली स्पेस चाहिए।"
            else -> "Motorola Moto g34 5G पूरी तरह संगत है (${metrics.totalRamMb}MB RAM, ${metrics.freeStorageMb}MB Storage, 4 CPU Threads)।"
        }

        return DeviceHardwareReport(
            totalRamMb = metrics.totalRamMb,
            availableRamMb = metrics.availableRamMb,
            isRamSufficient = isRamSufficient,
            freeStorageMb = metrics.freeStorageMb,
            isStorageSufficient = isStorageSufficient,
            isCompatible = isCompatible,
            recommendation = recommendation
        )
    }

    override fun isAvailable(): Boolean {
        val modelFile = offlineModeMgr.modelFile
        return modelFile.exists() && modelFile.length() >= (offlineModeMgr.modelInfo.expectedSizeBytes * 95 / 100)
    }

    fun isLoadedInRam(): Boolean = synchronized(lock) { isModelLoaded }

    fun getModelFile(): File = offlineModeMgr.modelFile

    fun getModelSizeMb(): Long = if (isAvailable()) getModelFile().length() / (1024 * 1024) else 0L

    /**
     * Loads verified LiteRT-LM model weights into memory.
     * Enforces single loaded model in memory, threads, and dynamic RAM verification.
     */
    fun loadModelWeights(): Result<Boolean> = synchronized(lock) {
        if (!isAvailable()) {
            return Result.failure(
                IllegalStateException("LiteRT-LM मॉडल फ़ाइल स्थापित नहीं है। कृपया सेटिंग्स से सत्यापित मॉडल डाउनलोड करें (${offlineModeMgr.modelInfo.displayName})।")
            )
        }

        val metrics = offlineModeMgr.getDeviceResourceMetrics()
        if (metrics.availableRamMb < LOW_RAM_THRESHOLD_MB) {
            return Result.failure(
                IllegalStateException("उपलब्ध रैम अपर्याप्त है (${metrics.availableRamMb} MB)। बैकग्राउंड ऐप्स बंद करें।")
            )
        }

        try {
            Log.i(TAG, "Initializing LiteRT-LM native runtime for ${offlineModeMgr.modelInfo.displayName}...")
            val modelPath = offlineModeMgr.modelFile.absolutePath
            val threads = if (metrics.thermalState.isThrottling) 3 else offlineModeMgr.getCpuThreadConfig()
            val contextWindow = offlineModeMgr.getContextWindowConfig()

            // Initialize official com.google.ai.edge.litertlm.Engine
            val initialized = initNativeEngine(modelPath, threads, contextWindow)
            if (initialized) {
                isModelLoaded = true
                offlineModeMgr.setModelLoadedInRam()
                Log.i(TAG, "LiteRT-LM Engine successfully initialized. Threads: $threads, Context: $contextWindow")
                Result.success(true)
            } else {
                Result.failure(IllegalStateException("LiteRT-LM इंजन लोड करने में असमर्थ। कृपया फ़ाइल अखंडता जांचें।"))
            }
        } catch (e: Exception) {
            isModelLoaded = false
            Log.e(TAG, "Failed to load LiteRT-LM model weights: ${e.message}", e)
            Result.failure(e)
        }
    }

    /**
     * Unloads weights to release ~950MB to ~1.8GB of RAM back to Android OS.
     */
    fun unloadModelWeights() = synchronized(lock) {
        if (isModelLoaded || nativeEngine != null) {
            closeNativeHandles()
            isModelLoaded = false
            offlineModeMgr.unloadModelFromRam()
            System.gc()
            Log.i(TAG, "LiteRT-LM Engine unloaded from RAM.")
        }
    }

    /**
     * Deletes model file from storage and cleans up memory.
     */
    fun deleteModel(): Boolean {
        unloadModelWeights()
        return offlineModeMgr.deleteLocalModel()
    }

    override suspend fun testConnection(): Pair<Boolean, String> = withContext(Dispatchers.Default) {
        val hardware = checkHardwareCompatibility()
        if (!hardware.isCompatible) {
            return@withContext Pair(false, hardware.recommendation)
        }
        if (!isAvailable()) {
            return@withContext Pair(
                false,
                "${offlineModeMgr.modelInfo.displayName} मॉडल फ़ाइल इन्सटाल्ड नहीं है। सेटिंग्स में जाकर मॉडल डाउनलोड करें।"
            )
        }
        val loadedStr = if (isLoadedInRam()) "RAM में लोड है (Active)" else "स्टोरेज में सुरक्षित है (Ready to load)"
        Pair(true, "Moto g34 5G On-Device AI तैयार है: ${offlineModeMgr.modelInfo.displayName} (${getModelSizeMb()} MB, $loadedStr)")
    }

    /**
     * Executes local chat inference off-main-thread with isolated Room memory injection.
     * Returns true model responses or explicit failures; never returns mock text.
     */
    override suspend fun executeChat(request: AIRequest): Result<AIResponse> = withContext(Dispatchers.Default) {
        val hardware = checkHardwareCompatibility()
        if (!hardware.isRamSufficient) {
            return@withContext Result.failure(
                IllegalStateException("रैम सुरक्षा चेतावनी: सिस्टम को फ्रीज होने से बचाने के लिए लोकल इन्फरेंस रोका गया (${hardware.availableRamMb} MB उपलब्ध)।")
            )
        }

        if (!isAvailable()) {
            return@withContext Result.failure(
                IllegalStateException(
                    "ऑन-डिवाइस मॉडल फ़ाइल उपलब्ध नहीं है (${offlineModeMgr.modelInfo.displayName})। " +
                    "कृपया 'सेटिंग्स > ऑफ़लाइन AI' में जाकर मॉडल डाउनलोड करें।"
                )
            )
        }

        if (!isLoadedInRam()) {
            val loadResult = loadModelWeights()
            if (loadResult.isFailure) {
                return@withContext Result.failure(
                    loadResult.exceptionOrNull() ?: Exception("मॉडल लोड करने में विफलता।")
                )
            }
        }

        val startTime = System.currentTimeMillis()
        val configuredThreads = if (hardware.recommendation.contains("तापमान अधिक")) 3 else offlineModeMgr.getCpuThreadConfig()

        // 1. Retrieve personality-isolated Room memories strictly offline
        val personality = request.systemInstruction?.takeIf { it.isNotBlank() } ?: "assistant"
        val isCompanionMode = personality.contains("girlfriend", ignoreCase = true) || personality.contains("companion", ignoreCase = true)
        val isolatedMemories = try {
            localMemoryRepo.getPersonalityIsolatedMemories(isCompanionMode, limit = 5)
        } catch (_: Exception) {
            emptyList()
        }

        val memoryContext = if (isolatedMemories.isNotEmpty()) {
            "\n[OFFLINE ROOM MEMORY (ISOLATED)]:\n" + isolatedMemories.joinToString("\n") { "- [${it.category}]: ${it.content}" }
        } else ""

        // 2. Format prompt using official Gemma 3 Instruct chat template
        val prompt = buildGemmaPrompt(
            systemInstruction = request.systemInstruction ?: "You are MYRA, a helpful and affectionate on-device AI assistant.",
            memoryContext = memoryContext,
            userQuery = request.prompt
        )

        // 3. Perform real native LiteRT-LM inference
        val responseResult = runNativeInference(prompt, configuredThreads, DEFAULT_MAX_GEN_TOKENS)
        val totalLatency = System.currentTimeMillis() - startTime

        if (responseResult.isSuccess) {
            val responseText = responseResult.getOrThrow()
            Result.success(
                AIResponse(
                    text = responseText,
                    spokenSummary = responseText.take(200),
                    providerUsed = AIProviderType.LOCAL_ON_DEVICE,
                    modelUsed = offlineModeMgr.modelInfo.modelId,
                    latencyMs = totalLatency
                )
            )
        } else {
            Result.failure(responseResult.exceptionOrNull() ?: Exception("लोकल इन्फरेंस निष्पादन विफल"))
        }
    }

    /**
     * Streaming inference for real-time speech and UI generation.
     */
    suspend fun executeStreamingChat(
        request: AIRequest,
        streamListener: LocalModelStreamListener
    ) = withContext(Dispatchers.Default) {
        val startTime = System.currentTimeMillis()
        var firstTokenTime = 0L

        if (!isAvailable()) {
            streamListener.onError("ऑफ़लाइन मॉडल स्थापित नहीं है। कृपया सेटिंग्स से मॉडल डाउनलोड करें।")
            return@withContext
        }

        if (!isLoadedInRam()) {
            val loadRes = loadModelWeights()
            if (loadRes.isFailure) {
                streamListener.onError("मॉडल लोड नहीं हो सका: ${loadRes.exceptionOrNull()?.message}")
                return@withContext
            }
        }

        val fullResponse = StringBuilder()
        val threads = offlineModeMgr.getCpuThreadConfig()

        try {
            // Memory isolation
            val personality = request.systemInstruction ?: "assistant"
            val isCompanionMode = personality.contains("girlfriend", ignoreCase = true) || personality.contains("companion", ignoreCase = true)
            val isolatedMemories = try {
                localMemoryRepo.getPersonalityIsolatedMemories(isCompanionMode, limit = 5)
            } catch (_: Exception) {
                emptyList()
            }
            val memoryContext = if (isolatedMemories.isNotEmpty()) {
                "\n[OFFLINE ROOM MEMORY]:\n" + isolatedMemories.joinToString("\n") { "- [${it.category}]: ${it.content}" }
            } else ""

            val prompt = buildGemmaPrompt(personality, memoryContext, request.prompt)
            var tokenCount = 0

            runNativeStreamingInference(prompt, threads, DEFAULT_MAX_GEN_TOKENS) { token ->
                if (!coroutineContext.isActive) {
                    throw CancellationException("Chat inference cancelled by user")
                }
                if (tokenCount == 0) {
                    firstTokenTime = System.currentTimeMillis() - startTime
                }
                fullResponse.append(token)
                tokenCount++
                streamListener.onTokenGenerated(token)

                val elapsed = System.currentTimeMillis() - startTime
                val tps = if (elapsed > 0) (tokenCount.toDouble() / (elapsed / 1000.0)) else 0.0
                streamListener.onMetricsUpdated(tps, elapsed)
            }

            val totalTime = System.currentTimeMillis() - startTime
            streamListener.onComplete(fullResponse.toString(), totalTime)
        } catch (e: CancellationException) {
            Log.i(TAG, "Streaming inference cancelled.")
            streamListener.onError("इनपुट रद्द कर दिया गया।")
        } catch (e: Exception) {
            Log.e(TAG, "Streaming inference error: ${e.message}", e)
            streamListener.onError("इन्फरेंस त्रुटि: ${e.localizedMessage ?: "Unknown inference error"}")
        }
    }

    /**
     * Executes on-device benchmark without fabricating numbers.
     * Requires the model to actually be installed; otherwise reports accurately.
     */
    suspend fun runDeviceBenchmark(): LocalModelBenchmarkResult = withContext(Dispatchers.Default) {
        val startTime = System.currentTimeMillis()
        val metrics = offlineModeMgr.getDeviceResourceMetrics()
        val threads = offlineModeMgr.getCpuThreadConfig()
        val contextWindow = offlineModeMgr.getContextWindowConfig()

        if (!isAvailable()) {
            return@withContext LocalModelBenchmarkResult(
                modelName = offlineModeMgr.modelInfo.displayName,
                contextWindowTokens = contextWindow,
                maxTokens = DEFAULT_MAX_GEN_TOKENS,
                cpuThreadsUsed = threads,
                timeToFirstTokenMs = 0L,
                totalInferenceTimeMs = 0L,
                generatedTokenCount = 0,
                tokensPerSecond = 0.0,
                memoryUsageMb = metrics.totalRamMb - metrics.availableRamMb,
                thermalStatus = metrics.thermalState.statusName,
                passedStabilityCheck = false
            )
        }

        if (!isLoadedInRam()) {
            val res = loadModelWeights()
            if (res.isFailure) {
                return@withContext LocalModelBenchmarkResult(
                    modelName = offlineModeMgr.modelInfo.displayName,
                    contextWindowTokens = contextWindow,
                    maxTokens = DEFAULT_MAX_GEN_TOKENS,
                    cpuThreadsUsed = threads,
                    timeToFirstTokenMs = 0L,
                    totalInferenceTimeMs = 0L,
                    generatedTokenCount = 0,
                    tokensPerSecond = 0.0,
                    memoryUsageMb = metrics.totalRamMb - metrics.availableRamMb,
                    thermalStatus = "Load Error: ${res.exceptionOrNull()?.message}",
                    passedStabilityCheck = false
                )
            }
        }

        val benchmarkPrompt = buildGemmaPrompt(
            "You are a benchmark tester on Motorola Moto g34 5G.",
            "",
            "Say hello and count to 10."
        )

        var tokenCount = 0
        var ttft = 0L
        val tokenStartTime = System.currentTimeMillis()

        try {
            runNativeStreamingInference(benchmarkPrompt, threads, 64) { _ ->
                if (tokenCount == 0) {
                    ttft = System.currentTimeMillis() - tokenStartTime
                }
                tokenCount++
            }
        } catch (e: Exception) {
            Log.w(TAG, "Benchmark inference error: ${e.message}")
        }

        val totalTime = System.currentTimeMillis() - startTime
        val actualInferenceDuration = System.currentTimeMillis() - tokenStartTime
        val tps = if (actualInferenceDuration > 0 && tokenCount > 0) {
            (tokenCount.toDouble() / (actualInferenceDuration / 1000.0))
        } else 0.0

        val memInfo = ActivityManager.MemoryInfo()
        val actMgr = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
        actMgr?.getMemoryInfo(memInfo)
        val ramUsed = (memInfo.totalMem - memInfo.availMem) / (1024 * 1024)

        LocalModelBenchmarkResult(
            modelName = offlineModeMgr.modelInfo.displayName,
            contextWindowTokens = contextWindow,
            maxTokens = DEFAULT_MAX_GEN_TOKENS,
            cpuThreadsUsed = threads,
            timeToFirstTokenMs = ttft,
            totalInferenceTimeMs = totalTime,
            generatedTokenCount = tokenCount,
            tokensPerSecond = String.format("%.1f", tps).toDoubleOrNull() ?: 0.0,
            memoryUsageMb = ramUsed,
            thermalStatus = metrics.thermalState.statusName,
            passedStabilityCheck = !metrics.thermalState.isThrottling && tokenCount > 0
        )
    }

    /**
     * Builds Gemma 3 Instruct format with turn delimiters:
     * <start_of_turn>user\n${system}${memory}\n\nUser: ${query}<end_of_turn>\n<start_of_turn>model\n
     */
    private fun buildGemmaPrompt(systemInstruction: String, memoryContext: String, userQuery: String): String {
        return "<start_of_turn>user\n" +
                "$systemInstruction$memoryContext\n\n" +
                userQuery +
                "<end_of_turn>\n" +
                "<start_of_turn>model\n"
    }

    // =========================================================================
    // Native LiteRT-LM Engine Integration Layer (com.google.ai.edge.litertlm)
    // =========================================================================

    private fun initNativeEngine(modelPath: String, threads: Int, contextWindow: Int): Boolean {
        return try {
            // Official LiteRT-LM Kotlin API: EngineConfig(modelPath), Engine(config), initialize().
            val engine = Engine(EngineConfig(modelPath = modelPath))
            engine.initialize()
            val conversation = engine.createConversation()
            nativeEngine = engine
            nativeConversation = conversation
            true
        } catch (e: Exception) {
            Log.e(TAG, "LiteRT-LM direct API initialization failed: ${e.message}", e)
            closeNativeHandles()
            false
        }
    }

    private fun closeNativeHandles() {
        try { nativeConversation?.close() } catch (e: Exception) {
            Log.w(TAG, "Error closing conversation: ${e.message}")
        } finally { nativeConversation = null }
        try { nativeEngine?.close() } catch (e: Exception) {
            Log.w(TAG, "Error closing engine: ${e.message}")
        } finally { nativeEngine = null }
    }

    private suspend fun runNativeInference(prompt: String, threads: Int, maxTokens: Int): Result<String> {
        val resultBuilder = StringBuilder()
        return try {
            runNativeStreamingInference(prompt, threads, maxTokens) { chunk -> resultBuilder.append(chunk) }
            if (resultBuilder.isEmpty()) Result.failure(IllegalStateException("LiteRT-LM से कोई response नहीं मिला।"))
            else Result.success(resultBuilder.toString())
        } catch (e: Exception) { Result.failure(e) }
    }

    private suspend fun runNativeStreamingInference(
        prompt: String,
        threads: Int,
        maxTokens: Int,
        onToken: (String) -> Unit
    ) {
        val conversation = nativeConversation
            ?: throw IllegalStateException("LiteRT-LM Conversation सक्रिय नहीं है।")
        try {
            // Official API returns Flow<Message>; collection remains suspending and non-blocking.
            conversation.sendMessageAsync(prompt).collect { message ->
                val text = message.toString()
                if (text.isNotBlank()) onToken(text)
            }
        } catch (e: CancellationException) { throw e }
        catch (e: Exception) {
            Log.e(TAG, "LiteRT-LM inference failed: ${e.message}", e)
            throw (e.cause ?: e)
        }
    }
}
