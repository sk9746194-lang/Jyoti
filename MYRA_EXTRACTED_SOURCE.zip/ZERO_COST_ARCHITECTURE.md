# MYRA ZERO-COST & GEMINI-NATIVE ARCHITECTURE GUIDE
*मायरा शून्य-लागत एवं जेमिनी-डायरेक्ट आर्किटेक्चर गाइड (2026 Edition)*

---

## 1. Primary Architecture Overview (मुख्य संरचना)

MYRA का प्राथमिक सिद्धांत **ZERO-COST-FIRST** (शून्य अनिवार्य लागत) है।

```
┌──────────────────────────────────────────────────────────┐
│                   Android MYRA App                       │
│    (Native Kotlin, Jetpack Compose, Android Keystore)    │
└────────────────────────────┬─────────────────────────────┘
                             │
                             │ HTTPS Direct (x-goog-api-key)
                             │ Zero Intermediate Servers
                             ▼
┌──────────────────────────────────────────────────────────┐
│             Official Google Gemini API                   │
│        (https://generativelanguage.googleapis.com)       │
└────────────────────────────┬─────────────────────────────┘
                             │
                             ▼
┌──────────────────────────────────────────────────────────┐
│            Google Gemini AI Foundation Models            │
│       (gemini-3.8-flash, gemini-3.6-flash, 3.5-lite)     │
└──────────────────────────────────────────────────────────┘
```

### महत्वपूर्ण सिद्धांत:
1. **No Mandatory Third-Party Hosting**:
   - Render, Cloudflare Workers, Paid VPS, या सशुल्क डेटाबेस की कोई अनिवार्य निर्भरता नहीं है।
   - सामान्य AI चैट के लिए किसी मध्यवर्ती सर्वर की आवश्यकता नहीं होती।
2. **Direct Android to Gemini HTTPS**:
   - MYRA ऐप सीधे Google के आधिकारिक REST एंडपॉइंट्स से कम्यूनिकेट करता है।
3. **Bring Your Own Key (BYOK)**:
   - उपयोगकर्ता Google AI Studio से अपनी निःशुल्क API Key प्राप्त कर ऐप में सुरक्षित रूप से दर्ज कर सकते हैं।
4. **Hardware-Backed Keystore Encryption**:
   - API Key को `Android Keystore` समर्थित `EncryptedSharedPreferences` (AES-256-GCM) में सुरक्षित रखा जाता है।
   - की कभी भी Logcat, क्रैश रिपोर्ट्स, या UI में प्लेनटेक्स्ट के रूप में नहीं दिखती।

---

## 2. हिंदी में सेटअप निर्देश (Setup Guide in Simple Hindi)

### स्टेप 1: मुफ़्त Google Gemini API Key कैसे प्राप्त करें?
1. अपने मोबाइल या कंप्यूटर ब्राउज़र में **[https://aistudio.google.com/](https://aistudio.google.com/)** खोलें।
2. अपने सामान्य Google Account (Gmail) से साइन-इन करें।
3. **"Get API key"** बटन पर क्लिक करें।
4. **"Create API key"** चुनें और बनी हुई की को कॉपी कर लें। *(यह बिल्कुल मुफ़्त है, किसी क्रेडिट कार्ड की आवश्यकता नहीं है)*।

### स्टेप 2: MYRA में Key सुरक्षित कैसे सेव करें?
1. MYRA ऐप खोलें और नीचे दिए गए **Settings (सेटिंग्स)** टैब पर जाएं।
2. **"Google Gemini API Integration"** सेक्शन में जाएं।
3. अपनी कॉपी की हुई की को **"Gemini API Key"** बॉक्स में पेस्ट करें।
4. **"Test & Save API Key"** बटन दबाएं।
5. MYRA तुरंत Google सर्वर से 1-वर्ड पिंग टेस्ट करके कनेक्शन सत्यापित करेगी और स्क्रीन पर लेटेंसी (ms) दिखाएगी।
6. आपकी की आपके फोन के हार्डवेयर एन्क्रिप्टेड वॉल्ट में सुरक्षित हो जाएगी।

---

## 3. Quota Management & 429 Handling (कोटा प्रबंधन)

Google Gemini Free Tier में प्रति मिनट 15 रिक्वेस्ट्स (15 RPM) और प्रतिदिन 1,500 रिक्वेस्ट्स (1,500 RPD) मिलती हैं।

### जब कोटा समाप्त हो जाए (When Quota is Exhausted):
- MYRA को `HTTP 429 RESOURCE_EXHAUSTED` एरर मिलते ही यह लगातार सर्वर को बार-बार कॉल करना तुरंत रोक देती है।
- स्क्रीन पर स्पष्ट हिंदी संदेश दिखाया जाता है:
  > *"⚠️ आपका Google Gemini फ्री कोटा समाप्त हो गया है। MYRA अब बिना इंटरनेट और बिना किसी अतिरिक्त शुल्क के सुरक्षित ऑफलाइन कमांड मोड में चल रही है।"*
- 60 सेकंड का कूलडाउन टाइमर चलता है, जिसके बाद सेवा स्वतः पुनः सामान्य हो जाती है।
- **Never Auto-Bill**: MYRA कभी भी ऑटोमैटिक पेड बिलिंग एक्टिवेट नहीं करती।

---

## 4. Multi-Tier Provider Failover Order (प्राथमिकता क्रम)

1. **Tier 1: Offline Deterministic Engine**:
   - टॉर्च, वॉल्यूम, बैटरी, ऐप्स खोलना जैसे कमांड्स बिना किसी नेटवर्क कॉल के **0ms में ऑन-डिवाइस** चलते हैं।
2. **Tier 2: Local AI Request Cache**:
   - बार-बार पूछे जाने वाले सवालों का जवाब कैश मेमोरी से तुरंत मिलता है (0 टोकन खर्च)।
3. **Tier 3: Gemini Direct Provider**:
   - ऑनलाइन जटिल प्रश्नों के लिए Google Gemini API से डायरेक्ट संपर्क।
4. **Tier 4: Optional On-Device Model**:
   - यदि उपयोगकर्ता ने फोन में मॉडल डाउनलोड किया हो और रैम >= 4GB हो।
5. **Tier 5: Local Offline Fallback**:
   - बिना इंटरनेट के सम्पूर्ण फोन टूल्स सहायता।
