# GOOGLE GEMINI API SETUP & BYOK SECURITY GUIDE
*गूगल जेमिनी एपीआई सेटअप एवं बीवाईओके (Bring Your Own Key) सुरक्षा गाइड*

---

## 1. Quick Setup in 3 Minutes (3 मिनट में त्वरित सेटअप)

MYRA को किसी भी तीसरे पक्ष के भुगतान वाले सर्वर (Render/Cloudflare) की आवश्यकता नहीं है। आप सीधे अपने व्यक्तिगत Google Gemini API Key का उपयोग कर सकते हैं।

### स्टेप-बाय-स्टेप गाइड:

1. **ब्राउज़र में जाएं**:
   कंप्यूटर या फोन के क्रोम ब्राउज़र में **https://aistudio.google.com/** पर जाएं।

2. **साइन इन करें**:
   अपने साधारण Gmail खाते से लॉगिन करें।

3. **Get API Key**:
   स्क्रीन के बाईं ओर या ऊपर **"Get API key"** पर क्लिक करें।

4. **की बनाएं**:
   - **"Create API key in new project"** पर क्लिक करें।
   - आपको एक स्ट्रिंग दिखाई देगी जो `AIzaSy...` से शुरू होगी।
   - **"Copy"** बटन पर क्लिक करें।

5. **MYRA में पेस्ट करें**:
   - MYRA ऐप में **Settings > API Configuration** खोलें।
   - **Gemini API Key** फील्ड में की पेस्ट करें।
   - **Test & Save** दबाएं।
   - यदि स्क्रीन पर हरा टिक `✓ Connected (xxx ms)` आता है, तो आपका सेटअप 100% पूरा हो गया है!

---

## 2. Security Architecture (सुरक्षा तकनीक)

### A. Android Keystore Encryption
- जब आप की दर्ज करते हैं, MYRA इसे सादे टेक्स्ट (Plaintext) में कभी स्टोर नहीं करती।
- यह Android OS के सिक्योर एलीमेंट (Hardware Keystore) द्वारा जनरेट की गई मास्टर की का उपयोग करके **AES-256-GCM** से एन्क्रिप्ट होती है।

### B. No Log Leakage
- Logcat, सिस्टम लॉग्स, और क्रैश रिपोर्ट में की पूरी तरह रेडैक्ट (Masked) रहती है (उदा. `AIzaSy...4X9Z`)।

### C. Freedom to Delete
- आप कभी भी **"Remove Key"** बटन दबाकर की को हार्डवेयर वॉल्ट से हमेशा के लिए डिलीट कर सकते हैं।

---

## 3. Supported Verified Models (सत्यापित मॉडल सूची)

| मॉडल आईडी | प्रकार | लेटेंसी | उपयोग |
| :--- | :--- | :--- | :--- |
| **`gemini-3.8-flash`** | फ्लैगशिप फास्ट | < 150ms | सामान्य बातचीत, कोडिंग, हिंदी साहित्य, गणित |
| **`gemini-3.6-flash`** | हाई थ्रूपुट | < 120ms | त्वरित विश्लेषण एवं विजन ओसीआर |
| **`gemini-3.5-flash-lite`** | अल्ट्रा-फास्ट फॉलबैक | < 60ms | फॉलबैक चैट एवं न्यूनतम लेटेंसी |


## Current MYRA setup — direct API key only

Backend login is not required. MYRA Android sends requests directly to the official Google Gemini API using the key you save in Settings > API Configuration. Do not deploy or configure the optional server for normal MYRA chat or voice use. The API key is encrypted at rest on the phone, but any key used by a client app can potentially be extracted from a compromised device; keep it private and set usage limits/restrictions in Google AI Studio/Cloud where available.
