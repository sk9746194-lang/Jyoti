# MYRA ANDROID BUILD GUIDE & RELEASE CHECKLIST
*मायरा एंड्रॉइड एपीके बिल्ड निर्देशिका एवं रिलीज चेकलिस्ट*

---

## 1. Prerequisites (आवश्यकताएं)
- **JDK**: Java Development Kit 17 (OpenJDK 17)
- **Android SDK**: Compile SDK 34, Min SDK 26, Target SDK 34
- **Gradle Wrapper**: 8.4+

---

## 2. APK Compilation Instructions (कमांड्स)

Android Studio में टर्मिनल खोलें या सीधे प्रोजेक्ट डायरेक्टरी में जाएं:

### A. Debug APK बिल्ड करने के लिए:
```bash
./gradlew assembleDebug
```
- आउटपुट फ़ाइल: `app/build/outputs/apk/debug/app-debug.apk`

### B. Release APK (प्रोडक्शन) बिल्ड करने के लिए:
```bash
./gradlew assembleRelease
```
- आउटपुट फ़ाइल: `app/build/outputs/apk/release/app-release-unsigned.apk`

### C. यूनिट टेस्ट्स रन करने के लिए:
```bash
./gradlew test
```

---

## 3. Pre-Release Verification Checklist (रिलीज चेकलिस्ट)

- [x] Zero hardcoded API keys in source code.
- [x] Android Keystore encryption active for BYOK key storage.
- [x] Direct HTTPS communication with Google Gemini endpoints verified.
- [x] Offline command engine responds in <5ms without network calls.
- [x] HTTP 429 quota exhaustion handled safely with Hindi notification.
- [x] No mandatory Render or Cloudflare dependencies.
- [x] All 5 premium Orbs operational.
- [x] Home screen layout preserved.
