/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { VoiceSettings, VoiceStatus } from '../types/myra';

// Helper: Decode 16-bit little-endian PCM base64 string to Float32Array
function pcm16Base64ToFloat32(base64: string): Float32Array {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  const int16Array = new Int16Array(bytes.buffer);
  const float32Array = new Float32Array(int16Array.length);
  for (let i = 0; i < int16Array.length; i++) {
    float32Array[i] = int16Array[i] / 32768.0;
  }
  return float32Array;
}

// Helper: Convert Float32 microphone data to 16kHz 16-bit PCM base64
function float32To16kPcmBase64(inputData: Float32Array, inputSampleRate: number): string {
  // Downsample to 16000 if necessary
  const targetSampleRate = 16000;
  let resampled: Float32Array;
  
  if (inputSampleRate === targetSampleRate) {
    resampled = inputData;
  } else {
    const ratio = inputSampleRate / targetSampleRate;
    const newLen = Math.round(inputData.length / ratio);
    resampled = new Float32Array(newLen);
    for (let i = 0; i < newLen; i++) {
      const originalIdx = Math.floor(i * ratio);
      resampled[i] = inputData[originalIdx] || 0;
    }
  }

  const int16 = new Int16Array(resampled.length);
  for (let i = 0; i < resampled.length; i++) {
    const s = Math.max(-1, Math.min(1, resampled[i]));
    int16[i] = s < 0 ? s * 0x8000 : s * 0x7fff;
  }

  const bytes = new Uint8Array(int16.buffer);
  let binary = '';
  for (let i = 0; i < bytes.byteLength; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

export class NaturalVoiceEngine {
  private ws: WebSocket | null = null;
  private audioCtx: AudioContext | null = null;
  private analyser: AnalyserNode | null = null;
  private micStream: MediaStream | null = null;
  private micAudioCtx: AudioContext | null = null;
  private micAnalyser: AnalyserNode | null = null;
  private scriptProcessor: ScriptProcessorNode | null = null;

  // Playback queue management
  private nextStartTime: number = 0;
  private activeSources: AudioBufferSourceNode[] = [];
  private isSpeaking: boolean = false;
  private animFrameId: number | null = null;
  private fallbackSpeechActive: boolean = false;

  // Recognition fallback
  private recognition: any = null;

  // Status state
  public status: VoiceStatus = {
    activeMode: 'gemini_tts',
    geminiLiveConnected: false,
    model: 'gemini-3.8-live',
    voiceName: 'Kore (Natural Female AI)',
    fallbackActive: false,
    fallbackReason: undefined,
    sampleRateIn: 16000,
    sampleRateOut: 24000,
  };

  private onStatusChangeCallbacks: ((status: VoiceStatus) => void)[] = [];
  private onAudioLevelCallback?: (level: number) => void;
  private onTranscriptCallback?: (text: string) => void;
  private onSpeakingChangeCallback?: (isSpeaking: boolean) => void;

  constructor() {
    this.initRecognition();
    this.initWebSocket();
  }

  private updateStatus(newPartial: Partial<VoiceStatus>) {
    this.status = { ...this.status, ...newPartial };
    this.onStatusChangeCallbacks.forEach((cb) => cb(this.status));
  }

  public onStatusChange(callback: (status: VoiceStatus) => void) {
    this.onStatusChangeCallbacks.push(callback);
    callback(this.status);
    return () => {
      this.onStatusChangeCallbacks = this.onStatusChangeCallbacks.filter((c) => c !== callback);
    };
  }

  public setAudioLevelCallback(callback: (level: number) => void) {
    this.onAudioLevelCallback = callback;
  }

  public setTranscriptCallback(callback: (text: string) => void) {
    this.onTranscriptCallback = callback;
  }

  public setSpeakingChangeCallback(callback: (isSpeaking: boolean) => void) {
    this.onSpeakingChangeCallback = callback;
  }

  // Audio Context initialization
  private getAudioContext(): AudioContext {
    if (!this.audioCtx || this.audioCtx.state === 'closed') {
      const AudioCtxClass = window.AudioContext || (window as any).webkitAudioContext;
      this.audioCtx = new AudioCtxClass({ sampleRate: 24000 });
      this.analyser = this.audioCtx.createAnalyser();
      this.analyser.fftSize = 256;
      this.analyser.smoothingTimeConstant = 0.4;
      this.analyser.connect(this.audioCtx.destination);
    }
    if (this.audioCtx.state === 'suspended') {
      this.audioCtx.resume().catch(() => {});
    }
    return this.audioCtx;
  }

  // Initialize WebSocket for Gemini Live
  public initWebSocket() {
    if (typeof window === 'undefined') return;

    try {
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const wsUrl = `${protocol}//${window.location.host}/live`;

      if (this.ws) {
        try {
          this.ws.close();
        } catch (e) {}
      }

      this.ws = new WebSocket(wsUrl);

      this.ws.onopen = () => {
        console.log('[NaturalVoiceEngine] WebSocket connected to /live');
      };

      this.ws.onmessage = (event) => {
        try {
          const msg = JSON.parse(event.data);

          if (msg.type === 'status') {
            if (msg.status === 'connected') {
              this.updateStatus({
                activeMode: 'gemini_live',
                geminiLiveConnected: true,
                fallbackActive: false,
                fallbackReason: undefined,
                model: msg.model || 'gemini-3.8-live',
                voiceName: 'Kore (Female Realtime AI Voice)',
                sampleRateIn: msg.sampleRateIn || 16000,
                sampleRateOut: msg.sampleRateOut || 24000,
              });
            } else if (msg.status === 'unavailable' || msg.status === 'error') {
              this.updateStatus({
                activeMode: 'fallback_tts',
                geminiLiveConnected: false,
                fallbackActive: true,
                fallbackReason: msg.error || 'Gemini Live session unavailable',
                voiceName: 'Browser TTS (Fallback Voice)',
              });
            }
          } else if (msg.type === 'audio' && msg.audio) {
            this.updateStatus({
              activeMode: 'gemini_live',
              fallbackActive: false,
            });
            this.playPcmChunk(msg.audio, 24000);
          } else if (msg.type === 'transcript' && msg.text) {
            if (this.onTranscriptCallback) {
              this.onTranscriptCallback(msg.text);
            }
          } else if (msg.type === 'interrupted') {
            this.stopPlayback();
          } else if (msg.type === 'turnComplete') {
            // Live turn complete
          }
        } catch (e) {
          console.error('[NaturalVoiceEngine] Error parsing WS message:', e);
        }
      };

      this.ws.onerror = (err) => {
        console.warn('[NaturalVoiceEngine] WebSocket error, fallback TTS mode prepared:', err);
        this.updateStatus({
          geminiLiveConnected: false,
          fallbackActive: true,
          fallbackReason: 'Gemini Live connection dropped or unavailable. Fallback TTS ready.',
        });
      };

      this.ws.onclose = () => {
        this.updateStatus({
          geminiLiveConnected: false,
        });
      };
    } catch (e) {
      console.warn('[NaturalVoiceEngine] Could not initialize Live WebSocket:', e);
      this.updateStatus({
        geminiLiveConnected: false,
        fallbackActive: true,
        fallbackReason: 'WebSocket connection failed. Using Fallback TTS.',
      });
    }
  }

  // Play a 24kHz PCM chunk with gapless scheduling and real-time audio visualization
  public playPcmChunk(base64Pcm: string, sampleRate: number = 24000) {
    try {
      const ctx = this.getAudioContext();
      const float32 = pcm16Base64ToFloat32(base64Pcm);
      const buffer = ctx.createBuffer(1, float32.length, sampleRate);
      buffer.getChannelData(0).set(float32);

      const source = ctx.createBufferSource();
      source.buffer = buffer;

      if (this.analyser) {
        source.connect(this.analyser);
      } else {
        source.connect(ctx.destination);
      }

      const now = ctx.currentTime;
      const startTime = Math.max(now, this.nextStartTime);
      source.start(startTime);
      this.nextStartTime = startTime + buffer.duration;
      this.activeSources.push(source);

      this.setSpeakingState(true);

      source.onended = () => {
        const idx = this.activeSources.indexOf(source);
        if (idx !== -1) this.activeSources.splice(idx, 1);
        if (this.activeSources.length === 0 && ctx.currentTime >= this.nextStartTime - 0.05) {
          this.setSpeakingState(false);
        }
      };

      this.startVisualizationLoop();
    } catch (e) {
      console.warn('[NaturalVoiceEngine] Notice playing PCM chunk:', e);
    }
  }

  // Continuous frequency measurement for Animated Orb
  private startVisualizationLoop() {
    if (this.animFrameId !== null) return;

    const update = () => {
      if ((this.isSpeaking && this.analyser) || (this.micAnalyser && this.micStream)) {
        const targetAnalyser = this.isSpeaking && this.analyser ? this.analyser : this.micAnalyser;
        if (targetAnalyser) {
          const dataArray = new Uint8Array(targetAnalyser.frequencyBinCount);
          targetAnalyser.getByteFrequencyData(dataArray);

          let sum = 0;
          for (let i = 0; i < dataArray.length; i++) {
            sum += dataArray[i];
          }
          const avg = sum / dataArray.length;
          const level = Math.min(1.0, Math.max(0, (avg / 128) * 1.3));

          if (this.onAudioLevelCallback) {
            this.onAudioLevelCallback(level);
          }
        }
        this.animFrameId = requestAnimationFrame(update);
      } else if (this.fallbackSpeechActive) {
        // Subtle realistic modulation during fallback Web Speech
        const t = Date.now() / 150;
        const simulated = 0.4 + 0.35 * Math.sin(t) + 0.15 * Math.cos(t * 2.3);
        if (this.onAudioLevelCallback) {
          this.onAudioLevelCallback(Math.max(0.1, simulated));
        }
        this.animFrameId = requestAnimationFrame(update);
      } else {
        if (this.onAudioLevelCallback) {
          this.onAudioLevelCallback(0);
        }
        this.animFrameId = null;
      }
    };

    this.animFrameId = requestAnimationFrame(update);
  }

  private setSpeakingState(speaking: boolean) {
    this.isSpeaking = speaking;
    if (this.onSpeakingChangeCallback) {
      this.onSpeakingChangeCallback(speaking);
    }
  }

  // Stop any ongoing audio playback
  public stopPlayback() {
    this.activeSources.forEach((s) => {
      try {
        s.stop();
      } catch (e) {}
    });
    this.activeSources = [];
    this.nextStartTime = 0;
    this.setSpeakingState(false);

    if (this.fallbackSpeechActive && typeof window !== 'undefined' && window.speechSynthesis) {
      window.speechSynthesis.cancel();
      this.fallbackSpeechActive = false;
    }
  }

  // Speak text using natural Gemini AI voice architecture
  public async speakText(
    text: string,
    voiceSettings: VoiceSettings,
    onStart?: () => void,
    onEnd?: () => void
  ) {
    this.stopPlayback();
    onStart?.();

    // 1. If Gemini Live is connected, send real-time text input
    if (this.ws && this.ws.readyState === WebSocket.OPEN && this.status.geminiLiveConnected) {
      try {
        this.ws.send(JSON.stringify({ text }));
        this.updateStatus({
          activeMode: 'gemini_live',
          fallbackActive: false,
          fallbackReason: undefined,
        });
        return;
      } catch (e) {
        console.warn('Gemini Live WS send failed, trying Neural TTS endpoint:', e);
      }
    }

    // 2. Try Gemini Neural TTS endpoint (/api/gemini/tts)
    try {
      const res = await fetch('/api/gemini/tts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text,
          voice: 'Kore', // Natural female voice
          personality: voiceSettings.personality,
        }),
      });

      if (res.ok) {
        const data = await res.json();
        if (data.audio) {
          this.updateStatus({
            activeMode: 'gemini_tts',
            fallbackActive: false,
            fallbackReason: undefined,
            model: data.model || 'gemini-3.1-flash-tts-preview',
            voiceName: 'Kore (Neural Female Voice)',
            sampleRateOut: 24000,
          });

          this.playPcmChunk(data.audio, data.sampleRate || 24000);
          return;
        }
      }
    } catch (e) {
      console.warn('Gemini TTS fetch error, switching to Fallback Browser TTS:', e);
    }

    // 3. Fallback Browser TTS (Clear notice, NO fake Gemini voice)
    this.updateStatus({
      activeMode: 'fallback_tts',
      fallbackActive: true,
      fallbackReason:
        'Gemini Live & Neural TTS audio unavailable. Operating in Fallback Text-to-Speech mode.',
      voiceName: 'Browser TTS (Fallback Female Voice)',
    });

    this.speakFallbackWebSpeech(text, voiceSettings, onStart, onEnd);
  }

  // Fallback speech synthesis
  private speakFallbackWebSpeech(
    text: string,
    settings: VoiceSettings,
    onStart?: () => void,
    onEnd?: () => void
  ) {
    if (typeof window === 'undefined' || !window.speechSynthesis) {
      onEnd?.();
      return;
    }

    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);

    // Pick best available Hindi / Indian English female voice
    const voices = window.speechSynthesis.getVoices();
    const femaleHindi = voices.find(
      (v) =>
        (v.lang.toLowerCase().includes('hi') || v.name.toLowerCase().includes('hindi')) &&
        (v.name.toLowerCase().includes('female') ||
          v.name.toLowerCase().includes('google') ||
          v.name.toLowerCase().includes('zira') ||
          v.name.toLowerCase().includes('natural'))
    );
    const anyHindiOrIndian = voices.find(
      (v) =>
        v.lang.toLowerCase().includes('hi') ||
        v.name.toLowerCase().includes('hindi') ||
        v.lang.toLowerCase() === 'en-in'
    );

    if (femaleHindi) {
      utterance.voice = femaleHindi;
    } else if (anyHindiOrIndian) {
      utterance.voice = anyHindiOrIndian;
    }

    // Natural smooth pitch & rate
    if (settings.personality === 'romantic_gf') {
      utterance.pitch = 1.25;
      utterance.rate = 0.92;
    } else {
      utterance.pitch = 1.05;
      utterance.rate = 0.98;
    }

    utterance.onstart = () => {
      this.fallbackSpeechActive = true;
      this.setSpeakingState(true);
      this.startVisualizationLoop();
      onStart?.();
    };

    utterance.onend = () => {
      this.fallbackSpeechActive = false;
      this.setSpeakingState(false);
      onEnd?.();
    };

    utterance.onerror = () => {
      this.fallbackSpeechActive = false;
      this.setSpeakingState(false);
      onEnd?.();
    };

    window.speechSynthesis.speak(utterance);
  }

  // Microphone capture with 16kHz PCM streaming and real-time audio level monitoring
  public async startRealtimeMic(
    onResult: (transcript: string, isFinal: boolean) => void,
    onError: (err: any) => void,
    onEnd: () => void,
    lang: string = 'hi-IN'
  ) {
    // 1. Audio stream capture for real-time Orb visualizer
    try {
      this.micStream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const AudioCtxClass = window.AudioContext || (window as any).webkitAudioContext;
      this.micAudioCtx = new AudioCtxClass();
      const source = this.micAudioCtx.createMediaStreamSource(this.micStream);

      this.micAnalyser = this.micAudioCtx.createAnalyser();
      this.micAnalyser.fftSize = 256;
      source.connect(this.micAnalyser);

      // Script processor to send 16kHz PCM chunks to Gemini Live if active
      const processor = this.micAudioCtx.createScriptProcessor(4096, 1, 1);
      source.connect(processor);
      processor.connect(this.micAudioCtx.destination);
      this.scriptProcessor = processor;

      processor.onaudioprocess = (e) => {
        if (this.ws && this.ws.readyState === WebSocket.OPEN && this.status.geminiLiveConnected) {
          const inputData = e.inputBuffer.getChannelData(0);
          const base64 = float32To16kPcmBase64(inputData, this.micAudioCtx?.sampleRate || 48000);
          try {
            this.ws.send(JSON.stringify({ audio: base64 }));
          } catch (err) {}
        }
      };

      this.startVisualizationLoop();
    } catch (err) {
      console.warn('Microphone AudioContext error:', err);
    }

    // 2. Also run SpeechRecognition for interim & final transcript display
    this.startSpeechRecognition(onResult, onError, onEnd, lang);
  }

  public stopRealtimeMic() {
    if (this.scriptProcessor) {
      try {
        this.scriptProcessor.disconnect();
      } catch (e) {}
      this.scriptProcessor = null;
    }
    if (this.micStream) {
      this.micStream.getTracks().forEach((track) => track.stop());
      this.micStream = null;
    }
    if (this.micAudioCtx && this.micAudioCtx.state !== 'closed') {
      try {
        this.micAudioCtx.close();
      } catch (e) {}
      this.micAudioCtx = null;
    }
    this.micAnalyser = null;
    this.stopSpeechRecognition();
  }

  // Web Speech recognition for transcription
  private initRecognition() {
    if (typeof window === 'undefined') return;
    const win = window as any;
    const SpeechRec = win.SpeechRecognition || win.webkitSpeechRecognition;
    if (SpeechRec) {
      try {
        this.recognition = new SpeechRec();
        this.recognition.continuous = false;
        this.recognition.interimResults = true;
        this.recognition.lang = 'hi-IN';
      } catch (e) {}
    }
  }

  private startSpeechRecognition(
    onResult: (transcript: string, isFinal: boolean) => void,
    onError: (err: any) => void,
    onEnd: () => void,
    lang: string = 'hi-IN'
  ) {
    if (!this.recognition) {
      // If recognition is not supported, still allow mic streaming
      return;
    }

    this.recognition.lang = lang;

    this.recognition.onresult = (event: any) => {
      let interim = '';
      let final = '';
      for (let i = event.resultIndex; i < event.results.length; ++i) {
        if (event.results[i].isFinal) {
          final += event.results[i][0].transcript;
        } else {
          interim += event.results[i][0].transcript;
        }
      }
      if (final) {
        onResult(final.trim(), true);
      } else if (interim) {
        onResult(interim.trim(), false);
      }
    };

    this.recognition.onerror = (event: any) => {
      onError(event.error);
    };

    this.recognition.onend = () => {
      onEnd();
    };

    try {
      this.recognition.start();
    } catch (e) {}
  }

  private stopSpeechRecognition() {
    if (this.recognition) {
      try {
        this.recognition.stop();
      } catch (e) {}
    }
  }
}

export const naturalVoice = new NaturalVoiceEngine();
