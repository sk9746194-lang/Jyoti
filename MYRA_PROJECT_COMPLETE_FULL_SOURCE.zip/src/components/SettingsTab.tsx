/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Settings, 
  Volume2, 
  Sparkles, 
  Palette, 
  ShieldCheck, 
  Mic, 
  Radio, 
  Bell, 
  Laptop, 
  Smartphone, 
  Download, 
  Key, 
  CheckCircle2, 
  Play, 
  Heart, 
  Sliders,
  Lock,
  ExternalLink,
  ShieldAlert,
  Code2
} from 'lucide-react';
import { OrbSettings, PersonalityMode, VoiceSettings } from '../types/myra';

interface SettingsTabProps {
  voiceSettings: VoiceSettings;
  onUpdateVoiceSettings: (settings: VoiceSettings) => void;
  orbSettings: OrbSettings;
  onUpdateOrbSettings: (settings: OrbSettings) => void;
  onTestVoice: () => void;
  onTriggerEnrollment: () => void;
  onOpenMyraConnect?: () => void;
  onOpenWallpaper?: () => void;
}

export const SettingsTab: React.FC<SettingsTabProps> = ({
  voiceSettings,
  onUpdateVoiceSettings,
  orbSettings,
  onUpdateOrbSettings,
  onTestVoice,
  onTriggerEnrollment,
  onOpenMyraConnect,
  onOpenWallpaper,
}) => {
  const [activeSection, setActiveSection] = useState<
    'voice_models' | 'myra_connect' | 'wallpaper' | 'orb' | 'permissions' | 'voice_auth' | 'wake_word' | 'pc_connect' | 'safety' | 'apk_export'
  >('voice_models');

  const [permissions, setPermissions] = useState([
    { name: 'Microphone & Voice Input', granted: true, key: 'mic' },
    { name: 'Accessibility Service (Screen Agent)', granted: true, key: 'access' },
    { name: 'Draw Over Other Apps (Overlay)', granted: true, key: 'overlay' },
    { name: 'Default Digital Assistant Role', granted: true, key: 'assistant' },
    { name: 'Phone Call Management & Dialing', granted: true, key: 'call' },
    { name: 'Notification Listener Service', granted: true, key: 'notif' },
    { name: 'SMS & OTP Reading (Safe Mode)', granted: true, key: 'sms' },
    { name: 'Precise Location (GPS / Parking)', granted: true, key: 'gps' },
    { name: 'Camera & Vision Scanner', granted: true, key: 'cam' },
    { name: 'Device Admin (Urgent Screen Lock)', granted: true, key: 'admin' },
    { name: 'Ignore Battery Optimizations', granted: true, key: 'battery' },
  ]);

  const [pcIp, setPcIp] = useState('192.168.1.105');
  const [pcPin, setPcPin] = useState('4829');
  const [pcConnected, setPcConnected] = useState(false);
  const [bluetoothAudioEnabled, setBluetoothAudioEnabled] = useState(true);

  // MYRA Owner Security State
  const [ownerProtection, setOwnerProtection] = useState(() => {
    return localStorage.getItem('myra_owner_protection') !== 'false';
  });
  const [ownerVoiceEnrolled, setOwnerVoiceEnrolled] = useState(() => {
    return localStorage.getItem('myra_owner_voice_enrolled') !== 'false';
  });
  const [biometricLock, setBiometricLock] = useState(() => {
    return localStorage.getItem('myra_biometric_lock') !== 'false';
  });
  const [deviceCredential, setDeviceCredential] = useState(() => {
    return localStorage.getItem('myra_device_credential') !== 'false';
  });
  const [unknownVoiceBlocked, setUnknownVoiceBlocked] = useState(() => {
    return localStorage.getItem('myra_unknown_voice_blocked') !== 'false';
  });
  const [sensitiveProtected, setSensitiveProtected] = useState(() => {
    return localStorage.getItem('myra_sensitive_protected') !== 'false';
  });
  const [appOpenProtection, setAppOpenProtection] = useState(() => {
    return localStorage.getItem('myra_app_open_protection') === 'true';
  });
  const [securityTimeoutMins, setSecurityTimeoutMins] = useState(2);

  const [showVoiceEnrollModal, setShowVoiceEnrollModal] = useState(false);
  const [enrollStep, setEnrollStep] = useState(0);
  const [isEnrollListening, setIsEnrollListening] = useState(false);

  const [showVoiceTestModal, setShowVoiceTestModal] = useState(false);
  const [isTestingVoice, setIsTestingVoice] = useState(false);
  const [voiceTestResult, setVoiceTestResult] = useState<{ match: boolean; score: number; text: string } | null>(null);

  const enrollmentPhrases = [
    'Hi Myra',
    'My name is the owner of Myra',
    'Myra, are you ready?',
    'Myra, unlock owner mode',
  ];

  const togglePermission = (idx: number) => {
    setPermissions((prev) =>
      prev.map((p, i) => (i === idx ? { ...p, granted: !p.granted } : p))
    );
  };

  return (
    <div className="flex-1 flex flex-col p-4 bg-[#090d16] text-slate-100 select-none overflow-y-auto">
      {/* Header */}
      <div className="mb-4">
        <h2 className="text-base font-bold text-white tracking-tight flex items-center gap-2">
          <Settings className="w-5 h-5 text-blue-400" />
          <span>App Settings & Intelligence</span>
        </h2>
        <p className="text-xs text-slate-400 mt-0.5">
          Har setting page, AI engine, permissions aur Android APK configuration.
        </p>
      </div>

      {/* Settings Navigation Chips */}
      <div className="flex gap-1.5 overflow-x-auto pb-2 mb-3 scrollbar-none">
        {[
          { id: 'voice_models', label: 'Voice & AI Models' },
          { id: 'myra_connect', label: '📱 MYRA Connect (Phone)' },
          { id: 'wallpaper', label: '🌌 Live Wallpaper' },
          { id: 'orb', label: 'Orb Visualizer' },
          { id: 'permissions', label: 'Permissions Hub' },
          { id: 'voice_auth', label: '🛡️ MYRA Security' },
          { id: 'wake_word', label: 'Wake Word' },
          { id: 'pc_connect', label: 'PC Connect' },
          { id: 'safety', label: 'Safety Rules' },
          { id: 'apk_export', label: 'Android APK' },
        ].map((sec) => (
          <button
            key={sec.id}
            onClick={() => setActiveSection(sec.id as any)}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors ${
              activeSection === sec.id
                ? 'bg-blue-600 text-white shadow-md shadow-blue-900/40'
                : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            {sec.label}
          </button>
        ))}
      </div>

      {/* Section 1: Voice & AI Models */}
      {activeSection === 'voice_models' && (
        <div className="space-y-4">
          <div className="bg-[#111726] border border-slate-800 rounded-2xl p-4 space-y-4">
            <div>
              <span className="text-xs font-bold text-white uppercase tracking-wider block mb-1">
                Voice Architecture & AI Engine
              </span>
              <p className="text-xs text-slate-400 mb-3">
                Select between Gemini Live real-time audio output, Gemini Neural TTS, or honest Browser Fallback TTS.
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                <button
                  onClick={() =>
                    onUpdateVoiceSettings({ ...voiceSettings, ttsEngine: 'gemini_live' })
                  }
                  className={`p-3 rounded-xl border text-left transition-all ${
                    voiceSettings.ttsEngine === 'gemini_live'
                      ? 'bg-emerald-950/60 border-emerald-500 text-white shadow-sm shadow-emerald-950/50'
                      : 'bg-slate-900 border-slate-800 text-slate-400'
                  }`}
                >
                  <span className="text-xs font-bold block flex items-center gap-1.5 text-emerald-400">
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                    Gemini Live Realtime
                  </span>
                  <span className="text-[10px] text-slate-300 block mt-1">
                    gemini-3.8-live • Kore female voice • 24kHz stream
                  </span>
                </button>

                <button
                  onClick={() =>
                    onUpdateVoiceSettings({ ...voiceSettings, ttsEngine: 'gemini_tts' })
                  }
                  className={`p-3 rounded-xl border text-left transition-all ${
                    voiceSettings.ttsEngine === 'gemini_tts'
                      ? 'bg-blue-950/60 border-blue-500 text-white shadow-sm'
                      : 'bg-slate-900 border-slate-800 text-slate-400'
                  }`}
                >
                  <span className="text-xs font-bold block flex items-center gap-1.5 text-blue-400">
                    <Sparkles className="w-3 h-3" />
                    Gemini Neural Voice
                  </span>
                  <span className="text-[10px] text-slate-300 block mt-1">
                    gemini-3.1-flash-tts • Natural female inflection
                  </span>
                </button>

                <button
                  onClick={() =>
                    onUpdateVoiceSettings({ ...voiceSettings, ttsEngine: 'fallback_tts' })
                  }
                  className={`p-3 rounded-xl border text-left transition-all ${
                    voiceSettings.ttsEngine === 'fallback_tts'
                      ? 'bg-amber-950/60 border-amber-500 text-white shadow-sm'
                      : 'bg-slate-900 border-slate-800 text-slate-400'
                  }`}
                >
                  <span className="text-xs font-bold block flex items-center gap-1.5 text-amber-400">
                    <Volume2 className="w-3 h-3" />
                    Fallback Browser TTS
                  </span>
                  <span className="text-[10px] text-slate-400 block mt-1">
                    Device Web Speech (When Gemini Live is offline)
                  </span>
                </button>
              </div>
            </div>

            {/* Personality Mode Selector */}
            <div className="pt-2 border-t border-slate-800">
              <span className="text-xs font-bold text-white block mb-1">Personality Mode</span>
              <p className="text-xs text-slate-400 mb-2.5">
                Set conversational demeanor (includes GF/Romantic mode from Page 9).
              </p>

              <div className="space-y-2">
                {[
                  {
                    id: 'friendly_assistant',
                    name: 'Friendly Assistant (Default)',
                    desc: 'Helpful, warm, capable Hindi/Hinglish partner',
                  },
                  {
                    id: 'romantic_gf',
                    name: 'GF / Romantic Mode ❤️',
                    desc: 'Caring, sweet, affectionate girlfriend voice & banter',
                  },
                  {
                    id: 'professional',
                    name: 'Pro Executive Assistant',
                    desc: 'Crisp, structured, business-ready responses',
                  },
                ].map((m) => (
                  <button
                    key={m.id}
                    onClick={() =>
                      onUpdateVoiceSettings({
                        ...voiceSettings,
                        personality: m.id as PersonalityMode,
                      })
                    }
                    className={`w-full p-2.5 rounded-xl border text-left flex items-center justify-between transition-all ${
                      voiceSettings.personality === m.id
                        ? 'bg-blue-950/70 border-blue-500 text-white'
                        : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    <div>
                      <span className="text-xs font-bold block text-white">{m.name}</span>
                      <span className="text-[11px] text-slate-400">{m.desc}</span>
                    </div>
                    {voiceSettings.personality === m.id && (
                      <CheckCircle2 className="w-4 h-4 text-blue-400 shrink-0" />
                    )}
                  </button>
                ))}
              </div>
            </div>

            {/* Pitch & Speed Sliders */}
            <div className="pt-2 border-t border-slate-800 space-y-3">
              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-slate-300">Voice Pitch</span>
                  <span className="font-mono text-blue-400">{voiceSettings.pitch}x</span>
                </div>
                <input
                  type="range"
                  min="0.5"
                  max="1.5"
                  step="0.1"
                  value={voiceSettings.pitch}
                  onChange={(e) =>
                    onUpdateVoiceSettings({
                      ...voiceSettings,
                      pitch: parseFloat(e.target.value),
                    })
                  }
                  className="w-full accent-blue-500"
                />
              </div>

              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-slate-300">Speech Rate</span>
                  <span className="font-mono text-blue-400">{voiceSettings.rate}x</span>
                </div>
                <input
                  type="range"
                  min="0.5"
                  max="1.5"
                  step="0.1"
                  value={voiceSettings.rate}
                  onChange={(e) =>
                    onUpdateVoiceSettings({
                      ...voiceSettings,
                      rate: parseFloat(e.target.value),
                    })
                  }
                  className="w-full accent-blue-500"
                />
              </div>

              <button
                onClick={onTestVoice}
                className="w-full py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold flex items-center justify-center gap-1.5 shadow-md active:scale-98 transition-all"
              >
                <Volume2 className="w-4 h-4" />
                <span>Play Sample Audio Preview</span>
              </button>

              {/* Bluetooth Audio & Headset Routing */}
              <div className="pt-2 border-t border-slate-800 flex items-center justify-between">
                <div>
                  <span className="text-xs font-bold text-white block">Bluetooth Audio & Headset Routing</span>
                  <p className="text-[11px] text-slate-400">Stream Gemini Live real-time audio through earbuds / car audio</p>
                </div>
                <button
                  onClick={() => setBluetoothAudioEnabled(!bluetoothAudioEnabled)}
                  className={`w-11 h-6 rounded-full transition-colors relative p-0.5 ${
                    bluetoothAudioEnabled ? 'bg-blue-600' : 'bg-slate-700'
                  }`}
                >
                  <div
                    className={`w-5 h-5 rounded-full bg-white transition-transform ${
                      bluetoothAudioEnabled ? 'translate-x-5' : 'translate-x-0'
                    }`}
                  />
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Section: MYRA Live Wallpaper */}
      {activeSection === 'wallpaper' && (
        <div className="space-y-4">
          <div className="bg-[#111726] border border-purple-500/30 rounded-2xl p-5 space-y-4 shadow-[0_0_30px_rgba(168,85,247,0.15)]">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-xl bg-purple-500/20 border border-purple-500/40 flex items-center justify-center text-purple-400">
                  <Sparkles className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white flex items-center gap-2">
                    MYRA Live Wallpaper
                    <span className="text-[10px] font-mono uppercase bg-purple-500/20 text-purple-300 border border-purple-500/40 px-2 py-0.5 rounded-full font-bold">
                      9:16 Android Live
                    </span>
                  </h3>
                  <p className="text-xs text-slate-300 mt-0.5">
                    Holographic Earth • HUD Rings • Glowing AI Orb • Radial App Galaxy
                  </p>
                </div>
              </div>
            </div>

            <p className="text-xs text-slate-400 leading-relaxed">
              MYRA Live Wallpaper Android system ka real <code className="text-cyan-300">WallpaperService</code> use karta hai. Isme 60 FPS real-time animated stars, rotating 3D Earth, dual neon blue + red energy pulses, aur battery-saving lifecycle synchronization shamil hai.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 pt-2">
              <div className="p-3 rounded-xl bg-black/40 border border-slate-800 space-y-1">
                <span className="text-[10px] font-bold text-purple-400 uppercase tracking-wider block">Visuals</span>
                <span className="text-xs font-semibold text-slate-200 block">Earth + HUD Rings + Orb</span>
                <span className="text-[10px] text-slate-400 block">Radial floating app icons galaxy</span>
              </div>

              <div className="p-3 rounded-xl bg-black/40 border border-slate-800 space-y-1">
                <span className="text-[10px] font-bold text-blue-400 uppercase tracking-wider block">Color Themes</span>
                <span className="text-xs font-semibold text-slate-200 block">Electric Blue & Cyber Red</span>
                <span className="text-[10px] text-slate-400 block">Dual Neon glow & pulse waves</span>
              </div>

              <div className="p-3 rounded-xl bg-black/40 border border-slate-800 space-y-1">
                <span className="text-[10px] font-bold text-emerald-400 uppercase tracking-wider block">Efficiency</span>
                <span className="text-xs font-semibold text-slate-200 block">0% Screen-off Usage</span>
                <span className="text-[10px] text-slate-400 block">Pauses automatically in background</span>
              </div>
            </div>

            <div className="pt-2">
              <button
                onClick={onOpenWallpaper}
                className="w-full py-3 px-4 bg-gradient-to-r from-purple-600 via-indigo-600 to-blue-600 hover:brightness-110 active:scale-[0.99] rounded-xl text-white font-bold text-sm shadow-[0_0_25px_rgba(168,85,247,0.35)] flex items-center justify-center gap-2 transition"
              >
                <Sparkles className="w-4 h-4 text-purple-200" />
                <span>Open Live Wallpaper Studio & Preview</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Section 2: Orb & Screen Studio Customization */}
      {activeSection === 'orb' && (
        <div className="bg-[#111726] border border-slate-800 rounded-2xl p-4 space-y-5">
          {/* 1. 10 Orb Styles Gallery */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <span className="text-xs font-bold text-white uppercase tracking-wider block">
                🔮 10 Orb Designs Gallery
              </span>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-blue-500/20 text-blue-400 font-bold border border-blue-500/30">
                10 STYLES
              </span>
            </div>
            <p className="text-xs text-slate-400 mb-3">
              Independent Canvas animations decoupled from voice engine.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {[
                { id: 'classic_glow', label: '1. Classic Glow Orb', desc: 'Breathing soft aura & specular crescent' },
                { id: 'siri_fluid', label: '2. Siri-style Fluid Orb', desc: 'Harmonic multi-frequency fluid blob' },
                { id: 'neon_ring', label: '3. Neon Ring Orb', desc: 'Concentric cyber rings & orbiting arcs' },
                { id: 'galaxy_particle', label: '4. Galaxy Particle Orb', desc: 'Accretion disk with swirling star dust' },
                { id: 'energy_core', label: '5. Energy Core Orb', desc: 'Plasma reactor with radiating lightning' },
                { id: 'aurora', label: '6. Aurora Orb', desc: 'Atmospheric Northern Lights curtains' },
                { id: 'glass', label: '7. Glass Orb', desc: 'Frosted glassmorphism & caustic rim' },
                { id: 'pulse', label: '8. Pulse Orb', desc: 'Acoustic sonar shockwaves & dense core' },
                { id: 'wave', label: '9. Wave Orb', desc: 'Sinusoidal 3D spherical equalizer waves' },
                { id: 'myra_signature', label: '10. MYRA Signature Orb', desc: 'Dual-gyroscopic rings & 8-node nexus' },
              ].map((styleItem) => {
                const isSelected = (orbSettings.style || 'myra_signature') === styleItem.id;
                return (
                  <button
                    key={styleItem.id}
                    onClick={() =>
                      onUpdateOrbSettings({ ...orbSettings, style: styleItem.id as any })
                    }
                    className={`p-3 rounded-xl border text-left transition-all flex flex-col justify-between ${
                      isSelected
                        ? 'bg-blue-950/70 border-blue-500 text-white shadow-lg shadow-blue-950/50'
                        : 'bg-slate-900 border-slate-800 text-slate-400 hover:border-slate-700 hover:text-slate-200'
                    }`}
                  >
                    <div className="flex items-center justify-between w-full mb-1">
                      <span className={`text-xs font-bold ${isSelected ? 'text-blue-300' : 'text-slate-200'}`}>
                        {styleItem.label}
                      </span>
                      {isSelected && (
                        <span className="w-2 h-2 rounded-full bg-blue-400 animate-pulse" />
                      )}
                    </div>
                    <span className="text-[11px] text-slate-400 leading-tight">
                      {styleItem.desc}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* 2. Color Palette Theme */}
          <div className="pt-3 border-t border-slate-800">
            <span className="text-xs font-bold text-white uppercase tracking-wider block mb-1">
              🎨 Color Theme & Glow
            </span>
            <p className="text-xs text-slate-400 mb-3">
              Applied to idle state, ambient glow, and edge illumination.
            </p>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {[
                { id: 'myra_signature', label: 'MYRA Electric', color: 'bg-cyan-400' },
                { id: 'electric_blue', label: 'Electric Blue', color: 'bg-blue-500' },
                { id: 'cyber_purple', label: 'Cyber Violet', color: 'bg-purple-500' },
                { id: 'romantic_rose', label: 'Romantic Rose', color: 'bg-rose-500' },
                { id: 'emerald_neon', label: 'Emerald Aura', color: 'bg-emerald-500' },
                { id: 'cyber_amber', label: 'Cyber Amber', color: 'bg-amber-500' },
              ].map((theme) => (
                <button
                  key={theme.id}
                  onClick={() =>
                    onUpdateOrbSettings({ ...orbSettings, theme: theme.id as any })
                  }
                  className={`p-2.5 rounded-xl border text-left flex items-center gap-2 transition-all ${
                    orbSettings.theme === theme.id
                      ? 'bg-blue-950/70 border-blue-500 text-white'
                      : 'bg-slate-900 border-slate-800 text-slate-400'
                  }`}
                >
                  <span className={`w-3.5 h-3.5 rounded-full shrink-0 ${theme.color}`} />
                  <span className="text-xs font-semibold text-white truncate">{theme.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* 3. Full-Screen Edge Speaking Effect */}
          <div className="pt-3 border-t border-slate-800">
            <span className="text-xs font-bold text-white uppercase tracking-wider block mb-1">
              ⚡ Full-Screen Edge Speaking Effect
            </span>
            <p className="text-xs text-slate-400 mb-3">
              Perimeter glowing light beams & equalizer waves along phone screen borders.
            </p>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {[
                { id: 'all_4_sides', label: 'All 4 Borders', desc: 'Full 360° perimeter' },
                { id: 'bottom_only', label: 'Bottom Beam', desc: 'Subtle speech equalizer' },
                { id: 'left_right', label: 'Left + Right', desc: 'Lateral acoustic bars' },
                { id: 'top_bottom', label: 'Top + Bottom', desc: 'Dual border light' },
                { id: 'off', label: 'Disabled (Off)', desc: 'Center orb only' },
              ].map((edge) => {
                const isSelected = (orbSettings.edgeEffectMode || 'all_4_sides') === edge.id;
                return (
                  <button
                    key={edge.id}
                    onClick={() =>
                      onUpdateOrbSettings({ ...orbSettings, edgeEffectMode: edge.id as any })
                    }
                    className={`p-2.5 rounded-xl border text-left transition-all ${
                      isSelected
                        ? 'bg-blue-950/70 border-blue-500 text-white'
                        : 'bg-slate-900 border-slate-800 text-slate-400'
                    }`}
                  >
                    <div className="text-xs font-semibold text-white">{edge.label}</div>
                    <div className="text-[10px] text-slate-400">{edge.desc}</div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* 4. Background Atmosphere */}
          <div className="pt-3 border-t border-slate-800">
            <span className="text-xs font-bold text-white uppercase tracking-wider block mb-1">
              🌌 Background Atmosphere
            </span>
            <p className="text-xs text-slate-400 mb-3">
              Atmospheric background rendered behind MYRA.
            </p>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {[
                { id: 'myra_signature', label: 'MYRA Cosmic' },
                { id: 'animated_gradient', label: 'Mesh Gradient' },
                { id: 'galaxy', label: 'Deep Galaxy' },
                { id: 'particles', label: 'Stardust Drift' },
                { id: 'aurora', label: 'Aurora Ribbons' },
                { id: 'digital', label: 'Cyber Grid' },
                { id: 'gradient', label: 'Radial Gradient' },
                { id: 'solid', label: 'Matte Deep' },
              ].map((bg) => {
                const isSelected = (orbSettings.backgroundStyle || 'myra_signature') === bg.id;
                return (
                  <button
                    key={bg.id}
                    onClick={() =>
                      onUpdateOrbSettings({ ...orbSettings, backgroundStyle: bg.id as any })
                    }
                    className={`p-2 rounded-xl border text-center transition-all text-xs font-medium ${
                      isSelected
                        ? 'bg-blue-950/70 border-blue-500 text-white'
                        : 'bg-slate-900 border-slate-800 text-slate-400'
                    }`}
                  >
                    {bg.label}
                  </button>
                );
              })}
            </div>
          </div>

          {/* 5. Sliders: Size, Glow, Speed, Particles, Thickness */}
          <div className="pt-3 border-t border-slate-800 space-y-3">
            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-slate-300">Orb Diameter</span>
                <span className="font-mono text-blue-400">{orbSettings.sizeDp || 240} dp</span>
              </div>
              <input
                type="range"
                min="160"
                max="320"
                step="10"
                value={orbSettings.sizeDp || 240}
                onChange={(e) =>
                  onUpdateOrbSettings({
                    ...orbSettings,
                    sizeDp: parseInt(e.target.value),
                  })
                }
                className="w-full accent-blue-500"
              />
            </div>

            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-slate-300">Glow Intensity</span>
                <span className="font-mono text-blue-400">{((orbSettings.glowIntensity || 0.85) * 100).toFixed(0)}%</span>
              </div>
              <input
                type="range"
                min="0.2"
                max="1.5"
                step="0.05"
                value={orbSettings.glowIntensity || 0.85}
                onChange={(e) =>
                  onUpdateOrbSettings({
                    ...orbSettings,
                    glowIntensity: parseFloat(e.target.value),
                  })
                }
                className="w-full accent-blue-500"
              />
            </div>

            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-slate-300">Animation Speed</span>
                <span className="font-mono text-blue-400">{(orbSettings.animationSpeed || 1.0).toFixed(1)}x</span>
              </div>
              <input
                type="range"
                min="0.4"
                max="2.5"
                step="0.1"
                value={orbSettings.animationSpeed || 1.0}
                onChange={(e) =>
                  onUpdateOrbSettings({
                    ...orbSettings,
                    animationSpeed: parseFloat(e.target.value),
                  })
                }
                className="w-full accent-blue-500"
              />
            </div>

            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-slate-300">Particle Density</span>
                <span className="font-mono text-blue-400">{orbSettings.particleCount} particles</span>
              </div>
              <input
                type="range"
                min="12"
                max="64"
                step="4"
                value={orbSettings.particleCount}
                onChange={(e) =>
                  onUpdateOrbSettings({
                    ...orbSettings,
                    particleCount: parseInt(e.target.value),
                  })
                }
                className="w-full accent-blue-500"
              />
            </div>

            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-slate-300">Ring & Contour Thickness</span>
                <span className="font-mono text-blue-400">{(orbSettings.ringThickness || 3.0).toFixed(1)} dp</span>
              </div>
              <input
                type="range"
                min="1.5"
                max="6.0"
                step="0.5"
                value={orbSettings.ringThickness || 3.0}
                onChange={(e) =>
                  onUpdateOrbSettings({
                    ...orbSettings,
                    ringThickness: parseFloat(e.target.value),
                  })
                }
                className="w-full accent-blue-500"
              />
            </div>
          </div>
        </div>
      )}

      {/* Section: MYRA Connect — Phone to Phone */}
      {activeSection === 'myra_connect' && (
        <div className="space-y-4">
          <div className="bg-[#111726] border border-cyan-500/40 rounded-2xl p-4 space-y-4 shadow-lg shadow-cyan-500/10">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-cyan-500/20 text-cyan-400 flex items-center justify-center border border-cyan-500/40">
                  <Smartphone className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-white">MYRA Connect — Phone to Phone</h3>
                  <p className="text-xs text-slate-400">Secure Wi-Fi / Hotspot Local Interconnect</p>
                </div>
              </div>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-400 border border-cyan-500/40 font-bold">
                PORT 9876
              </span>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">
              अपने दूसरे या घर के Android फोन को MYRA से जोड़ें। एक बार पेयर होने के बाद आप कहीं से भी बोल सकते हैं:
              <br />
              <span className="text-cyan-300 font-mono">"दूसरे फोन पर YouTube खोलो"</span>,{' '}
              <span className="text-cyan-300 font-mono">"Camera खोलो"</span>, या{' '}
              <span className="text-cyan-300 font-mono">"टॉर्च जलाओ"</span>।
            </p>

            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
                <div className="text-[10px] uppercase font-bold text-slate-400">Pairing Security</div>
                <div className="text-sm font-bold text-white mt-0.5">QR + 6-Digit PIN</div>
                <p className="text-[10px] text-slate-500 mt-1">Both sides must approve</p>
              </div>
              <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
                <div className="text-[10px] uppercase font-bold text-slate-400">Local Network</div>
                <div className="text-sm font-bold text-white mt-0.5">Wi-Fi / Hotspot</div>
                <p className="text-[10px] text-slate-500 mt-1">Zero cloud latency</p>
              </div>
            </div>

            <button
              onClick={onOpenMyraConnect}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-bold text-xs shadow-lg shadow-cyan-500/20 transition-all active:scale-98 flex items-center justify-center gap-2"
            >
              <Smartphone className="w-4 h-4" />
              <span>Open MYRA Connect Device Manager</span>
            </button>
          </div>
        </div>
      )}

      {/* Section 3: Permissions Hub */}
      {activeSection === 'permissions' && (
        <div className="bg-[#111726] border border-slate-800 rounded-2xl p-4 space-y-3">
          <div className="mb-2">
            <span className="text-xs font-bold text-white uppercase tracking-wider block">
              Android Runtime Permissions
            </span>
            <p className="text-xs text-slate-400">
              Accessibility, Mic, Overlay, Default Assistant, Device Admin, Storage — sab yahin check hote hain (Page 10).
            </p>
          </div>

          <div className="divide-y divide-slate-800/80">
            {permissions.map((perm, idx) => (
              <div key={perm.key} className="py-2.5 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <ShieldCheck
                    className={`w-4 h-4 ${perm.granted ? 'text-emerald-400' : 'text-slate-600'}`}
                  />
                  <span className="text-xs text-slate-200">{perm.name}</span>
                </div>
                <button
                  onClick={() => togglePermission(idx)}
                  className={`px-2.5 py-1 rounded-full text-[10px] font-bold font-mono transition-colors ${
                    perm.granted
                      ? 'bg-emerald-950 text-emerald-300 border border-emerald-500/40'
                      : 'bg-rose-950 text-rose-300 border border-rose-500/40'
                  }`}
                >
                  {perm.granted ? 'GRANTED' : 'DENIED'}
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Section 4: MYRA SECURITY */}
      {activeSection === 'voice_auth' && (
        <div className="space-y-4">
          {/* Master Security Status Card (14. UI Requirement) */}
          <div className="bg-[#111726] border border-emerald-500/40 rounded-2xl p-4 shadow-lg shadow-emerald-950/20">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
                <span className="text-xs font-bold text-white tracking-wider">
                  MYRA SECURITY
                </span>
              </div>
              <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md ${
                ownerProtection ? 'bg-emerald-950 text-emerald-300 border border-emerald-500/30' : 'bg-slate-800 text-slate-400'
              }`}>
                {ownerProtection ? 'ACTIVE' : 'DISABLED'}
              </span>
            </div>

            <div className="py-3 space-y-2 text-xs">
              <div className="flex justify-between items-center">
                <span className="text-slate-300">Owner Protection</span>
                <span className={`font-bold font-mono ${ownerProtection ? 'text-emerald-400' : 'text-slate-500'}`}>
                  {ownerProtection ? 'ON' : 'OFF'}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-300">Owner Voice</span>
                <span className={`font-bold font-mono ${ownerVoiceEnrolled ? 'text-cyan-400' : 'text-amber-400'}`}>
                  {ownerVoiceEnrolled ? 'Enrolled' : 'Not Enrolled'}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-300">Biometric Lock</span>
                <span className={`font-bold font-mono ${biometricLock ? 'text-emerald-400' : 'text-slate-500'}`}>
                  {biometricLock ? 'ON' : 'OFF'}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-300">Sensitive Commands</span>
                <span className={`font-bold font-mono ${sensitiveProtected ? 'text-emerald-400' : 'text-amber-400'}`}>
                  {sensitiveProtected ? 'Protected' : 'Unprotected'}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-300">Unknown Voices</span>
                <span className={`font-bold font-mono ${unknownVoiceBlocked ? 'text-emerald-400' : 'text-slate-500'}`}>
                  {unknownVoiceBlocked ? 'Blocked' : 'Allowed'}
                </span>
              </div>
            </div>

            {/* Action Buttons: [ Test Owner Voice ] [ Re-enroll Voice ] [ Security Settings ] */}
            <div className="grid grid-cols-3 gap-2 pt-3 border-t border-slate-800">
              <button
                onClick={() => {
                  setVoiceTestResult(null);
                  setShowVoiceTestModal(true);
                }}
                className="py-2 px-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-[11px] font-bold text-center transition-all flex items-center justify-center gap-1 shadow-md shadow-blue-900/30"
              >
                <span>Test Owner Voice</span>
              </button>
              <button
                onClick={() => {
                  setEnrollStep(0);
                  setShowVoiceEnrollModal(true);
                }}
                className="py-2 px-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-[11px] font-bold text-center transition-all flex items-center justify-center gap-1 shadow-md shadow-purple-900/30"
              >
                <span>Re-enroll Voice</span>
              </button>
              <button
                onClick={() => {
                  const secEl = document.getElementById('myra-security-controls');
                  secEl?.scrollIntoView({ behavior: 'smooth' });
                }}
                className="py-2 px-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-[11px] font-bold text-center transition-all flex items-center justify-center gap-1 border border-slate-700"
              >
                <span>Security Settings</span>
              </button>
            </div>
          </div>

          {/* Granular Security Controls */}
          <div id="myra-security-controls" className="bg-[#111726] border border-slate-800 rounded-2xl p-4 space-y-4">
            <div>
              <span className="text-xs font-bold text-white uppercase tracking-wider block mb-1">
                Owner Defense & Biometric Boundary
              </span>
              <p className="text-xs text-slate-400">
                Voice verification identifies the owner; Android BiometricPrompt safeguards high-risk actions.
              </p>
            </div>

            <div className="divide-y divide-slate-800/80 text-xs">
              {/* Toggle 1: Owner Protection */}
              <div className="py-3 flex items-center justify-between">
                <div className="pr-4">
                  <div className="font-semibold text-slate-200">Owner Protection</div>
                  <div className="text-[11px] text-slate-400">
                    Sirf owner ki enrolled voice par protected commands chalenge
                  </div>
                </div>
                <button
                  onClick={() => {
                    const newVal = !ownerProtection;
                    setOwnerProtection(newVal);
                    localStorage.setItem('myra_owner_protection', String(newVal));
                  }}
                  className={`px-3 py-1 rounded-full text-[10px] font-bold font-mono transition-colors ${
                    ownerProtection
                      ? 'bg-emerald-950 text-emerald-300 border border-emerald-500/40'
                      : 'bg-slate-800 text-slate-400 border border-slate-700'
                  }`}
                >
                  {ownerProtection ? 'ON' : 'OFF'}
                </button>
              </div>

              {/* Toggle 2: Fingerprint / Face Authentication */}
              <div className="py-3 flex items-center justify-between">
                <div className="pr-4">
                  <div className="font-semibold text-slate-200">Fingerprint / Face Authentication</div>
                  <div className="text-[11px] text-slate-400">
                    Sensitive commands (WhatsApp, SMS, Call, SOS, Connect) ke liye Android BiometricPrompt
                  </div>
                </div>
                <button
                  onClick={() => {
                    const newVal = !biometricLock;
                    setBiometricLock(newVal);
                    localStorage.setItem('myra_biometric_lock', String(newVal));
                  }}
                  className={`px-3 py-1 rounded-full text-[10px] font-bold font-mono transition-colors ${
                    biometricLock
                      ? 'bg-emerald-950 text-emerald-300 border border-emerald-500/40'
                      : 'bg-slate-800 text-slate-400 border border-slate-700'
                  }`}
                >
                  {biometricLock ? 'ON' : 'OFF'}
                </button>
              </div>

              {/* Toggle 3: Device Credential Fallback */}
              <div className="py-3 flex items-center justify-between">
                <div className="pr-4">
                  <div className="font-semibold text-slate-200">Device PIN / Pattern Fallback</div>
                  <div className="text-[11px] text-slate-400">
                    Agar fingerprint/face available na ho toh system PIN/Password ki permission dein
                  </div>
                </div>
                <button
                  onClick={() => {
                    const newVal = !deviceCredential;
                    setDeviceCredential(newVal);
                    localStorage.setItem('myra_device_credential', String(newVal));
                  }}
                  className={`px-3 py-1 rounded-full text-[10px] font-bold font-mono transition-colors ${
                    deviceCredential
                      ? 'bg-emerald-950 text-emerald-300 border border-emerald-500/40'
                      : 'bg-slate-800 text-slate-400 border border-slate-700'
                  }`}
                >
                  {deviceCredential ? 'ON' : 'OFF'}
                </button>
              </div>

              {/* Toggle 4: Unknown Voice Protection */}
              <div className="py-3 flex items-center justify-between">
                <div className="pr-4">
                  <div className="font-semibold text-slate-200">Unknown Voice Protection</div>
                  <div className="text-[11px] text-slate-400">
                    Aparichit aawaz aane par 'Owner verification required' bol kar command block karein
                  </div>
                </div>
                <button
                  onClick={() => {
                    const newVal = !unknownVoiceBlocked;
                    setUnknownVoiceBlocked(newVal);
                    localStorage.setItem('myra_unknown_voice_blocked', String(newVal));
                  }}
                  className={`px-3 py-1 rounded-full text-[10px] font-bold font-mono transition-colors ${
                    unknownVoiceBlocked
                      ? 'bg-emerald-950 text-emerald-300 border border-emerald-500/40'
                      : 'bg-slate-800 text-slate-400 border border-slate-700'
                  }`}
                >
                  {unknownVoiceBlocked ? 'BLOCKED' : 'OFF'}
                </button>
              </div>

              {/* Toggle 5: Sensitive Command Protection */}
              <div className="py-3 flex items-center justify-between">
                <div className="pr-4">
                  <div className="font-semibold text-slate-200">Sensitive Command Protection</div>
                  <div className="text-[11px] text-slate-400">
                    WhatsApp, SMS, Calls, SOS, Location & Settings change ko biometric shield mein rakhein
                  </div>
                </div>
                <button
                  onClick={() => {
                    const newVal = !sensitiveProtected;
                    setSensitiveProtected(newVal);
                    localStorage.setItem('myra_sensitive_protected', String(newVal));
                  }}
                  className={`px-3 py-1 rounded-full text-[10px] font-bold font-mono transition-colors ${
                    sensitiveProtected
                      ? 'bg-emerald-950 text-emerald-300 border border-emerald-500/40'
                      : 'bg-slate-800 text-slate-400 border border-slate-700'
                  }`}
                >
                  {sensitiveProtected ? 'PROTECTED' : 'OFF'}
                </button>
              </div>

              {/* Toggle 6: App Open Protection */}
              <div className="py-3 flex items-center justify-between">
                <div className="pr-4">
                  <div className="font-semibold text-slate-200">App Open Protection</div>
                  <div className="text-[11px] text-slate-400">
                    MYRA shuru hote hi 'MYRA Owner Verification' prompt dikhayein
                  </div>
                </div>
                <button
                  onClick={() => {
                    const newVal = !appOpenProtection;
                    setAppOpenProtection(newVal);
                    localStorage.setItem('myra_app_open_protection', String(newVal));
                  }}
                  className={`px-3 py-1 rounded-full text-[10px] font-bold font-mono transition-colors ${
                    appOpenProtection
                      ? 'bg-emerald-950 text-emerald-300 border border-emerald-500/40'
                      : 'bg-slate-800 text-slate-400 border border-slate-700'
                  }`}
                >
                  {appOpenProtection ? 'ON' : 'OFF'}
                </button>
              </div>
            </div>

            {/* Security Session Timeout Slider */}
            <div className="pt-3 border-t border-slate-800">
              <div className="flex justify-between items-center mb-1 text-xs">
                <span className="text-slate-300 font-semibold">Security Session Window</span>
                <span className="font-mono text-emerald-400 font-bold">{securityTimeoutMins} Minutes</span>
              </div>
              <p className="text-[11px] text-slate-400 mb-2">
                Biometric verify hone ke baad {securityTimeoutMins} minute tak sensitive actions bina baar-baar prompt ke chalenge.
              </p>
              <input
                type="range"
                min="1"
                max="10"
                step="1"
                value={securityTimeoutMins}
                onChange={(e) => setSecurityTimeoutMins(parseInt(e.target.value))}
                className="w-full accent-emerald-500"
              />
            </div>
          </div>

          {/* Interactive Voice Enrollment Modal (Multi-Phrase Flow) */}
          {showVoiceEnrollModal && (
            <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
              <div className="bg-[#111726] border border-purple-500/40 rounded-2xl p-5 max-w-sm w-full space-y-4 shadow-2xl">
                <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                  <div className="flex items-center gap-2">
                    <Mic className="w-5 h-5 text-purple-400" />
                    <span className="text-sm font-bold text-white">Owner Voice Enrollment</span>
                  </div>
                  <span className="text-[11px] font-mono text-purple-300">
                    Step {enrollStep + 1} of 4
                  </span>
                </div>

                <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                  <div
                    className="bg-purple-500 h-full transition-all duration-300"
                    style={{ width: `${((enrollStep + 1) / 4) * 100}%` }}
                  />
                </div>

                <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 text-center space-y-2">
                  <span className="text-xs text-slate-400 block">Kripya saaf aawaz mein boleinp:</span>
                  <div className="text-base font-bold text-white text-purple-200 py-1">
                    "{enrollmentPhrases[enrollStep]}"
                  </div>
                </div>

                <div className="flex flex-col items-center justify-center gap-2 pt-2">
                  <button
                    onClick={() => {
                      setIsEnrollListening(true);
                      setTimeout(() => {
                        setIsEnrollListening(false);
                        if (enrollStep < 3) {
                          setEnrollStep((prev) => prev + 1);
                        } else {
                          setOwnerVoiceEnrolled(true);
                          setOwnerProtection(true);
                          localStorage.setItem('myra_owner_voice_enrolled', 'true');
                          localStorage.setItem('myra_owner_protection', 'true');
                          setShowVoiceEnrollModal(false);
                        }
                      }, 1200);
                    }}
                    className={`w-14 h-14 rounded-full flex items-center justify-center transition-all ${
                      isEnrollListening
                        ? 'bg-rose-500 animate-pulse scale-105 shadow-lg shadow-rose-500/30'
                        : 'bg-purple-600 hover:bg-purple-500 text-white shadow-lg shadow-purple-600/30'
                    }`}
                  >
                    <Mic className="w-6 h-6" />
                  </button>
                  <span className="text-[11px] text-slate-400">
                    {isEnrollListening ? 'Listening & Extracting Embeddings...' : 'Tap mic to record phrase'}
                  </span>
                </div>

                <div className="pt-2 border-t border-slate-800 flex justify-end">
                  <button
                    onClick={() => setShowVoiceEnrollModal(false)}
                    className="px-3 py-1.5 rounded-lg text-xs text-slate-400 hover:text-white"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Interactive Voice Testing Modal */}
          {showVoiceTestModal && (
            <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
              <div className="bg-[#111726] border border-blue-500/40 rounded-2xl p-5 max-w-sm w-full space-y-4 shadow-2xl">
                <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                  <div className="flex items-center gap-2">
                    <ShieldCheck className="w-5 h-5 text-blue-400" />
                    <span className="text-sm font-bold text-white">Test Owner Voice Match</span>
                  </div>
                  <button
                    onClick={() => setShowVoiceTestModal(false)}
                    className="text-xs text-slate-400 hover:text-white"
                  >
                    ✕
                  </button>
                </div>

                <p className="text-xs text-slate-400">
                  Mic daba kar koi bhi bol chal ki command bolein (e.g. "MYRA, battery batao").
                </p>

                <div className="flex flex-col items-center justify-center py-4">
                  <button
                    onClick={() => {
                      setIsTestingVoice(true);
                      setTimeout(() => {
                        setIsTestingVoice(false);
                        setVoiceTestResult({
                          match: true,
                          score: 94.2,
                          text: 'Owner Voice Verified (Confidence: 94.2%)',
                        });
                      }, 1000);
                    }}
                    className={`w-14 h-14 rounded-full flex items-center justify-center transition-all ${
                      isTestingVoice
                        ? 'bg-rose-500 animate-pulse scale-105'
                        : 'bg-blue-600 hover:bg-blue-500 text-white'
                    }`}
                  >
                    <Mic className="w-6 h-6" />
                  </button>
                  <span className="text-[11px] text-slate-400 mt-2">
                    {isTestingVoice ? 'Analyzing acoustic frequencies...' : 'Tap to test speak'}
                  </span>
                </div>

                {voiceTestResult && (
                  <div className="p-3 rounded-xl bg-emerald-950/60 border border-emerald-500/50 text-emerald-300 text-xs text-center font-semibold">
                    ✓ {voiceTestResult.text}
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Section 5: Wake Word */}
      {activeSection === 'wake_word' && (
        <div className="bg-[#111726] border border-slate-800 rounded-2xl p-4 space-y-3">
          <span className="text-xs font-bold text-white uppercase tracking-wider block">
            Always-Listening Wake Word Engine
          </span>
          <p className="text-xs text-slate-400">
            Microphone low-power background model listens for your custom wake phrase.
          </p>

          <div className="space-y-2 pt-1">
            <span className="text-xs font-semibold text-slate-300 block">Select Wake Phrase:</span>
            {[
              { id: 'Hey MYRA', label: 'Hey MYRA (Default)', sub: 'Standard trigger' },
              { id: 'Sun MYRA', label: 'Sun MYRA', sub: 'Natural conversational Hindi trigger' },
              { id: 'Namaste MYRA', label: 'Namaste MYRA', sub: 'Traditional Indian greeting' },
              { id: 'Hello MYRA', label: 'Hello MYRA', sub: 'Casual voice trigger' },
            ].map((wp) => (
              <button
                key={wp.id}
                onClick={() =>
                  onUpdateVoiceSettings({
                    ...voiceSettings,
                    wakeWord: wp.id,
                  })
                }
                className={`w-full p-2.5 rounded-xl border text-left flex items-center justify-between transition-all ${
                  (voiceSettings.wakeWord || 'Hey MYRA') === wp.id
                    ? 'bg-blue-950/70 border-blue-500 text-white'
                    : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200'
                }`}
              >
                <div>
                  <span className="text-xs font-bold block text-white font-mono">"{wp.id}"</span>
                  <span className="text-[10px] text-slate-400">{wp.sub}</span>
                </div>
                {(voiceSettings.wakeWord || 'Hey MYRA') === wp.id ? (
                  <CheckCircle2 className="w-4 h-4 text-blue-400 shrink-0" />
                ) : (
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-400">
                    SELECT
                  </span>
                )}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Section 6: PC Connect */}
      {activeSection === 'pc_connect' && (
        <div className="bg-[#111726] border border-slate-800 rounded-2xl p-4 space-y-3">
          <span className="text-xs font-bold text-white uppercase tracking-wider block">
            PC Connect (MYRA Companion)
          </span>
          <p className="text-xs text-slate-400">
            Laptop/PC ko phone se control karna (Page 7 & 10).
          </p>

          <div className="space-y-2">
            <div>
              <label className="text-[11px] text-slate-400 block mb-1">PC IP Address:</label>
              <input
                type="text"
                value={pcIp}
                onChange={(e) => setPcIp(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 text-xs text-white rounded-xl p-2.5 outline-none font-mono"
              />
            </div>

            <div>
              <label className="text-[11px] text-slate-400 block mb-1">Companion Security PIN:</label>
              <input
                type="text"
                value={pcPin}
                onChange={(e) => setPcPin(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 text-xs text-white rounded-xl p-2.5 outline-none font-mono"
              />
            </div>

            <button
              onClick={() => setPcConnected(!pcConnected)}
              className={`w-full py-2.5 rounded-xl text-xs font-bold transition-all ${
                pcConnected
                  ? 'bg-emerald-600 text-white'
                  : 'bg-blue-600 hover:bg-blue-500 text-white'
              }`}
            >
              {pcConnected ? 'Connected to Windows PC (192.168.1.105)' : 'Connect to PC Companion'}
            </button>
          </div>
        </div>
      )}

      {/* Section 7: Safety Rules Reference */}
      {activeSection === 'safety' && (
        <div className="bg-[#111726] border border-slate-800 rounded-2xl p-4 space-y-3">
          <div className="flex items-center gap-2">
            <ShieldAlert className="w-5 h-5 text-amber-400" />
            <h3 className="text-xs font-bold text-white uppercase tracking-wider">
              16. Safety Rules — MYRA Kya Kabhi Nahi Karega
            </h3>
          </div>

          <div className="space-y-2 text-xs">
            <div className="p-2.5 rounded-xl bg-slate-900/80 border border-slate-800">
              <span className="font-bold text-amber-300 block mb-0.5">OTP/Password Privacy</span>
              <p className="text-slate-300 text-[11px]">
                MYRA kabhi khud se OTP, password, ya bank PIN nahi bolta — sirf tab jab aap explicitly poochho ("OTP batao").
              </p>
            </div>

            <div className="p-2.5 rounded-xl bg-slate-900/80 border border-slate-800">
              <span className="font-bold text-amber-300 block mb-0.5">Call-Reject Guard</span>
              <p className="text-slate-300 text-[11px]">
                Ringing call ko sirf tab kaatega jab pichle ~20 second mein aapne clearly reject word bola ho ("reject", "kaat do", "mat utha"). Confusion mein hang up nahi karega, dobara poochega.
              </p>
            </div>

            <div className="p-2.5 rounded-xl bg-slate-900/80 border border-slate-800">
              <span className="font-bold text-amber-300 block mb-0.5">Lock command (Instant)</span>
              <p className="text-slate-300 text-[11px]">
                "Lock kar do" turant bina confirmation ke chal jaata hai — kyunki ye urgent safety command mana jaata hai.
              </p>
            </div>

            <div className="p-2.5 rounded-xl bg-slate-900/80 border border-slate-800">
              <span className="font-bold text-amber-300 block mb-0.5">Traffic data honest hai</span>
              <p className="text-slate-300 text-[11px]">
                Agar real traffic data available nahi hai to MYRA "pata nahi" bolega, kabhi jhoothi "traffic smooth hai" jaisi baat nahi banayega.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Section 8: Android APK & Complete Source Exporter */}
      {activeSection === 'apk_export' && (
        <div className="bg-[#111726] border border-blue-500/40 rounded-2xl p-4 space-y-4 shadow-xl">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl bg-blue-600/20 text-blue-400 border border-blue-500/30">
                <Smartphone className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-white uppercase tracking-wider">
                  Complete Android Studio Project Export
                </h3>
                <p className="text-[11px] text-slate-400">
                  Full buildable Native Android project (Jetpack Compose & Kotlin)
                </p>
              </div>
            </div>
            <span className="text-[10px] font-mono px-2.5 py-1 rounded-full bg-emerald-950 text-emerald-400 border border-emerald-500/40">
              READY (ZIP)
            </span>
          </div>

          {/* Primary Download Card */}
          <div className="bg-gradient-to-br from-blue-950/70 via-slate-900 to-indigo-950/70 border border-blue-500/40 rounded-2xl p-4 space-y-3 shadow-lg">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="text-xl">📦</span>
                <div>
                  <span className="text-sm font-bold text-white font-mono block">
                    MYRA_ANDROID_PROJECT_FULL.zip
                  </span>
                  <span className="text-[10px] text-slate-300">
                    51 files • 84.5 KB Uncompressed • 31 Kotlin Sources • 0 TODOs
                  </span>
                </div>
              </div>
            </div>

            <a
              href="/MYRA_ANDROID_PROJECT_FULL.zip"
              download="MYRA_ANDROID_PROJECT_FULL.zip"
              className="w-full py-3 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-blue-900/40 active:scale-98 transition-all"
            >
              <Download className="w-4 h-4" />
              <span>DOWNLOAD MYRA_ANDROID_PROJECT_FULL.ZIP</span>
            </a>

            <div className="flex items-center justify-between text-[10px] text-slate-400 px-1">
              <span>Direct Link: <code className="text-blue-300">/MYRA_ANDROID_PROJECT_FULL.zip</code></span>
              <a href="/MYRA_Android_Project.zip" download className="text-slate-400 hover:text-white underline">
                Also download as MYRA_Android_Project.zip
              </a>
            </div>
          </div>

          {/* Files Included Summary */}
          <div className="bg-slate-900/90 rounded-xl p-3 text-xs border border-slate-800 space-y-2.5">
            <span className="font-semibold text-slate-200 block text-xs">
              What's Included in this ZIP (100% Buildable):
            </span>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px] text-slate-300">
              <div className="p-2 rounded-lg bg-black/40 border border-slate-800 space-y-1">
                <span className="text-blue-400 font-bold block font-mono">📱 App & UI</span>
                <div>• MainActivity.kt (Compose Root)</div>
                <div>• MainVoiceScreen.kt (Voice-First UI)</div>
                <div>• AnimatedOrb.kt (Quantum Canvas Orb)</div>
                <div>• ToolsScreen.kt & SettingsScreen.kt</div>
              </div>

              <div className="p-2 rounded-lg bg-black/40 border border-slate-800 space-y-1">
                <span className="text-emerald-400 font-bold block font-mono">🎙️ Voice & Duplex Audio</span>
                <div>• GeminiLiveVoiceEngine.kt (WebSocket)</div>
                <div>• AudioTrackPlayer.kt (24kHz PCM)</div>
                <div>• AudioRecorder.kt (16kHz RMS)</div>
                <div>• SystemSpeechEngine.kt (Fallback)</div>
              </div>

              <div className="p-2 rounded-lg bg-black/40 border border-slate-800 space-y-1">
                <span className="text-amber-400 font-bold block font-mono">⚡ Services & Tools</span>
                <div>• MyraAccessibilityService.kt</div>
                <div>• MyraVoiceInteractionService.kt</div>
                <div>• WhatsAppAutomation.kt & Calls</div>
                <div>• DeviceControlManager.kt (Flashlight/Battery)</div>
              </div>

              <div className="p-2 rounded-lg bg-black/40 border border-slate-800 space-y-1">
                <span className="text-indigo-400 font-bold block font-mono">⚙️ Gradle & Android Config</span>
                <div>• AndroidManifest.xml (All permissions)</div>
                <div>• build.gradle.kts & settings.gradle.kts</div>
                <div>• gradle-wrapper.properties (8.4)</div>
                <div>• gradlew & gradlew.bat</div>
              </div>
            </div>
          </div>

          {/* How to Open in Android Studio & AndroidIDE */}
          <div className="bg-slate-900/90 rounded-xl p-3 text-xs border border-slate-800 space-y-2">
            <span className="font-semibold text-slate-200 block">
              How to Open & Run:
            </span>
            <div className="space-y-1.5 text-[11px] text-slate-400 leading-relaxed">
              <div>
                <strong className="text-slate-200">1. Android Studio (PC / Mac):</strong> Unzip file ➔ File ➔ Open ➔ Select <code className="text-blue-300">MYRA_Android_Project</code> ➔ Sync Gradle ➔ Run 'app' on Phone/Emulator.
              </div>
              <div>
                <strong className="text-slate-200">2. AndroidIDE (Directly on Phone):</strong> Install AndroidIDE from F-Droid/GitHub ➔ Unzip to <code className="text-blue-300">/storage/emulated/0/AndroidIDEProjects/</code> ➔ Open and tap Build APK.
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
