<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://ai.google.dev/static/site-assets/images/share-ais-513315318.png" />
</div>

# Run and deploy your AI Studio app

This contains everything you need to run your app locally.

View your app in AI Studio: https://ai.studio/apps/cbee01b6-4f02-4569-88e2-65a2e204a4ac

## Run Locally

**Prerequisites:**  Node.js


1. Install dependencies:
   `npm install`
2. Set the `GEMINI_API_KEY` in [.env.local](.env.local) to your Gemini API key
3. Run the app:
   `npm run dev`


## Native Android project

The native Kotlin/Jetpack Compose Android application is in `MYRA_Android_Project/`. Open that folder directly in AndroidIDE or Android Studio. The repository-level GitHub Actions workflow builds the project from that directory.


## Latest audited downloads

- `MYRA_ANDROID_AUDITED_FINAL.zip`: native Android source + repository-root CI configuration; open `MYRA_Android_Project/` in AndroidIDE.
- `MYRA_PROJECT_COMPLETE_FULL_SOURCE.zip`: full React/Vite + native Android workspace snapshot.

The source audit is complete, but an APK build was not verified in the current environment. See `AUDIT_FIXES.md` for limitations.
