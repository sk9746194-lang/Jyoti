package com.myra.assistant.wallpaper

import android.service.wallpaper.WallpaperService

/**
 * Official Android WallpaperService for MYRA AI Live Wallpaper.
 */
class MyraLiveWallpaperService : WallpaperService() {

    override fun onCreateEngine(): Engine {
        return MyraWallpaperEngine(this)
    }
}
